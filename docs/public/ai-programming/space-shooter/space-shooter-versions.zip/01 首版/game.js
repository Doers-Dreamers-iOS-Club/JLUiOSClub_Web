/* ============================================================
   深空防线 — 单文件游戏逻辑
   ------------------------------------------------------------
   游戏世界固定为 960 × 600，CSS 只负责缩放画面。
   整局游戏只运行一个 requestAnimationFrame 循环；重新开始
   只重置状态，不会再次注册循环，因此连续重开不会加速。
   ============================================================ */
(() => {
  "use strict";

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");
  const stage = document.getElementById("stage");
  const scoreOutput = document.getElementById("score");
  const livesCount = document.getElementById("livesCount");
  const lifePips = Array.from(document.querySelectorAll(".life-pip"));
  const overlay = document.getElementById("gameOverOverlay");
  const finalScoreOutput = document.getElementById("finalScore");
  const restartButton = document.getElementById("restartButton");

  if (!canvas || !ctx || !stage || !scoreOutput || !overlay || !restartButton) {
    throw new Error("游戏初始化失败：缺少必要的页面元素。");
  }

  const W = 960;
  const H = 600;
  const MAX_LIVES = 3;
  const PLAYER_SPEED = 390;
  const PLAYER_FIRE_INTERVAL = 0.14;
  const BULLET_SPEED = 760;
  const SCORE_PER_ENEMY = 100;
  const INITIAL_SPAWN_DELAY = 0.55;
  const MIN_SPAWN_INTERVAL = 0.46;
  const PLAYER_HALF_W = 26;
  const PLAYER_HALF_H = 29;
  const INVULNERABLE_TIME = 1.25;
  const TAU = Math.PI * 2;

  const State = Object.freeze({
    PLAYING: "playing",
    GAME_OVER: "gameover",
  });

  const keys = new Set();
  const stars = [];
  let bullets = [];
  let enemies = [];
  let particles = [];
  let player = createPlayer();
  let state = State.PLAYING;
  let score = 0;
  let lives = MAX_LIVES;
  let elapsed = 0;
  let spawnClock = INITIAL_SPAWN_DELAY;
  let fireClock = 0;
  let shakeClock = 0;
  let damageFlash = 0;
  let nextEnemyId = 1;
  let lastFrameTime = performance.now();

  function random(min, max) {
    return min + Math.random() * (max - min);
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function padScore(value) {
    return String(value).padStart(6, "0");
  }

  function circlesRectsOverlap(ax, ay, ahw, ahh, bx, by, bhw, bhh) {
    return Math.abs(ax - bx) < ahw + bhw && Math.abs(ay - by) < ahh + bhh;
  }

  function createPlayer() {
    return {
      x: W / 2,
      y: H - 76,
      tilt: 0,
      invulnerable: 0,
      hitHalfW: 15,
      hitHalfH: 18,
    };
  }

  /* ---------- 初始化与画面尺寸 ---------- */

  function initStars() {
    stars.length = 0;
    for (let i = 0; i < 118; i += 1) {
      stars.push({
        x: random(6, W - 6),
        y: random(6, H - 6),
        size: random(0.7, 1.9),
        speed: random(13, 68),
        alpha: random(0.22, 0.82),
        twinkle: random(0, TAU),
        twinkleSpeed: random(0.5, 2.1),
      });
    }
  }

  function setupCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
  }

  function updateHud() {
    scoreOutput.textContent = padScore(score);
    livesCount.textContent = String(lives);
    lifePips.forEach((pip, index) => {
      pip.classList.toggle("is-empty", index >= lives);
    });
  }

  /* ---------- 一局的生命周期 ---------- */

  function resetRound() {
    state = State.PLAYING;
    score = 0;
    lives = MAX_LIVES;
    elapsed = 0;
    spawnClock = INITIAL_SPAWN_DELAY;
    fireClock = 0;
    shakeClock = 0;
    damageFlash = 0;
    nextEnemyId = 1;
    player = createPlayer();
    bullets = [];
    enemies = [];
    particles = [];
    keys.clear();

    overlay.hidden = true;
    stage.classList.remove("is-over");
    finalScoreOutput.textContent = padScore(0);
    updateHud();
    lastFrameTime = performance.now();
  }

  function restartGame() {
    resetRound();
    canvas.focus({ preventScroll: true });
  }

  function endGame() {
    if (state === State.GAME_OVER) return;

    state = State.GAME_OVER;
    keys.clear();
    shakeClock = 0;
    damageFlash = 0;
    finalScoreOutput.textContent = padScore(score);
    overlay.hidden = false;
    stage.classList.add("is-over");
    restartButton.focus({ preventScroll: true });
  }

  /* ---------- 键盘输入 ---------- */

  function isGameKey(code) {
    return (
      code === "Space" ||
      code.startsWith("Arrow") ||
      code === "KeyW" ||
      code === "KeyA" ||
      code === "KeyS" ||
      code === "KeyD"
    );
  }

  function isInteractiveTarget(target) {
    return (
      target instanceof Element &&
      Boolean(target.closest("button, a, input, textarea, select"))
    );
  }

  window.addEventListener("keydown", (event) => {
    const code = event.code;
    const gameKey = isGameKey(code);
    const onControl = isInteractiveTarget(event.target);

    // 阻止方向键滚动页面 / 空格键触发页面滚动。按钮聚焦时保留原生激活。
    if (gameKey && !onControl) {
      event.preventDefault();
    }

    if (state === State.GAME_OVER) {
      if ((code === "Enter" || code === "Space") && !onControl) {
        restartGame();
      }
      return;
    }

    if (gameKey) {
      keys.add(code);
    }
  });

  window.addEventListener("keyup", (event) => {
    keys.delete(event.code);
  });

  window.addEventListener("blur", () => {
    keys.clear();
  });

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      keys.clear();
    }
  });

  restartButton.addEventListener("click", () => {
    restartGame();
  });

  canvas.addEventListener("pointerdown", () => {
    canvas.focus({ preventScroll: true });
  });

  /* ---------- 玩家 ---------- */

  function updatePlayer(dt) {
    const left = keys.has("ArrowLeft") || keys.has("KeyA");
    const right = keys.has("ArrowRight") || keys.has("KeyD");
    const up = keys.has("ArrowUp") || keys.has("KeyW");
    const down = keys.has("ArrowDown") || keys.has("KeyS");

    let dx = Number(right) - Number(left);
    let dy = Number(down) - Number(up);

    if (dx !== 0 && dy !== 0) {
      const diagonal = Math.SQRT1_2;
      dx *= diagonal;
      dy *= diagonal;
    }

    player.x = clamp(
      player.x + dx * PLAYER_SPEED * dt,
      PLAYER_HALF_W + 6,
      W - PLAYER_HALF_W - 6,
    );
    player.y = clamp(
      player.y + dy * PLAYER_SPEED * dt,
      PLAYER_HALF_H + 6,
      H - PLAYER_HALF_H - 6,
    );

    const targetTilt = dx * 0.16;
    const smoothing = 1 - Math.exp(-12 * dt);
    player.tilt += (targetTilt - player.tilt) * smoothing;

    if (player.invulnerable > 0) {
      player.invulnerable = Math.max(0, player.invulnerable - dt);
    }
  }

  function updateShooting(dt) {
    fireClock = Math.max(0, fireClock - dt);

    if (!keys.has("Space") || fireClock > 0) {
      return;
    }

    // 双发等离子弹；任一发命中即可摧毁一架敌机。
    bullets.push({
      x: player.x - 9,
      y: player.y - 26,
      vy: -BULLET_SPEED,
      halfW: 2.5,
      halfH: 9,
    });
    bullets.push({
      x: player.x + 9,
      y: player.y - 26,
      vy: -BULLET_SPEED,
      halfW: 2.5,
      halfH: 9,
    });
    fireClock = PLAYER_FIRE_INTERVAL;
  }

  /* ---------- 敌机 ---------- */

  function createEnemy(options = {}) {
    const speedRamp = Math.min(elapsed * 2.1, 105);
    const startX = clamp(
      options.x ?? random(56, W - 56),
      52,
      W - 52,
    );
    const sway = options.sway ?? random(7, 25);

    return {
      id: nextEnemyId++,
      x: startX,
      baseX: startX,
      y: options.y ?? -38,
      speed: options.speed ?? random(92, 128) + speedRamp,
      sway,
      swayRate: random(1.1, 2.2),
      phase: random(0, TAU),
      age: 0,
      points: SCORE_PER_ENEMY,
      destroyed: false,
      hasHitPlayer: false,
      hitHalfW: 17,
      hitHalfH: 14,
    };
  }

  function spawnEnemy() {
    const enemy = createEnemy();
    enemies.push(enemy);
  }

  function updateSpawner(dt) {
    spawnClock -= dt;
    if (spawnClock > 0) {
      return;
    }

    spawnEnemy();

    // 难度随时间平缓上升，但每局都会从同样的基础速度与间隔开始。
    const interval = Math.max(
      MIN_SPAWN_INTERVAL,
      0.95 - elapsed * 0.0075,
    );
    spawnClock = interval * random(0.88, 1.12);
  }

  function updateEnemies(dt) {
    for (let i = enemies.length - 1; i >= 0; i -= 1) {
      const enemy = enemies[i];
      enemy.age += dt;
      enemy.y += enemy.speed * dt;
      enemy.x = clamp(
        enemy.baseX + Math.sin(enemy.age * enemy.swayRate + enemy.phase) * enemy.sway,
        20,
        W - 20,
      );

      if (enemy.y - enemy.hitHalfH > H + 34) {
        enemies.splice(i, 1);
      }
    }
  }

  /* ---------- 子弹与碰撞 ---------- */

  function updateBullets(dt) {
    for (let i = bullets.length - 1; i >= 0; i -= 1) {
      const bullet = bullets[i];
      bullet.y += bullet.vy * dt;

      if (bullet.y + bullet.halfH < -10) {
        bullets.splice(i, 1);
        continue;
      }

      for (let j = enemies.length - 1; j >= 0; j -= 1) {
        const enemy = enemies[j];

        if (
          !enemy.destroyed &&
          circlesRectsOverlap(
            bullet.x,
            bullet.y,
            bullet.halfW,
            bullet.halfH,
            enemy.x,
            enemy.y,
            enemy.hitHalfW,
            enemy.hitHalfH,
          )
        ) {
          // 先锁定结算标记，再把敌机移出数组。即使同帧有两发子弹命中，
          // 同一架敌机也只会结算一次分数。
          enemy.destroyed = true;
          enemies.splice(j, 1);
          bullets.splice(i, 1);
          score += enemy.points;
          updateHud();
          burst(enemy.x, enemy.y, 16, "#ff719e", 185);
          break;
        }
      }
    }
  }

  function resolvePlayerCollisions() {
    for (let i = enemies.length - 1; i >= 0; i -= 1) {
      const enemy = enemies[i];

      if (enemy.hasHitPlayer) {
        continue;
      }

      const touchesPlayer = circlesRectsOverlap(
        player.x,
        player.y,
        player.hitHalfW,
        player.hitHalfH,
        enemy.x,
        enemy.y,
        enemy.hitHalfW,
        enemy.hitHalfH,
      );

      if (!touchesPlayer) {
        continue;
      }

      // 每架敌机只允许触发一次碰撞结算，并立即从场上移除。
      enemy.hasHitPlayer = true;
      enemies.splice(i, 1);
      burst(enemy.x, enemy.y, 10, "#ff9c7a", 135);

      if (player.invulnerable <= 0) {
        loseLife();
        if (state === State.GAME_OVER) {
          return;
        }
      }
    }
  }

  function loseLife() {
    lives = Math.max(0, lives - 1);
    player.invulnerable = INVULNERABLE_TIME;
    shakeClock = 0.34;
    damageFlash = 0.5;
    updateHud();
    burst(player.x, player.y, 24, "#ffd37a", 245);

    if (lives <= 0) {
      endGame();
    }
  }

  /* ---------- 粒子与背景 ---------- */

  function burst(x, y, count, color, power) {
    for (let i = 0; i < count; i += 1) {
      const angle = random(0, TAU);
      const speed = random(power * 0.25, power);
      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: random(0.28, 0.72),
        maxLife: 0.72,
        size: random(1.2, 3.4),
        color,
      });
    }
  }

  function updateParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i -= 1) {
      const particle = particles[i];
      particle.life -= dt;
      if (particle.life <= 0) {
        particles.splice(i, 1);
        continue;
      }

      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= Math.pow(0.18, dt);
      particle.vy *= Math.pow(0.18, dt);
    }
  }

  function updateStars(dt) {
    for (const star of stars) {
      star.y += star.speed * dt;
      if (star.y > H + 4) {
        star.y = -4;
        star.x = random(6, W - 6);
      }
    }
  }

  function updateEffects(dt) {
    shakeClock = Math.max(0, shakeClock - dt);
    damageFlash = Math.max(0, damageFlash - dt);
  }

  /* ---------- 主更新 ---------- */

  function update(dt) {
    elapsed += dt;
    updateStars(dt);
    updateEffects(dt);
    updatePlayer(dt);
    updateShooting(dt);
    updateSpawner(dt);
    updateEnemies(dt);
    updateBullets(dt);
    resolvePlayerCollisions();

    if (state === State.PLAYING) {
      updateParticles(dt);
    }
  }

  /* ---------- 绘制 ---------- */

  function drawBackdrop() {
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#06121f");
    sky.addColorStop(0.45, "#04101a");
    sky.addColorStop(1, "#040a12");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    const nebulaA = ctx.createRadialGradient(
      W * 0.16,
      H * 0.18,
      8,
      W * 0.16,
      H * 0.18,
      W * 0.48,
    );
    nebulaA.addColorStop(0, "rgba(31, 139, 164, 0.13)");
    nebulaA.addColorStop(0.45, "rgba(20, 102, 140, 0.055)");
    nebulaA.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = nebulaA;
    ctx.fillRect(0, 0, W, H);

    const nebulaB = ctx.createRadialGradient(
      W * 0.86,
      H * 0.74,
      10,
      W * 0.86,
      H * 0.74,
      W * 0.42,
    );
    nebulaB.addColorStop(0, "rgba(137, 40, 97, 0.09)");
    nebulaB.addColorStop(0.55, "rgba(93, 30, 84, 0.035)");
    nebulaB.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = nebulaB;
    ctx.fillRect(0, 0, W, H);

    // 极淡的坐标网格，给驾驶舱一点仪表感。
    ctx.strokeStyle = "rgba(115, 219, 255, 0.045)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 120; x < W; x += 120) {
      ctx.moveTo(x + 0.5, 0);
      ctx.lineTo(x + 0.5, H);
    }
    for (let y = 100; y < H; y += 100) {
      ctx.moveTo(0, y + 0.5);
      ctx.lineTo(W, y + 0.5);
    }
    ctx.stroke();

    // 顶部微光，暗示敌方来袭方向。
    const topGlow = ctx.createLinearGradient(0, 0, 0, 130);
    topGlow.addColorStop(0, "rgba(255, 93, 148, 0.075)");
    topGlow.addColorStop(1, "rgba(255, 93, 148, 0)");
    ctx.fillStyle = topGlow;
    ctx.fillRect(0, 0, W, 130);
  }

  function drawStars() {
    ctx.save();
    for (const star of stars) {
      const flicker =
        0.68 + 0.32 * Math.sin(elapsed * star.twinkleSpeed + star.twinkle);
      ctx.globalAlpha = star.alpha * flicker;
      ctx.fillStyle = star.speed > 45 ? "#c8f6ff" : "#a9c8dd";
      ctx.fillRect(star.x, star.y, star.size, star.size);
    }
    ctx.restore();
  }

  function drawPlayer() {
    if (lives <= 0) {
      return;
    }

    const blinking =
      player.invulnerable > 0 && Math.floor(player.invulnerable * 16) % 2 === 0;

    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.rotate(player.tilt);
    ctx.globalAlpha = blinking ? 0.36 : 1;

    // 尾焰
    const flame = 17 + Math.sin(elapsed * 44) * 4;
    const flameGradient = ctx.createLinearGradient(0, 20, 0, 25 + flame);
    flameGradient.addColorStop(0, "rgba(202, 253, 255, 0.95)");
    flameGradient.addColorStop(0.5, "rgba(98, 230, 255, 0.8)");
    flameGradient.addColorStop(1, "rgba(43, 116, 255, 0)");
    ctx.fillStyle = flameGradient;
    ctx.beginPath();
    ctx.moveTo(-7, 20);
    ctx.lineTo(7, 20);
    ctx.lineTo(0, 25 + flame);
    ctx.closePath();
    ctx.fill();

    // 机翼与机身
    const hullPath = new Path2D();
    hullPath.moveTo(0, -29);
    hullPath.lineTo(6, -16);
    hullPath.lineTo(9, -6);
    hullPath.lineTo(20, 8);
    hullPath.lineTo(27, 17);
    hullPath.lineTo(14, 13);
    hullPath.lineTo(9, 22);
    hullPath.lineTo(4, 26);
    hullPath.lineTo(-4, 26);
    hullPath.lineTo(-9, 22);
    hullPath.lineTo(-14, 13);
    hullPath.lineTo(-27, 17);
    hullPath.lineTo(-20, 8);
    hullPath.lineTo(-9, -6);
    hullPath.lineTo(-6, -16);
    hullPath.closePath();

    ctx.save();
    ctx.shadowColor = "rgba(114, 238, 255, 0.85)";
    ctx.shadowBlur = 18;
    ctx.fillStyle = "#0b2633";
    ctx.fill(hullPath);
    ctx.restore();

    ctx.strokeStyle = "#7cefff";
    ctx.lineWidth = 1.7;
    ctx.stroke(hullPath);

    ctx.strokeStyle = "rgba(114, 238, 255, 0.45)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-19, 9);
    ctx.lineTo(-8, 3);
    ctx.moveTo(19, 9);
    ctx.lineTo(8, 3);
    ctx.moveTo(0, -24);
    ctx.lineTo(0, 16);
    ctx.stroke();

    const cockpit = ctx.createLinearGradient(0, -14, 0, 5);
    cockpit.addColorStop(0, "#d9ffff");
    cockpit.addColorStop(0.5, "#72eeff");
    cockpit.addColorStop(1, "#1e6b89");
    ctx.fillStyle = cockpit;
    ctx.beginPath();
    ctx.ellipse(0, -7, 4.2, 9, 0, 0, TAU);
    ctx.fill();

    ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
    ctx.beginPath();
    ctx.ellipse(-1.2, -10, 1.2, 3.2, -0.25, 0, TAU);
    ctx.fill();

    ctx.restore();

    // 受击后的短暂护盾环。
    if (player.invulnerable > 0) {
      const shieldAlpha = 0.2 + Math.sin(elapsed * 18) * 0.08;
      ctx.save();
      ctx.strokeStyle = `rgba(114, 238, 255, ${shieldAlpha})`;
      ctx.lineWidth = 1;
      ctx.setLineDash([7, 9]);
      ctx.beginPath();
      ctx.arc(player.x, player.y, 33, 0, TAU);
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawEnemies() {
    for (const enemy of enemies) {
      const glowColor = enemy.id % 2 === 0 ? "#ff789f" : "#ff977c";
      const rotation = Math.sin(enemy.age * 2.2 + enemy.phase) * 0.08;

      ctx.save();
      ctx.translate(enemy.x, enemy.y);
      ctx.rotate(rotation);
      ctx.shadowColor = glowColor;
      ctx.shadowBlur = 14;

      const body = new Path2D();
      body.moveTo(0, 17);
      body.lineTo(9, 8);
      body.lineTo(21, 4);
      body.lineTo(15, -3);
      body.lineTo(20, -11);
      body.lineTo(7, -8);
      body.lineTo(0, -16);
      body.lineTo(-7, -8);
      body.lineTo(-20, -11);
      body.lineTo(-15, -3);
      body.lineTo(-21, 4);
      body.lineTo(-9, 8);
      body.closePath();

      ctx.fillStyle = "#260b19";
      ctx.fill(body);
      ctx.strokeStyle = glowColor;
      ctx.lineWidth = 1.5;
      ctx.stroke(body);

      ctx.shadowBlur = 0;
      ctx.strokeStyle = "rgba(255, 132, 165, 0.54)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-13, -1);
      ctx.lineTo(13, -1);
      ctx.moveTo(-9, 9);
      ctx.lineTo(9, 9);
      ctx.stroke();

      const eye = ctx.createRadialGradient(0, 1, 0, 0, 1, 6);
      eye.addColorStop(0, "#fff0b8");
      eye.addColorStop(0.35, "#ffd37a");
      eye.addColorStop(1, "rgba(255, 93, 148, 0)");
      ctx.fillStyle = eye;
      ctx.beginPath();
      ctx.arc(0, 1, 6, 0, TAU);
      ctx.fill();

      ctx.fillStyle = "#fff6d6";
      ctx.beginPath();
      ctx.arc(0, 1, 1.8, 0, TAU);
      ctx.fill();

      ctx.restore();
    }
  }

  function drawBullets() {
    ctx.save();
    ctx.shadowColor = "#89f7ff";
    ctx.shadowBlur = 12;
    for (const bullet of bullets) {
      const gradient = ctx.createLinearGradient(
        0,
        bullet.y - 15,
        0,
        bullet.y + 10,
      );
      gradient.addColorStop(0, "rgba(137, 247, 255, 0)");
      gradient.addColorStop(0.4, "#89f7ff");
      gradient.addColorStop(1, "#ffffff");
      ctx.fillStyle = gradient;
      ctx.fillRect(bullet.x - 1.8, bullet.y - 12, 3.6, 22);
    }
    ctx.restore();
  }

  function drawParticles() {
    ctx.save();
    for (const particle of particles) {
      const alpha = clamp(particle.life / particle.maxLife, 0, 1);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = particle.color;
      ctx.fillRect(
        particle.x - particle.size / 2,
        particle.y - particle.size / 2,
        particle.size,
        particle.size,
      );
    }
    ctx.restore();
  }

  function drawDamageFlash() {
    if (damageFlash <= 0 || state !== State.PLAYING) {
      return;
    }

    const flash = ctx.createRadialGradient(
      W / 2,
      H / 2,
      H * 0.2,
      W / 2,
      H / 2,
      H * 0.78,
    );
    flash.addColorStop(0, "rgba(255, 70, 120, 0)");
    flash.addColorStop(1, `rgba(255, 70, 120, ${damageFlash * 0.48})`);
    ctx.fillStyle = flash;
    ctx.fillRect(0, 0, W, H);
  }

  function render() {
    ctx.clearRect(0, 0, W, H);
    drawBackdrop();
    drawStars();

    ctx.save();
    if (state === State.PLAYING && shakeClock > 0) {
      const strength = shakeClock * 16;
      ctx.translate(random(-strength, strength), random(-strength, strength));
    }

    drawEnemies();
    drawBullets();
    drawParticles();
    drawPlayer();
    ctx.restore();

    drawDamageFlash();
  }

  /* ---------- 动画循环（全局唯一） ---------- */

  function frame(now) {
    const dt = Math.min(Math.max((now - lastFrameTime) / 1000, 0), 1 / 30);
    lastFrameTime = now;

    if (state === State.PLAYING) {
      update(dt);
    }

    render();
    requestAnimationFrame(frame);
  }

  /* ---------- 自动化验收接口（仅在 ?debug=1 时开启） ---------- */

  function installDebugApi() {
    const enabled = new URLSearchParams(window.location.search).has("debug");
    if (!enabled) {
      return;
    }

    window.__SPACE_SHOOTER_DEBUG__ = Object.freeze({
      snapshot() {
        return {
          state,
          score,
          lives,
          elapsed: Number(elapsed.toFixed(4)),
          spawnClock: Number(spawnClock.toFixed(4)),
          player: {
            x: Number(player.x.toFixed(2)),
            y: Number(player.y.toFixed(2)),
            invulnerable: Number(player.invulnerable.toFixed(3)),
          },
          enemies: enemies.map((enemy) => ({
            id: enemy.id,
            x: Number(enemy.x.toFixed(2)),
            y: Number(enemy.y.toFixed(2)),
            speed: Number(enemy.speed.toFixed(2)),
            destroyed: enemy.destroyed,
            hasHitPlayer: enemy.hasHitPlayer,
          })),
          bullets: bullets.map((bullet) => ({
            x: Number(bullet.x.toFixed(2)),
            y: Number(bullet.y.toFixed(2)),
          })),
          overlayVisible: !overlay.hidden,
          finalScore: finalScoreOutput.textContent,
        };
      },
      spawnEnemyAt(x, y, options = {}) {
        if (state !== State.PLAYING) {
          return null;
        }
        const enemy = createEnemy({
          x,
          y,
          speed: options.speed ?? 0,
          sway: options.sway ?? 0,
        });
        enemies.push(enemy);
        return enemy.id;
      },
      spawnBulletAt(x, y, vy = -BULLET_SPEED) {
        if (state !== State.PLAYING) {
          return false;
        }
        bullets.push({ x, y, vy, halfW: 2.5, halfH: 9 });
        return true;
      },
      setPlayerPosition(x, y) {
        player.x = clamp(x, PLAYER_HALF_W + 6, W - PLAYER_HALF_W - 6);
        player.y = clamp(y, PLAYER_HALF_H + 6, H - PLAYER_HALF_H - 6);
      },
      setLives(value) {
        lives = clamp(Math.round(value), 0, MAX_LIVES);
        updateHud();
        if (lives <= 0) {
          endGame();
        }
      },
      setInvulnerable(seconds) {
        player.invulnerable = Math.max(0, seconds);
      },
      restart() {
        restartGame();
      },
    });
  }

  /* ---------- 启动 ---------- */

  setupCanvas();
  initStars();
  updateHud();
  finalScoreOutput.textContent = padScore(0);
  installDebugApi();
  window.addEventListener("resize", setupCanvas);
  requestAnimationFrame(frame);
})();
