/* ============================================================
   深空防线 — 单文件游戏逻辑
   ------------------------------------------------------------
   游戏世界固定为 960 × 600，CSS 只负责缩放画面。
   整局游戏只运行一个 requestAnimationFrame 循环；重新开始
   只重置状态，不会再次注册循环，因此连续重开不会加速。
   ============================================================ */
(() => {
  "use strict";

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");
  const stage = document.getElementById("stage");
  const scoreOutput = document.getElementById("score");
  const killCountOutput = document.getElementById("killCount");
  const livesCount = document.getElementById("livesCount");
  const lifePips = Array.from(document.querySelectorAll(".life-pip"));
  const bossWarningEl = document.getElementById("bossWarning");
  const bossWarningTimer = document.getElementById("bossWarningTimer");
  const bossHud = document.getElementById("bossHud");
  const bossHealthBar = document.getElementById("bossHealthBar");
  const bossHealthFill = document.getElementById("bossHealthFill");
  const bossHpText = document.getElementById("bossHpText");
  const bossPhaseText = document.getElementById("bossPhase");
  const bossStatusText = bossHud ? bossHud.querySelector(".boss-status-text") : null;
  const pauseOverlay = document.getElementById("pauseOverlay");
  const overlay = document.getElementById("gameOverOverlay");
  const outcomeEyebrow = document.getElementById("outcomeEyebrow");
  const gameOverTitle = document.getElementById("gameOverTitle");
  const outcomeSummary = document.getElementById("outcomeSummary");
  const finalLabel = document.getElementById("finalLabel");
  const finalScoreOutput = document.getElementById("finalScore");
  const restartButton = document.getElementById("restartButton");

  if (
    !canvas ||
    !ctx ||
    !stage ||
    !scoreOutput ||
    !killCountOutput ||
    !overlay ||
    !restartButton ||
    !bossWarningEl ||
    !bossWarningTimer ||
    !bossHud ||
    !bossHealthBar ||
    !bossHealthFill ||
    !bossHpText ||
    !bossPhaseText ||
    !pauseOverlay ||
    !outcomeEyebrow ||
    !gameOverTitle ||
    !outcomeSummary ||
    !finalLabel
  ) {
    throw new Error("游戏初始化失败：缺少必要的页面元素。");
  }

  const W = 960;
  const H = 600;
  const MAX_LIVES = 3;
  const PLAYER_SPEED = 390;
  const PLAYER_FIRE_INTERVAL = 0.14;
  const BULLET_SPEED = 760;
  const SCORE_PER_ENEMY = 100;
  const INITIAL_SPAWN_DELAY = 0.55;
  const MIN_SPAWN_INTERVAL = 0.46;
  const PLAYER_HALF_W = 26;
  const PLAYER_HALF_H = 29;
  const INVULNERABLE_TIME = 1.25;
  const MUZZLE_FLASH_TIME = 0.08;
  const TAU = Math.PI * 2;

  const BOSS_KILL_TARGET = 10;
  const BOSS_MAX_HP = 1600;
  const PLAYER_BOSS_DAMAGE = 12;
  const BOSS_REWARD = 5000;
  const BOSS_WARNING_TIME = 2.2;
  const BOSS_ENTRY_TARGET_Y = 142;
  const BOSS_FAN_WARNING_TIME = 0.95;
  const BOSS_LOCK_WARNING_TIME = 1.15;
  const BOSS_LOCK_RADIUS = 56;
  const BOSS_FAN_SPREAD = 0.46;
  const BOSS_FAN_SPREAD_PHASE_TWO = 0.52;
  const BOSS_FAN_SHOTS = 9;
  const BOSS_FAN_SHOTS_PHASE_TWO = 11;
  const BOSS_FAN_BULLET_SPEED = 255;
  const BOSS_FAN_BULLET_SPEED_PHASE_TWO = 285;
  const BOSS_ATTACK_COOLDOWN = 2.65;
  const BOSS_ATTACK_COOLDOWN_PHASE_TWO = 2.2;

  // 左右炮口的唯一坐标来源：飞船局部坐标（机头方向为 -Y）。
  // 绘制炮口和生成子弹都通过 getMuzzleWorldPositions() 从这里换算，
  // 因此横移、侧倾和重开后，子弹出生点始终与对应炮口重合。
  const CANNON_OFFSETS = Object.freeze([
    Object.freeze({ side: "left", x: -13, y: -26 }),
    Object.freeze({ side: "right", x: 13, y: -26 }),
  ]);

  const State = Object.freeze({
    PLAYING: "playing",
    PAUSED: "paused",
    GAME_OVER: "gameover",
  });

  const keys = new Set();
  const stars = [];
  let bullets = [];
  let enemies = [];
  let particles = [];
  let player = createPlayer();
  let state = State.PLAYING;
  let score = 0;
  let lives = MAX_LIVES;
  let elapsed = 0;
  let spawnClock = INITIAL_SPAWN_DELAY;
  let fireClock = 0;
  let muzzleFlashClock = 0;
  let lastShotMuzzles = [];
  let shakeClock = 0;
  let damageFlash = 0;
  let nextEnemyId = 1;
  let lastFrameTime = performance.now();
  let destroyedEnemyCount = 0;
  let bossEncounter = "idle";
  let bossWarningClock = 0;
  let boss = null;
  let bossBullets = [];
  let bossWarnings = [];
  let bossAttackTimer = 0;
  let nextBossAttack = "fan";
  let bossRewardAwarded = false;
  let outcome = null;

  function random(min, max) {
    return min + Math.random() * (max - min);
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function padScore(value) {
    return String(value).padStart(6, "0");
  }

  function formatWarningTime(seconds) {
    const tenths = Math.ceil(Math.max(0, seconds) * 10);
    return `${(tenths / 10).toFixed(1)}s`;
  }

  function circlesRectsOverlap(ax, ay, ahw, ahh, bx, by, bhw, bhh) {
    return Math.abs(ax - bx) < ahw + bhw && Math.abs(ay - by) < ahh + bhh;
  }

  function createPlayer() {
    return {
      x: W / 2,
      y: H - 76,
      tilt: 0,
      invulnerable: 0,
      hitHalfW: 15,
      hitHalfH: 18,
    };
  }

  // 与 Canvas 的 translate(player.x, player.y) + rotate(player.tilt)
  // 使用同一套变换，保证炮口绘制位置和子弹出生点严格一致。
  function getMuzzleWorldPositions() {
    const cos = Math.cos(player.tilt);
    const sin = Math.sin(player.tilt);

    return CANNON_OFFSETS.map((cannon) => ({
      side: cannon.side,
      x: player.x + cannon.x * cos - cannon.y * sin,
      y: player.y + cannon.x * sin + cannon.y * cos,
    }));
  }

  /* ---------- 初始化与画面尺寸 ---------- */

  function initStars() {
    stars.length = 0;
    for (let i = 0; i < 118; i += 1) {
      stars.push({
        x: random(6, W - 6),
        y: random(6, H - 6),
        size: random(0.7, 1.9),
        speed: random(13, 68),
        alpha: random(0.22, 0.82),
        twinkle: random(0, TAU),
        twinkleSpeed: random(0.5, 2.1),
      });
    }
  }

  function setupCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
  }

  function updateHud() {
    scoreOutput.textContent = padScore(score);
    killCountOutput.textContent = String(destroyedEnemyCount).padStart(2, "0");
    livesCount.textContent = String(lives);
    lifePips.forEach((pip, index) => {
      pip.classList.toggle("is-empty", index >= lives);
    });
  }

  function updateBossHud() {
    if (!boss) {
      bossHud.hidden = true;
      return;
    }

    const healthRatio = clamp(boss.hp / boss.maxHp, 0, 1);
    bossHud.hidden = false;
    bossHealthFill.style.width = `${(healthRatio * 100).toFixed(2)}%`;
    bossHpText.textContent = `${Math.ceil(boss.hp)} / ${boss.maxHp}`;
    bossHealthBar.setAttribute("aria-valuemax", String(boss.maxHp));
    bossHealthBar.setAttribute("aria-valuenow", String(Math.ceil(boss.hp)));
    bossPhaseText.textContent = boss.phaseTwo ? "PHASE 2 // LOCK" : "PHASE 1";
    bossHud.classList.toggle("is-phase-two", boss.phaseTwo);

    if (bossStatusText) {
      bossStatusText.textContent = boss.phaseTwo
        ? "锁定协议已启动"
        : "主反应堆在线";
    }
  }

  function resetBossState() {
    destroyedEnemyCount = 0;
    bossEncounter = "idle";
    bossWarningClock = 0;
    boss = null;
    bossBullets = [];
    bossWarnings = [];
    bossAttackTimer = 0;
    nextBossAttack = "fan";
    bossRewardAwarded = false;
    outcome = null;

    bossWarningEl.hidden = true;
    bossWarningTimer.textContent = formatWarningTime(BOSS_WARNING_TIME);
    bossHud.hidden = true;
    bossHud.classList.remove("is-phase-two");
    bossHealthFill.style.width = "100%";
    bossHealthBar.setAttribute("aria-valuemax", String(BOSS_MAX_HP));
    bossHealthBar.setAttribute("aria-valuenow", String(BOSS_MAX_HP));
    bossHpText.textContent = `${BOSS_MAX_HP} / ${BOSS_MAX_HP}`;
    bossPhaseText.textContent = "PHASE 1";
    if (bossStatusText) {
      bossStatusText.textContent = "主反应堆在线";
    }
  }

  /* ---------- 一局的生命周期 ---------- */

  function resetRound() {
    state = State.PLAYING;
    score = 0;
    lives = MAX_LIVES;
    elapsed = 0;
    spawnClock = INITIAL_SPAWN_DELAY;
    fireClock = 0;
    muzzleFlashClock = 0;
    lastShotMuzzles = [];
    shakeClock = 0;
    damageFlash = 0;
    nextEnemyId = 1;
    player = createPlayer();
    bullets = [];
    enemies = [];
    particles = [];
    keys.clear();
    resetBossState();

    overlay.hidden = true;
    overlay.classList.remove("is-victory");
    pauseOverlay.hidden = true;
    stage.classList.remove("is-over", "is-paused");
    outcomeEyebrow.textContent = "MISSION FAILED";
    outcomeEyebrow.classList.add("danger");
    gameOverTitle.textContent = "防线失守";
    outcomeSummary.hidden = true;
    outcomeSummary.textContent = "";
    finalLabel.textContent = "本局得分";
    finalScoreOutput.textContent = padScore(0);
    updateHud();
    lastFrameTime = performance.now();
  }

  function restartGame() {
    resetRound();
    canvas.focus({ preventScroll: true });
  }

  function finishRound(result) {
    if (state === State.GAME_OVER) {
      return;
    }

    state = State.GAME_OVER;
    outcome = result;
    keys.clear();
    shakeClock = 0;
    damageFlash = 0;
    bossWarningEl.hidden = true;
    bossHud.hidden = true;
    pauseOverlay.hidden = true;
    stage.classList.remove("is-paused");

    const won = result === "victory";

    if (won && !bossRewardAwarded) {
      bossRewardAwarded = true;
      score += BOSS_REWARD;
    }

    updateHud();
    overlay.classList.toggle("is-victory", won);
    stage.classList.add("is-over");
    outcomeEyebrow.textContent = won ? "MISSION COMPLETE" : "MISSION FAILED";
    outcomeEyebrow.classList.toggle("danger", !won);
    gameOverTitle.textContent = won ? "防线守住了" : "防线失守";
    outcomeSummary.hidden = !won;
    outcomeSummary.textContent = won
      ? `BOSS 击破奖励 +${BOSS_REWARD}`
      : "";
    finalLabel.textContent = won ? "最终得分" : "本局得分";
    finalScoreOutput.textContent = padScore(score);
    overlay.hidden = false;
    restartButton.focus({ preventScroll: true });
  }

  function resolveRoundOutcome() {
    if (state !== State.PLAYING) {
      return;
    }

    // 同一帧双方归零时，玩家失败优先；Boss 奖励也只在真正胜利时结算。
    if (lives <= 0) {
      finishRound("defeat");
      return;
    }

    if (boss && boss.defeated) {
      finishRound("victory");
    }
  }

  function pauseGame() {
    if (state !== State.PLAYING) {
      return;
    }

    state = State.PAUSED;
    // 暂停只冻结游戏更新，不清空按键状态；暂停期间松开的键仍由 keyup 移除。
    pauseOverlay.hidden = false;
    stage.classList.add("is-paused");
  }

  function resumeGame() {
    if (state !== State.PAUSED) {
      return;
    }

    state = State.PLAYING;
    pauseOverlay.hidden = true;
    stage.classList.remove("is-paused");
    lastFrameTime = performance.now();
    canvas.focus({ preventScroll: true });
  }

  /* ---------- 键盘输入 ---------- */

  function isGameKey(code) {
    return (
      code === "Space" ||
      code.startsWith("Arrow") ||
      code === "KeyW" ||
      code === "KeyA" ||
      code === "KeyS" ||
      code === "KeyD"
    );
  }

  function isPauseKey(code) {
    return code === "KeyP" || code === "Escape";
  }

  function isInteractiveTarget(target) {
    return (
      target instanceof Element &&
      Boolean(target.closest("button, a, input, textarea, select"))
    );
  }

  window.addEventListener("keydown", (event) => {
    const code = event.code;
    const gameKey = isGameKey(code);
    const pauseKey = isPauseKey(code);
    const onControl = isInteractiveTarget(event.target);

    // 阻止方向键滚动页面 / 空格键触发页面滚动。按钮聚焦时保留原生激活。
    if ((gameKey || pauseKey) && !onControl) {
      event.preventDefault();
    }

    if (state === State.GAME_OVER) {
      if ((code === "Enter" || code === "Space") && !onControl) {
        restartGame();
      }
      return;
    }

    if (pauseKey) {
      if (event.repeat) {
        return;
      }

      if (state === State.PLAYING) {
        pauseGame();
      } else if (state === State.PAUSED) {
        resumeGame();
      }
      return;
    }

    if (state === State.PAUSED) {
      return;
    }

    if (gameKey) {
      keys.add(code);
    }
  });

  window.addEventListener("keyup", (event) => {
    // 暂停中也同步松开状态，恢复时不会继续保留已经放开的键。
    keys.delete(event.code);
  });

  window.addEventListener("blur", () => {
    keys.clear();
  });

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      keys.clear();
    }
  });

  restartButton.addEventListener("click", () => {
    restartGame();
  });

  canvas.addEventListener("pointerdown", () => {
    canvas.focus({ preventScroll: true });
  });

  /* ---------- 玩家 ---------- */

  function updatePlayer(dt) {
    const left = keys.has("ArrowLeft") || keys.has("KeyA");
    const right = keys.has("ArrowRight") || keys.has("KeyD");
    const up = keys.has("ArrowUp") || keys.has("KeyW");
    const down = keys.has("ArrowDown") || keys.has("KeyS");

    let dx = Number(right) - Number(left);
    let dy = Number(down) - Number(up);

    if (dx !== 0 && dy !== 0) {
      const diagonal = Math.SQRT1_2;
      dx *= diagonal;
      dy *= diagonal;
    }

    player.x = clamp(
      player.x + dx * PLAYER_SPEED * dt,
      PLAYER_HALF_W + 6,
      W - PLAYER_HALF_W - 6,
    );
    player.y = clamp(
      player.y + dy * PLAYER_SPEED * dt,
      PLAYER_HALF_H + 6,
      H - PLAYER_HALF_H - 6,
    );

    const targetTilt = dx * 0.16;
    const smoothing = 1 - Math.exp(-12 * dt);
    player.tilt += (targetTilt - player.tilt) * smoothing;

    if (player.invulnerable > 0) {
      player.invulnerable = Math.max(0, player.invulnerable - dt);
    }
  }

  function updateShooting(dt) {
    fireClock = Math.max(0, fireClock - dt);

    if (!keys.has("Space") || fireClock > 0) {
      return;
    }

    // 双发等离子弹；任一发命中即可摧毁一架敌机。
    // 每发子弹都从当前帧对应的炮口世界坐标出生。
    const muzzles = getMuzzleWorldPositions();
    lastShotMuzzles = muzzles.map((muzzle) => ({ ...muzzle }));

    for (const muzzle of muzzles) {
      bullets.push({
        x: muzzle.x,
        y: muzzle.y,
        originX: muzzle.x,
        originY: muzzle.y,
        side: muzzle.side,
        vy: -BULLET_SPEED,
        halfW: 2.5,
        halfH: 9,
      });
    }

    muzzleFlashClock = MUZZLE_FLASH_TIME;
    fireClock = PLAYER_FIRE_INTERVAL;
  }

  /* ---------- 敌机 ---------- */

  function createEnemy(options = {}) {
    const speedRamp = Math.min(elapsed * 2.1, 105);
    const startX = clamp(
      options.x ?? random(56, W - 56),
      52,
      W - 52,
    );
    const sway = options.sway ?? random(7, 25);

    return {
      id: nextEnemyId++,
      x: startX,
      baseX: startX,
      y: options.y ?? -38,
      speed: options.speed ?? random(92, 128) + speedRamp,
      sway,
      swayRate: random(1.1, 2.2),
      phase: random(0, TAU),
      age: 0,
      points: SCORE_PER_ENEMY,
      destroyed: false,
      hasHitPlayer: false,
      hitHalfW: 17,
      hitHalfH: 14,
    };
  }

  function spawnEnemy() {
    const enemy = createEnemy();
    enemies.push(enemy);
  }

  function updateSpawner(dt) {
    // 第 10 架普通敌机被击毁后永久停用普通生成器，直到重开。
    if (bossEncounter !== "idle" || destroyedEnemyCount >= BOSS_KILL_TARGET) {
      return;
    }

    spawnClock -= dt;
    if (spawnClock > 0) {
      return;
    }

    spawnEnemy();

    // 难度随时间平缓上升，但每局都会从同样的基础速度与间隔开始。
    const interval = Math.max(
      MIN_SPAWN_INTERVAL,
      0.95 - elapsed * 0.0075,
    );
    spawnClock = interval * random(0.88, 1.12);
  }

  function updateEnemies(dt) {
    for (let i = enemies.length - 1; i >= 0; i -= 1) {
      const enemy = enemies[i];
      enemy.age += dt;
      enemy.y += enemy.speed * dt;
      enemy.x = clamp(
        enemy.baseX + Math.sin(enemy.age * enemy.swayRate + enemy.phase) * enemy.sway,
        20,
        W - 20,
      );

      if (enemy.y - enemy.hitHalfH > H + 34) {
        enemies.splice(i, 1);
      }
    }
  }

  /* ---------- Boss 战 ---------- */

  function beginBossWarning() {
    if (bossEncounter !== "idle") {
      return;
    }

    bossEncounter = "warning";
    bossWarningClock = BOSS_WARNING_TIME;
    bossWarningEl.hidden = false;
    bossWarningTimer.textContent = formatWarningTime(bossWarningClock);
    bossHud.hidden = true;
    // 清空残余普通敌机，预警结束后场上只保留这一架 Boss。
    enemies.length = 0;
  }

  function createBoss() {
    return {
      x: W / 2,
      y: -90,
      targetY: BOSS_ENTRY_TARGET_Y,
      hp: BOSS_MAX_HP,
      maxHp: BOSS_MAX_HP,
      state: "entering",
      phaseTwo: false,
      phaseTransitions: 0,
      age: 0,
      hitHalfW: 92,
      hitHalfH: 47,
      hitFlash: 0,
      muzzleFlash: 0,
      defeated: false,
    };
  }

  function spawnBoss() {
    bossWarningEl.hidden = true;
    bossEncounter = "boss";
    boss = createBoss();
    bossAttackTimer = 1.15;
    updateBossHud();
    burst(W / 2, 54, 32, "#ff7ca2", 210);
    shakeClock = 0.34;
  }

  function enterBossPhaseTwo() {
    if (!boss || boss.phaseTwo || boss.defeated) {
      return;
    }

    boss.phaseTwo = true;
    boss.phaseTransitions += 1;
    nextBossAttack = "lock";
    if (bossWarnings.length === 0) {
      bossAttackTimer = Math.min(bossAttackTimer, 0.7);
    }
    updateBossHud();
    burst(boss.x, boss.y, 36, "#72eeff", 240);
    shakeClock = 0.3;
  }

  function damageBoss(amount) {
    if (!boss || boss.defeated) {
      return;
    }

    boss.hitFlash = 0.14;
    boss.hp = Math.max(0, boss.hp - amount);
    updateBossHud();

    if (!boss.phaseTwo && boss.hp > 0 && boss.hp <= boss.maxHp * 0.5) {
      enterBossPhaseTwo();
    }

    if (boss.hp <= 0) {
      defeatBoss();
    }
  }

  function defeatBoss() {
    if (!boss || boss.defeated) {
      return;
    }

    boss.defeated = true;
    boss.state = "defeated";
    boss.hp = 0;
    updateBossHud();
    burst(boss.x, boss.y, 92, "#ffd37a", 360);
    burst(boss.x, boss.y, 54, "#ff5d94", 290);
    shakeClock = 0.72;
  }

  function startBossFanAttack() {
    if (!boss || boss.state !== "active") {
      return;
    }

    const originX = boss.x;
    const originY = boss.y + 42;
    const straightDown = Math.PI / 2;
    const aimAngle = Math.atan2(player.y - originY, player.x - originX);
    const centerAngle = clamp(aimAngle, straightDown - 0.62, straightDown + 0.62);
    const phaseTwo = boss.phaseTwo;

    bossWarnings.push({
      type: "fan",
      originX,
      originY,
      centerAngle,
      spread: phaseTwo ? BOSS_FAN_SPREAD_PHASE_TWO : BOSS_FAN_SPREAD,
      timer: BOSS_FAN_WARNING_TIME,
      duration: BOSS_FAN_WARNING_TIME,
      shotCount: phaseTwo ? BOSS_FAN_SHOTS_PHASE_TWO : BOSS_FAN_SHOTS,
      bulletSpeed: phaseTwo
        ? BOSS_FAN_BULLET_SPEED_PHASE_TWO
        : BOSS_FAN_BULLET_SPEED,
    });
  }

  function startBossLockAttack() {
    if (!boss || boss.state !== "active") {
      return;
    }

    bossWarnings.push({
      type: "lock",
      x: player.x,
      y: player.y,
      originX: boss.x,
      originY: boss.y + 38,
      radius: BOSS_LOCK_RADIUS,
      timer: BOSS_LOCK_WARNING_TIME,
      duration: BOSS_LOCK_WARNING_TIME,
    });
  }

  function startBossAttack() {
    if (!boss || boss.state !== "active" || boss.defeated) {
      return;
    }

    let attackType = "fan";

    if (boss.phaseTwo) {
      attackType = nextBossAttack === "lock" ? "lock" : "fan";
      nextBossAttack = attackType === "lock" ? "fan" : "lock";
    }

    if (attackType === "lock") {
      startBossLockAttack();
    } else {
      startBossFanAttack();
    }
  }

  function fireBossFan(warning) {
    if (!boss || boss.defeated) {
      return;
    }

    const count = warning.shotCount;
    const lastIndex = Math.max(1, count - 1);

    for (let i = 0; i < count; i += 1) {
      const angle =
        warning.centerAngle -
        warning.spread +
        (warning.spread * 2 * i) / lastIndex;

      bossBullets.push({
        x: warning.originX,
        y: warning.originY,
        vx: Math.cos(angle) * warning.bulletSpeed,
        vy: Math.sin(angle) * warning.bulletSpeed,
        radius: 6.5,
        phaseTwo: boss.phaseTwo,
      });
    }

    boss.muzzleFlash = 0.2;
    burst(warning.originX, warning.originY, 14, "#ff977c", 165);
    bossAttackTimer = boss.phaseTwo
      ? BOSS_ATTACK_COOLDOWN_PHASE_TWO
      : BOSS_ATTACK_COOLDOWN;
  }

  function resolveBossLock(warning) {
    const dx = Math.max(0, Math.abs(player.x - warning.x) - player.hitHalfW);
    const dy = Math.max(0, Math.abs(player.y - warning.y) - player.hitHalfH);
    const insideDanger = dx * dx + dy * dy <= warning.radius * warning.radius;

    burst(warning.x, warning.y, 34, insideDanger ? "#ffd37a" : "#ff8f7a", 280);
    shakeClock = Math.max(shakeClock, 0.34);

    if (insideDanger && player.invulnerable <= 0) {
      damageFlash = Math.max(damageFlash, 0.36);
      loseLife();
    }

    if (boss && !boss.defeated) {
      boss.muzzleFlash = 0.16;
      bossAttackTimer = boss.phaseTwo
        ? BOSS_ATTACK_COOLDOWN_PHASE_TWO
        : BOSS_ATTACK_COOLDOWN;
    }
  }

  function updateBossWarnings(dt) {
    for (let i = bossWarnings.length - 1; i >= 0; i -= 1) {
      const warning = bossWarnings[i];
      warning.timer -= dt;

      if (warning.timer > 0) {
        continue;
      }

      bossWarnings.splice(i, 1);
      if (warning.type === "fan") {
        fireBossFan(warning);
      } else {
        resolveBossLock(warning);
      }
    }
  }

  function updateBossEncounter(dt) {
    if (bossEncounter === "warning") {
      bossWarningClock = Math.max(0, bossWarningClock - dt);
      bossWarningTimer.textContent = formatWarningTime(bossWarningClock);
      if (bossWarningClock <= 0) {
        spawnBoss();
      }
      return;
    }

    if (bossEncounter !== "boss" || !boss || boss.defeated) {
      return;
    }

    boss.age += dt;
    boss.hitFlash = Math.max(0, boss.hitFlash - dt);
    boss.muzzleFlash = Math.max(0, boss.muzzleFlash - dt);

    if (boss.state === "entering") {
      boss.y = Math.min(boss.targetY, boss.y + 178 * dt);
      if (boss.y >= boss.targetY) {
        boss.state = "active";
        bossAttackTimer = 1.15;
      }
      return;
    }

    const sweep = boss.phaseTwo ? 232 : 208;
    boss.x = clamp(
      W / 2 + Math.sin(boss.age * 0.7) * sweep,
      118,
      W - 118,
    );
    boss.y = boss.targetY + Math.sin(boss.age * 1.35) * 9;

    bossAttackTimer = Math.max(0, bossAttackTimer - dt);
    updateBossWarnings(dt);

    if (bossWarnings.length === 0 && bossAttackTimer <= 0) {
      startBossAttack();
    }
  }

  function updateBossBullets(dt) {
    for (let i = bossBullets.length - 1; i >= 0; i -= 1) {
      const shot = bossBullets[i];
      shot.x += shot.vx * dt;
      shot.y += shot.vy * dt;

      if (
        shot.y - shot.radius > H + 32 ||
        shot.x < -36 ||
        shot.x > W + 36 ||
        shot.y < -80
      ) {
        bossBullets.splice(i, 1);
        continue;
      }

      if (
        circlesRectsOverlap(
          player.x,
          player.y,
          player.hitHalfW,
          player.hitHalfH,
          shot.x,
          shot.y,
          shot.radius,
          shot.radius,
        )
      ) {
        bossBullets.splice(i, 1);
        if (player.invulnerable <= 0) {
          loseLife();
        }
      }
    }
  }

  function resolveBossBodyCollision() {
    if (!boss || boss.defeated || player.invulnerable > 0) {
      return;
    }

    if (
      circlesRectsOverlap(
        player.x,
        player.y,
        player.hitHalfW,
        player.hitHalfH,
        boss.x,
        boss.y,
        boss.hitHalfW,
        boss.hitHalfH,
      )
    ) {
      loseLife();
    }
  }

  /* ---------- 子弹与碰撞 ---------- */

  function updateBullets(dt) {
    for (let i = bullets.length - 1; i >= 0; i -= 1) {
      const bullet = bullets[i];
      bullet.y += bullet.vy * dt;

      if (bullet.y + bullet.halfH < -10) {
        bullets.splice(i, 1);
        continue;
      }

      let hitEnemy = false;

      for (let j = enemies.length - 1; j >= 0; j -= 1) {
        const enemy = enemies[j];

        if (
          !enemy.destroyed &&
          circlesRectsOverlap(
            bullet.x,
            bullet.y,
            bullet.halfW,
            bullet.halfH,
            enemy.x,
            enemy.y,
            enemy.hitHalfW,
            enemy.hitHalfH,
          )
        ) {
          // 先锁定结算标记，再把敌机移出数组。即使同帧有两发子弹命中，
          // 同一架敌机也只会结算一次分数和一次击毁数。
          enemy.destroyed = true;
          enemies.splice(j, 1);
          bullets.splice(i, 1);
          hitEnemy = true;
          score += enemy.points;
          destroyedEnemyCount += 1;
          updateHud();
          burst(enemy.x, enemy.y, 16, "#ff719e", 185);

          if (destroyedEnemyCount >= BOSS_KILL_TARGET) {
            beginBossWarning();
          }
          break;
        }
      }

      if (hitEnemy) {
        continue;
      }

      if (
        boss &&
        bossEncounter === "boss" &&
        !boss.defeated &&
        circlesRectsOverlap(
          bullet.x,
          bullet.y,
          bullet.halfW,
          bullet.halfH,
          boss.x,
          boss.y,
          boss.hitHalfW,
          boss.hitHalfH,
        )
      ) {
        bullets.splice(i, 1);
        burst(bullet.x, bullet.y, 7, "#89f7ff", 135);
        damageBoss(PLAYER_BOSS_DAMAGE);
      }
    }
  }

  function resolvePlayerCollisions() {
    for (let i = enemies.length - 1; i >= 0; i -= 1) {
      const enemy = enemies[i];

      if (enemy.hasHitPlayer) {
        continue;
      }

      const touchesPlayer = circlesRectsOverlap(
        player.x,
        player.y,
        player.hitHalfW,
        player.hitHalfH,
        enemy.x,
        enemy.y,
        enemy.hitHalfW,
        enemy.hitHalfH,
      );

      if (!touchesPlayer) {
        continue;
      }

      // 每架敌机只允许触发一次碰撞结算，并立即从场上移除。
      enemy.hasHitPlayer = true;
      enemies.splice(i, 1);
      burst(enemy.x, enemy.y, 10, "#ff9c7a", 135);

      if (player.invulnerable <= 0) {
        loseLife();
      }
    }
  }

  function loseLife() {
    lives = Math.max(0, lives - 1);
    player.invulnerable = INVULNERABLE_TIME;
    shakeClock = 0.34;
    damageFlash = 0.5;
    updateHud();
    burst(player.x, player.y, 24, "#ffd37a", 245);
    // 胜负在整帧更新末尾统一结算，以保证同帧双方归零时失败优先。
  }

  /* ---------- 粒子与背景 ---------- */

  function burst(x, y, count, color, power) {
    for (let i = 0; i < count; i += 1) {
      const angle = random(0, TAU);
      const speed = random(power * 0.25, power);
      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: random(0.28, 0.72),
        maxLife: 0.72,
        size: random(1.2, 3.4),
        color,
      });
    }
  }

  function updateParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i -= 1) {
      const particle = particles[i];
      particle.life -= dt;
      if (particle.life <= 0) {
        particles.splice(i, 1);
        continue;
      }

      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= Math.pow(0.18, dt);
      particle.vy *= Math.pow(0.18, dt);
    }
  }

  function updateStars(dt) {
    for (const star of stars) {
      star.y += star.speed * dt;
      if (star.y > H + 4) {
        star.y = -4;
        star.x = random(6, W - 6);
      }
    }
  }

  function updateEffects(dt) {
    shakeClock = Math.max(0, shakeClock - dt);
    damageFlash = Math.max(0, damageFlash - dt);
    muzzleFlashClock = Math.max(0, muzzleFlashClock - dt);
  }

  /* ---------- 主更新 ---------- */

  function update(dt) {
    elapsed += dt;
    updateStars(dt);
    updateEffects(dt);
    updatePlayer(dt);
    updateShooting(dt);
    updateSpawner(dt);
    updateEnemies(dt);
    updateBossEncounter(dt);
    updateBossBullets(dt);
    updateBullets(dt);
    resolvePlayerCollisions();
    resolveBossBodyCollision();

    if (state === State.PLAYING) {
      updateParticles(dt);
      resolveRoundOutcome();
    }
  }

  /* ---------- 绘制 ---------- */

  function drawBackdrop() {
    const sky = ctx.createLinearGradient(0, 0, 0, H);
    sky.addColorStop(0, "#06121f");
    sky.addColorStop(0.45, "#04101a");
    sky.addColorStop(1, "#040a12");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    const nebulaA = ctx.createRadialGradient(
      W * 0.16,
      H * 0.18,
      8,
      W * 0.16,
      H * 0.18,
      W * 0.48,
    );
    nebulaA.addColorStop(0, "rgba(31, 139, 164, 0.13)");
    nebulaA.addColorStop(0.45, "rgba(20, 102, 140, 0.055)");
    nebulaA.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = nebulaA;
    ctx.fillRect(0, 0, W, H);

    const nebulaB = ctx.createRadialGradient(
      W * 0.86,
      H * 0.74,
      10,
      W * 0.86,
      H * 0.74,
      W * 0.42,
    );
    nebulaB.addColorStop(0, "rgba(137, 40, 97, 0.09)");
    nebulaB.addColorStop(0.55, "rgba(93, 30, 84, 0.035)");
    nebulaB.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = nebulaB;
    ctx.fillRect(0, 0, W, H);

    // 极淡的坐标网格，给驾驶舱一点仪表感。
    ctx.strokeStyle = "rgba(115, 219, 255, 0.045)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 120; x < W; x += 120) {
      ctx.moveTo(x + 0.5, 0);
      ctx.lineTo(x + 0.5, H);
    }
    for (let y = 100; y < H; y += 100) {
      ctx.moveTo(0, y + 0.5);
      ctx.lineTo(W, y + 0.5);
    }
    ctx.stroke();

    // 顶部微光，暗示敌方来袭方向。
    const topGlow = ctx.createLinearGradient(0, 0, 0, 130);
    topGlow.addColorStop(0, "rgba(255, 93, 148, 0.075)");
    topGlow.addColorStop(1, "rgba(255, 93, 148, 0)");
    ctx.fillStyle = topGlow;
    ctx.fillRect(0, 0, W, 130);
  }

  function drawStars() {
    ctx.save();
    for (const star of stars) {
      const flicker =
        0.68 + 0.32 * Math.sin(elapsed * star.twinkleSpeed + star.twinkle);
      ctx.globalAlpha = star.alpha * flicker;
      ctx.fillStyle = star.speed > 45 ? "#c8f6ff" : "#a9c8dd";
      ctx.fillRect(star.x, star.y, star.size, star.size);
    }
    ctx.restore();
  }

  // 炮口挂架：先画在机身下方，让机身盖住根部，形成连接结构。
  function drawCannonPylons() {
    ctx.save();
    for (const cannon of CANNON_OFFSETS) {
      const inward = Math.sign(cannon.x);

      ctx.beginPath();
      ctx.moveTo(inward * 6, -4);
      ctx.lineTo(cannon.x, -13);
      ctx.lineTo(cannon.x, -8.5);
      ctx.lineTo(inward * 9, -1);
      ctx.closePath();
      ctx.fillStyle = "#081b26";
      ctx.fill();
      ctx.strokeStyle = "rgba(114, 238, 255, 0.38)";
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.restore();
  }

  // 双炮管与发光炮口。炮口圆心就是 CANNON_OFFSETS 的局部坐标，
  // 与 getMuzzleWorldPositions() 换算出的子弹出生点完全对应。
  function drawCannonBarrels() {
    ctx.save();
    for (const cannon of CANNON_OFFSETS) {
      const { x, y } = cannon;
      const baseY = -5.5;

      ctx.beginPath();
      ctx.moveTo(x - 3.4, baseY);
      ctx.lineTo(x - 3.4, y + 2.2);
      ctx.lineTo(x - 2.1, y);
      ctx.lineTo(x + 2.1, y);
      ctx.lineTo(x + 3.4, y + 2.2);
      ctx.lineTo(x + 3.4, baseY);
      ctx.closePath();
      ctx.fillStyle = "#0a1d28";
      ctx.fill();
      ctx.strokeStyle = "rgba(124, 239, 255, 0.72)";
      ctx.lineWidth = 1.1;
      ctx.stroke();

      ctx.strokeStyle = "rgba(114, 238, 255, 0.28)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x - 1.2, baseY - 2);
      ctx.lineTo(x - 1.2, y + 5);
      ctx.moveTo(x + 1.2, baseY - 2);
      ctx.lineTo(x + 1.2, y + 5);
      ctx.stroke();

      // 炮口环、暗色膛口与轻微呼吸光，保证静止时也能清楚看见左右炮口。
      const pulse = 0.72 + 0.28 * Math.sin(elapsed * 12 + (x > 0 ? 1.5 : 0));
      ctx.save();
      ctx.shadowColor = "#8cf5ff";
      ctx.shadowBlur = 12;
      ctx.fillStyle = "#03121a";
      ctx.beginPath();
      ctx.arc(x, y, 4.2, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "#bafaff";
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.fillStyle = `rgba(188, 252, 255, ${pulse})`;
      ctx.beginPath();
      ctx.arc(x, y, 1.55, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }

  function drawMuzzleFlash() {
    if (muzzleFlashClock <= 0) {
      return;
    }

    const alpha = Math.min(1, muzzleFlashClock / MUZZLE_FLASH_TIME);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";

    for (const cannon of CANNON_OFFSETS) {
      const { x, y } = cannon;
      const plume = 10 + alpha * 9;
      const flare = ctx.createLinearGradient(x, y, x, y - plume);
      flare.addColorStop(0, `rgba(224, 255, 255, ${0.95 * alpha})`);
      flare.addColorStop(0.45, `rgba(114, 238, 255, ${0.62 * alpha})`);
      flare.addColorStop(1, "rgba(114, 238, 255, 0)");
      ctx.fillStyle = flare;
      ctx.beginPath();
      ctx.ellipse(x, y - plume * 0.45, 4.4, plume * 0.55, 0, 0, TAU);
      ctx.fill();
    }

    ctx.restore();
  }

  function drawPlayer() {
    if (lives <= 0) {
      return;
    }

    const blinking =
      player.invulnerable > 0 && Math.floor(player.invulnerable * 16) % 2 === 0;

    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.rotate(player.tilt);
    ctx.globalAlpha = blinking ? 0.36 : 1;

    // 尾焰
    const flame = 17 + Math.sin(elapsed * 44) * 4;
    const flameGradient = ctx.createLinearGradient(0, 20, 0, 25 + flame);
    flameGradient.addColorStop(0, "rgba(202, 253, 255, 0.95)");
    flameGradient.addColorStop(0.5, "rgba(98, 230, 255, 0.8)");
    flameGradient.addColorStop(1, "rgba(43, 116, 255, 0)");
    ctx.fillStyle = flameGradient;
    ctx.beginPath();
    ctx.moveTo(-7, 20);
    ctx.lineTo(7, 20);
    ctx.lineTo(0, 25 + flame);
    ctx.closePath();
    ctx.fill();

    drawCannonPylons();

    // 机翼与机身
    const hullPath = new Path2D();
    hullPath.moveTo(0, -29);
    hullPath.lineTo(6, -16);
    hullPath.lineTo(9, -6);
    hullPath.lineTo(20, 8);
    hullPath.lineTo(27, 17);
    hullPath.lineTo(14, 13);
    hullPath.lineTo(9, 22);
    hullPath.lineTo(4, 26);
    hullPath.lineTo(-4, 26);
    hullPath.lineTo(-9, 22);
    hullPath.lineTo(-14, 13);
    hullPath.lineTo(-27, 17);
    hullPath.lineTo(-20, 8);
    hullPath.lineTo(-9, -6);
    hullPath.lineTo(-6, -16);
    hullPath.closePath();

    ctx.save();
    ctx.shadowColor = "rgba(114, 238, 255, 0.85)";
    ctx.shadowBlur = 18;
    ctx.fillStyle = "#0b2633";
    ctx.fill(hullPath);
    ctx.restore();

    ctx.strokeStyle = "#7cefff";
    ctx.lineWidth = 1.7;
    ctx.stroke(hullPath);

    ctx.strokeStyle = "rgba(114, 238, 255, 0.45)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-19, 9);
    ctx.lineTo(-8, 3);
    ctx.moveTo(19, 9);
    ctx.lineTo(8, 3);
    ctx.moveTo(0, -24);
    ctx.lineTo(0, 16);
    ctx.stroke();

    const cockpit = ctx.createLinearGradient(0, -14, 0, 5);
    cockpit.addColorStop(0, "#d9ffff");
    cockpit.addColorStop(0.5, "#72eeff");
    cockpit.addColorStop(1, "#1e6b89");
    ctx.fillStyle = cockpit;
    ctx.beginPath();
    ctx.ellipse(0, -7, 4.2, 9, 0, 0, TAU);
    ctx.fill();

    ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
    ctx.beginPath();
    ctx.ellipse(-1.2, -10, 1.2, 3.2, -0.25, 0, TAU);
    ctx.fill();

    drawCannonBarrels();
    drawMuzzleFlash();

    ctx.restore();

    // 受击后的短暂护盾环。
    if (player.invulnerable > 0) {
      const shieldAlpha = 0.2 + Math.sin(elapsed * 18) * 0.08;
      ctx.save();
      ctx.strokeStyle = `rgba(114, 238, 255, ${shieldAlpha})`;
      ctx.lineWidth = 1;
      ctx.setLineDash([7, 9]);
      ctx.beginPath();
      ctx.arc(player.x, player.y, 33, 0, TAU);
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawEnemies() {
    for (const enemy of enemies) {
      const glowColor = enemy.id % 2 === 0 ? "#ff789f" : "#ff977c";
      const rotation = Math.sin(enemy.age * 2.2 + enemy.phase) * 0.08;

      ctx.save();
      ctx.translate(enemy.x, enemy.y);
      ctx.rotate(rotation);
      ctx.shadowColor = glowColor;
      ctx.shadowBlur = 14;

      const body = new Path2D();
      body.moveTo(0, 17);
      body.lineTo(9, 8);
      body.lineTo(21, 4);
      body.lineTo(15, -3);
      body.lineTo(20, -11);
      body.lineTo(7, -8);
      body.lineTo(0, -16);
      body.lineTo(-7, -8);
      body.lineTo(-20, -11);
      body.lineTo(-15, -3);
      body.lineTo(-21, 4);
      body.lineTo(-9, 8);
      body.closePath();

      ctx.fillStyle = "#260b19";
      ctx.fill(body);
      ctx.strokeStyle = glowColor;
      ctx.lineWidth = 1.5;
      ctx.stroke(body);

      ctx.shadowBlur = 0;
      ctx.strokeStyle = "rgba(255, 132, 165, 0.54)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-13, -1);
      ctx.lineTo(13, -1);
      ctx.moveTo(-9, 9);
      ctx.lineTo(9, 9);
      ctx.stroke();

      const eye = ctx.createRadialGradient(0, 1, 0, 0, 1, 6);
      eye.addColorStop(0, "#fff0b8");
      eye.addColorStop(0.35, "#ffd37a");
      eye.addColorStop(1, "rgba(255, 93, 148, 0)");
      ctx.fillStyle = eye;
      ctx.beginPath();
      ctx.arc(0, 1, 6, 0, TAU);
      ctx.fill();

      ctx.fillStyle = "#fff6d6";
      ctx.beginPath();
      ctx.arc(0, 1, 1.8, 0, TAU);
      ctx.fill();

      ctx.restore();
    }
  }

  function drawBossWarnings() {
    if (bossWarnings.length === 0) {
      return;
    }

    ctx.save();

    for (const warning of bossWarnings) {
      const remaining = clamp(warning.timer / warning.duration, 0, 1);
      const urgency = 1 - remaining;
      const pulse = 0.72 + Math.sin(elapsed * 23) * 0.18;

      if (warning.type === "fan") {
        const radius = 860;
        ctx.save();
        ctx.translate(warning.originX, warning.originY);

        const fanGradient = ctx.createRadialGradient(0, 0, 20, 0, 0, 640);
        fanGradient.addColorStop(
          0,
          `rgba(255, 93, 148, ${0.2 + urgency * 0.09})`,
        );
        fanGradient.addColorStop(
          0.55,
          `rgba(255, 113, 158, ${0.1 + urgency * 0.06})`,
        );
        fanGradient.addColorStop(1, "rgba(255, 93, 148, 0)");

        ctx.fillStyle = fanGradient;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(
          0,
          0,
          radius,
          warning.centerAngle - warning.spread,
          warning.centerAngle + warning.spread,
        );
        ctx.closePath();
        ctx.fill();

        ctx.setLineDash([8, 9]);
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = `rgba(255, 146, 172, ${0.48 + pulse * 0.28})`;

        for (const edge of [-warning.spread, warning.spread]) {
          const angle = warning.centerAngle + edge;
          ctx.beginPath();
          ctx.moveTo(Math.cos(angle) * 24, Math.sin(angle) * 24);
          ctx.lineTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
          ctx.stroke();
        }

        ctx.setLineDash([2, 10]);
        ctx.strokeStyle = `rgba(255, 211, 122, ${0.34 + pulse * 0.22})`;
        ctx.beginPath();
        ctx.moveTo(Math.cos(warning.centerAngle) * 24, Math.sin(warning.centerAngle) * 24);
        ctx.lineTo(
          Math.cos(warning.centerAngle) * radius,
          Math.sin(warning.centerAngle) * radius,
        );
        ctx.stroke();

        ctx.setLineDash([]);
        ctx.lineWidth = 2;
        ctx.strokeStyle = `rgba(255, 160, 182, ${0.62 + pulse * 0.25})`;
        ctx.beginPath();
        ctx.arc(0, 0, 28, -Math.PI / 2, -Math.PI / 2 + TAU * remaining);
        ctx.stroke();

        const labelX = Math.cos(warning.centerAngle) * 235;
        const labelY = Math.sin(warning.centerAngle) * 235;
        ctx.fillStyle = "rgba(255, 186, 202, 0.86)";
        ctx.font = '600 10px "SFMono-Regular", Consolas, monospace';
        ctx.textAlign = "center";
        ctx.fillText("DANGER FAN / 危险扇区", labelX, labelY);
        ctx.fillStyle = "rgba(255, 222, 164, 0.96)";
        ctx.font = '700 15px "SFMono-Regular", Consolas, monospace';
        ctx.fillText(`T-${formatWarningTime(warning.timer)}`, labelX, labelY + 20);
        ctx.restore();
        continue;
      }

      const progress = 1 - remaining;
      const lockGradient = ctx.createRadialGradient(
        warning.x,
        warning.y,
        0,
        warning.x,
        warning.y,
        warning.radius,
      );
      lockGradient.addColorStop(0, `rgba(255, 211, 122, ${0.08 + urgency * 0.15})`);
      lockGradient.addColorStop(0.65, `rgba(255, 93, 148, ${0.08 + urgency * 0.12})`);
      lockGradient.addColorStop(1, "rgba(255, 93, 148, 0)");

      ctx.fillStyle = lockGradient;
      ctx.beginPath();
      ctx.arc(warning.x, warning.y, warning.radius, 0, TAU);
      ctx.fill();

      ctx.save();
      ctx.translate(warning.x, warning.y);

      ctx.setLineDash([6, 7]);
      ctx.lineWidth = 1.4;
      ctx.strokeStyle = `rgba(255, 155, 181, ${0.55 + pulse * 0.25})`;
      ctx.beginPath();
      ctx.arc(0, 0, warning.radius, 0, TAU);
      ctx.stroke();

      ctx.setLineDash([]);
      ctx.lineWidth = 2;
      ctx.strokeStyle = `rgba(255, 211, 122, ${0.48 + urgency * 0.36})`;
      ctx.beginPath();
      ctx.arc(
        0,
        0,
        warning.radius - 9,
        -Math.PI / 2,
        -Math.PI / 2 + TAU * progress,
      );
      ctx.stroke();

      ctx.strokeStyle = `rgba(255, 155, 181, ${0.45 + pulse * 0.25})`;
      ctx.lineWidth = 1;
      const cross = warning.radius + 15;
      ctx.beginPath();
      ctx.moveTo(-cross, 0);
      ctx.lineTo(-24, 0);
      ctx.moveTo(24, 0);
      ctx.lineTo(cross, 0);
      ctx.moveTo(0, -cross);
      ctx.lineTo(0, -24);
      ctx.moveTo(0, 24);
      ctx.lineTo(0, cross);
      ctx.stroke();

      ctx.fillStyle = `rgba(255, 224, 168, ${0.72 + pulse * 0.18})`;
      ctx.beginPath();
      ctx.arc(0, 0, 3.5, 0, TAU);
      ctx.fill();

      ctx.fillStyle = "rgba(255, 206, 181, 0.9)";
      ctx.font = '600 10px "SFMono-Regular", Consolas, monospace';
      ctx.textAlign = "center";
      ctx.fillText("LOCKED / 锁定", 0, -warning.radius - 28);
      ctx.fillStyle = "rgba(255, 226, 170, 0.96)";
      ctx.font = '700 15px "SFMono-Regular", Consolas, monospace';
      ctx.fillText(`T-${formatWarningTime(warning.timer)}`, 0, -warning.radius - 46);
      ctx.restore();

      ctx.setLineDash([3, 9]);
      ctx.strokeStyle = `rgba(255, 132, 165, ${0.24 + pulse * 0.2})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(warning.originX, warning.originY);
      ctx.lineTo(warning.x, warning.y);
      ctx.stroke();
    }

    ctx.restore();
  }

  function drawBoss() {
    if (!boss || boss.defeated) {
      return;
    }

    ctx.save();
    ctx.translate(boss.x, boss.y);
    ctx.shadowColor = boss.phaseTwo ? "#72eeff" : "#ff5d94";
    ctx.shadowBlur = boss.phaseTwo ? 32 : 26;

    const body = new Path2D();
    body.moveTo(-104, 8);
    body.lineTo(-72, -16);
    body.lineTo(-47, -36);
    body.lineTo(-20, -46);
    body.lineTo(0, -40);
    body.lineTo(20, -46);
    body.lineTo(47, -36);
    body.lineTo(72, -16);
    body.lineTo(104, 8);
    body.lineTo(66, 27);
    body.lineTo(42, 43);
    body.lineTo(0, 31);
    body.lineTo(-42, 43);
    body.lineTo(-66, 27);
    body.closePath();

    const hull = ctx.createLinearGradient(0, -48, 0, 44);
    hull.addColorStop(0, "#2b0c21");
    hull.addColorStop(0.52, "#180d1d");
    hull.addColorStop(1, "#0b1420");
    ctx.fillStyle = hull;
    ctx.fill(body);

    ctx.strokeStyle = boss.phaseTwo ? "#7df4ff" : "#ff719d";
    ctx.lineWidth = 2;
    ctx.stroke(body);

    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(255, 177, 198, 0.28)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-77, 11);
    ctx.lineTo(-35, 2);
    ctx.lineTo(0, 14);
    ctx.lineTo(35, 2);
    ctx.lineTo(77, 11);
    ctx.moveTo(-50, -23);
    ctx.lineTo(-28, -9);
    ctx.lineTo(0, -23);
    ctx.lineTo(28, -9);
    ctx.lineTo(50, -23);
    ctx.stroke();

    ctx.fillStyle = "rgba(8, 19, 29, 0.88)";
    ctx.strokeStyle = "rgba(255, 137, 164, 0.38)";
    for (const side of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(side * 58, -19);
      ctx.lineTo(side * 91, 1);
      ctx.lineTo(side * 72, 18);
      ctx.lineTo(side * 50, 6);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = "rgba(255, 119, 150, 0.62)";
      ctx.fillRect(side * 67 - 4, 23, 8, 10);
      ctx.fillStyle = "#ffd37a";
      ctx.beginPath();
      ctx.arc(side * 67, 34, 3.1, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(8, 19, 29, 0.88)";
    }

    for (const engineX of [-68, -38, 0, 38, 68]) {
      const engineGlow = ctx.createRadialGradient(
        engineX,
        -33,
        0,
        engineX,
        -33,
        10,
      );
      engineGlow.addColorStop(0, "rgba(255, 227, 164, 0.9)");
      engineGlow.addColorStop(0.38, "rgba(255, 146, 130, 0.48)");
      engineGlow.addColorStop(1, "rgba(255, 93, 148, 0)");
      ctx.fillStyle = engineGlow;
      ctx.beginPath();
      ctx.arc(engineX, -33, 10, 0, TAU);
      ctx.fill();
    }

    const coreRadius = 17 + Math.sin(elapsed * 5.4) * 2.4;
    const coreColor = boss.phaseTwo ? "#72eeff" : "#ffd37a";
    const core = ctx.createRadialGradient(0, 8, 0, 0, 8, coreRadius + 12);
    core.addColorStop(0, "#ffffff");
    core.addColorStop(0.22, coreColor);
    core.addColorStop(0.54, boss.phaseTwo ? "rgba(85, 228, 255, 0.55)" : "rgba(255, 93, 148, 0.68)");
    core.addColorStop(1, "rgba(255, 93, 148, 0)");

    ctx.fillStyle = core;
    ctx.beginPath();
    ctx.arc(0, 8, coreRadius + 12, 0, TAU);
    ctx.fill();

    ctx.strokeStyle = boss.phaseTwo ? "#c9fdff" : "#fff0c2";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(0, 8, coreRadius, 0, TAU);
    ctx.stroke();

    ctx.fillStyle = "#fff8df";
    ctx.beginPath();
    ctx.arc(0, 8, 5.2, 0, TAU);
    ctx.fill();

    if (boss.phaseTwo) {
      ctx.strokeStyle = "rgba(114, 238, 255, 0.78)";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 5]);
      ctx.beginPath();
      ctx.arc(0, 8, 29, 0, TAU);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    ctx.fillStyle = "#0a1a27";
    ctx.strokeStyle = "rgba(255, 145, 169, 0.56)";
    ctx.lineWidth = 1;
    for (const cannonX of [-44, 0, 44]) {
      ctx.fillRect(cannonX - 4, 26, 8, 13);
      ctx.strokeRect(cannonX - 4, 26, 8, 13);
      ctx.fillStyle = boss.phaseTwo ? "#b9fdff" : "#ffd37a";
      ctx.beginPath();
      ctx.arc(cannonX, 39, 2.8, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#0a1a27";
    }

    if (boss.muzzleFlash > 0) {
      const flashAlpha = clamp(boss.muzzleFlash / 0.2, 0, 1);
      ctx.globalAlpha = flashAlpha;
      ctx.fillStyle = boss.phaseTwo ? "#bffbff" : "#ffe0a3";
      for (const cannonX of [-44, 0, 44]) {
        ctx.beginPath();
        ctx.arc(cannonX, 41, 9 + flashAlpha * 4, 0, TAU);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    if (boss.hitFlash > 0) {
      ctx.globalAlpha = clamp(boss.hitFlash / 0.14, 0, 1) * 0.28;
      ctx.fillStyle = "#ffffff";
      ctx.fill(body);
      ctx.globalAlpha = 1;
    }

    ctx.restore();
  }

  function drawBossBullets() {
    if (bossBullets.length === 0) {
      return;
    }

    ctx.save();
    ctx.shadowColor = "#ff6d86";
    ctx.shadowBlur = 14;

    for (const shot of bossBullets) {
      const speed = Math.hypot(shot.vx, shot.vy) || 1;
      const tailX = shot.x - (shot.vx / speed) * 18;
      const tailY = shot.y - (shot.vy / speed) * 18;
      const tail = ctx.createLinearGradient(tailX, tailY, shot.x, shot.y);
      tail.addColorStop(0, "rgba(255, 93, 148, 0)");
      tail.addColorStop(1, "rgba(255, 211, 122, 0.76)");

      ctx.strokeStyle = tail;
      ctx.lineWidth = 4;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(tailX, tailY);
      ctx.lineTo(shot.x, shot.y);
      ctx.stroke();

      const orb = ctx.createRadialGradient(
        shot.x,
        shot.y,
        0,
        shot.x,
        shot.y,
        shot.radius + 4,
      );
      orb.addColorStop(0, "#fff9e8");
      orb.addColorStop(0.35, shot.phaseTwo ? "#ffb4ef" : "#ffd37a");
      orb.addColorStop(0.72, "#ff5d94");
      orb.addColorStop(1, "rgba(255, 93, 148, 0)");
      ctx.fillStyle = orb;
      ctx.beginPath();
      ctx.arc(shot.x, shot.y, shot.radius + 4, 0, TAU);
      ctx.fill();
    }

    ctx.restore();
  }

  function drawBullets() {
    ctx.save();
    ctx.shadowColor = "#89f7ff";
    ctx.shadowBlur = 12;
    for (const bullet of bullets) {
      const gradient = ctx.createLinearGradient(
        0,
        bullet.y - 15,
        0,
        bullet.y + 10,
      );
      gradient.addColorStop(0, "rgba(137, 247, 255, 0)");
      gradient.addColorStop(0.4, "#89f7ff");
      gradient.addColorStop(1, "#ffffff");
      ctx.fillStyle = gradient;
      ctx.fillRect(bullet.x - 1.8, bullet.y - 12, 3.6, 22);
    }
    ctx.restore();
  }

  function drawParticles() {
    ctx.save();
    for (const particle of particles) {
      const alpha = clamp(particle.life / particle.maxLife, 0, 1);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = particle.color;
      ctx.fillRect(
        particle.x - particle.size / 2,
        particle.y - particle.size / 2,
        particle.size,
        particle.size,
      );
    }
    ctx.restore();
  }

  function drawDamageFlash() {
    if (damageFlash <= 0 || state !== State.PLAYING) {
      return;
    }

    const flash = ctx.createRadialGradient(
      W / 2,
      H / 2,
      H * 0.2,
      W / 2,
      H / 2,
      H * 0.78,
    );
    flash.addColorStop(0, "rgba(255, 70, 120, 0)");
    flash.addColorStop(1, `rgba(255, 70, 120, ${damageFlash * 0.48})`);
    ctx.fillStyle = flash;
    ctx.fillRect(0, 0, W, H);
  }

  function render() {
    ctx.clearRect(0, 0, W, H);
    drawBackdrop();
    drawStars();

    ctx.save();
    if (state === State.PLAYING && shakeClock > 0) {
      const strength = shakeClock * 16;
      ctx.translate(random(-strength, strength), random(-strength, strength));
    }

    drawBossWarnings();
    drawEnemies();
    drawBoss();
    drawBossBullets();
    drawBullets();
    drawParticles();
    drawPlayer();
    ctx.restore();

    drawDamageFlash();
  }

  /* ---------- 动画循环（全局唯一） ---------- */

  function frame(now) {
    const dt = Math.min(Math.max((now - lastFrameTime) / 1000, 0), 1 / 30);
    lastFrameTime = now;

    if (state === State.PLAYING) {
      update(dt);
    }

    render();
    requestAnimationFrame(frame);
  }

  /* ---------- 自动化验收接口（仅在 ?debug=1 时开启） ---------- */

  function installDebugApi() {
    const enabled = new URLSearchParams(window.location.search).has("debug");
    if (!enabled) {
      return;
    }

    window.__SPACE_SHOOTER_DEBUG__ = Object.freeze({
      snapshot() {
        return {
          state,
          score,
          lives,
          elapsed: Number(elapsed.toFixed(4)),
          spawnClock: Number(spawnClock.toFixed(4)),
          player: {
            x: Number(player.x.toFixed(2)),
            y: Number(player.y.toFixed(2)),
            tilt: Number(player.tilt.toFixed(4)),
            invulnerable: Number(player.invulnerable.toFixed(3)),
          },
          muzzles: getMuzzleWorldPositions().map((muzzle) => ({
            side: muzzle.side,
            x: Number(muzzle.x.toFixed(2)),
            y: Number(muzzle.y.toFixed(2)),
          })),
          lastShotMuzzles: lastShotMuzzles.map((muzzle) => ({
            side: muzzle.side,
            x: Number(muzzle.x.toFixed(2)),
            y: Number(muzzle.y.toFixed(2)),
          })),
          enemies: enemies.map((enemy) => ({
            id: enemy.id,
            x: Number(enemy.x.toFixed(2)),
            y: Number(enemy.y.toFixed(2)),
            speed: Number(enemy.speed.toFixed(2)),
            destroyed: enemy.destroyed,
            hasHitPlayer: enemy.hasHitPlayer,
          })),
          bullets: bullets.map((bullet) => ({
            x: Number(bullet.x.toFixed(2)),
            y: Number(bullet.y.toFixed(2)),
            side: bullet.side ?? null,
            originX:
              bullet.originX === undefined ? null : Number(bullet.originX.toFixed(2)),
            originY:
              bullet.originY === undefined ? null : Number(bullet.originY.toFixed(2)),
          })),
          destroyedEnemyCount,
          bossEncounter,
          bossWarningClock: Number(bossWarningClock.toFixed(3)),
          bossWarningVisible: !bossWarningEl.hidden,
          bossWarningTimerText: bossWarningTimer.textContent,
          bossHudVisible: !bossHud.hidden,
          paused: state === State.PAUSED,
          pauseOverlayVisible: !pauseOverlay.hidden,
          bossRewardAwarded,
          outcome,
          boss: boss
            ? {
                x: Number(boss.x.toFixed(2)),
                y: Number(boss.y.toFixed(2)),
                hp: Number(boss.hp.toFixed(2)),
                maxHp: boss.maxHp,
                state: boss.state,
                phaseTwo: boss.phaseTwo,
                phaseTransitions: boss.phaseTransitions,
                defeated: boss.defeated,
                hitHalfW: boss.hitHalfW,
                hitHalfH: boss.hitHalfH,
              }
            : null,
          bossWarnings: bossWarnings.map((warning) => ({
            type: warning.type,
            timer: Number(warning.timer.toFixed(3)),
            duration: warning.duration,
            x: warning.x === undefined ? null : Number(warning.x.toFixed(2)),
            y: warning.y === undefined ? null : Number(warning.y.toFixed(2)),
            originX: Number(warning.originX.toFixed(2)),
            originY: Number(warning.originY.toFixed(2)),
            centerAngle:
              warning.centerAngle === undefined
                ? null
                : Number(warning.centerAngle.toFixed(4)),
            spread: warning.spread ?? null,
            radius: warning.radius ?? null,
            shotCount: warning.shotCount ?? null,
          })),
          bossBullets: bossBullets.map((shot) => ({
            x: Number(shot.x.toFixed(2)),
            y: Number(shot.y.toFixed(2)),
            vx: Number(shot.vx.toFixed(2)),
            vy: Number(shot.vy.toFixed(2)),
          })),
          killCountText: killCountOutput.textContent,
          overlayVisible: !overlay.hidden,
          overlayVictory: overlay.classList.contains("is-victory"),
          overlayTitle: gameOverTitle.textContent,
          outcomeSummaryVisible: !outcomeSummary.hidden,
          finalScore: finalScoreOutput.textContent,
        };
      },
      spawnEnemyAt(x, y, options = {}) {
        if (state !== State.PLAYING) {
          return null;
        }
        const enemy = createEnemy({
          x,
          y,
          speed: options.speed ?? 0,
          sway: options.sway ?? 0,
        });
        enemies.push(enemy);
        return enemy.id;
      },
      spawnBulletAt(x, y, vy = -BULLET_SPEED) {
        if (state !== State.PLAYING) {
          return false;
        }
        bullets.push({ x, y, vy, halfW: 2.5, halfH: 9 });
        return true;
      },
      setPlayerPosition(x, y) {
        player.x = clamp(x, PLAYER_HALF_W + 6, W - PLAYER_HALF_W - 6);
        player.y = clamp(y, PLAYER_HALF_H + 6, H - PLAYER_HALF_H - 6);
      },
      setLives(value) {
        lives = clamp(Math.round(value), 0, MAX_LIVES);
        updateHud();
      },
      setInvulnerable(seconds) {
        player.invulnerable = Math.max(0, seconds);
      },
      spawnBossNow() {
        if (state !== State.PLAYING) {
          return false;
        }
        bossWarningEl.hidden = true;
        bossEncounter = "boss";
        boss = createBoss();
        boss.y = boss.targetY;
        boss.state = "active";
        boss.age = 1.8;
        bossAttackTimer = 0.45;
        updateBossHud();
        return true;
      },
      setBossHealth(value) {
        if (!boss || state !== State.PLAYING) {
          return false;
        }
        boss.hp = clamp(value, 0, boss.maxHp);
        updateBossHud();
        if (!boss.phaseTwo && boss.hp > 0 && boss.hp <= boss.maxHp * 0.5) {
          enterBossPhaseTwo();
        }
        if (boss.hp <= 0) {
          defeatBoss();
        }
        return true;
      },
      triggerBossAttack(type = "fan") {
        if (!boss || state !== State.PLAYING || boss.state !== "active" || boss.defeated) {
          return false;
        }
        bossWarnings.length = 0;
        bossAttackTimer = 0;
        if (type === "lock") {
          startBossLockAttack();
        } else {
          startBossFanAttack();
        }
        return true;
      },
      restart() {
        restartGame();
      },
    });
  }

  /* ---------- 启动 ---------- */

  setupCanvas();
  initStars();
  updateHud();
  finalScoreOutput.textContent = padScore(0);
  installDebugApi();
  window.addEventListener("resize", setupCanvas);
  requestAnimationFrame(frame);
})();
