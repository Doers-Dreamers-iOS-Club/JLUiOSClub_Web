#!/usr/bin/env node
/* ============================================================
   第二关「废弃矿场」Node vm 验收脚本
   ------------------------------------------------------------
   不引入任何 npm 依赖：用 vm 沙箱 stub DOM/Canvas，加载真实
   game.js，通过 ?debug=1 暴露的调试接口驱动并断言。
   运行：node tests/level2.test.js
   ============================================================ */
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.resolve(__dirname, "..");
const GAME_PATH = path.join(ROOT, "game.js");
const GAME_CODE = fs.readFileSync(GAME_PATH, "utf8");

const W = 960;
const H = 600;
const DEFAULT_TIP_HTML =
  "击毁 <strong>10</strong> 架普通敌机后进入 BOSS 战 · 预警含倒计时";
const DT_MS = 1000 / 60;

/* ---------- DOM / Canvas stub ---------- */

class FakeClassList {
  constructor() {
    this._names = new Set();
  }

  add(...names) {
    names.forEach((name) => this._names.add(name));
  }

  remove(...names) {
    names.forEach((name) => this._names.delete(name));
  }

  contains(name) {
    return this._names.has(name);
  }

  toggle(name, force) {
    const next = force === undefined ? !this._names.has(name) : Boolean(force);
    if (next) {
      this._names.add(name);
    } else {
      this._names.delete(name);
    }
    return next;
  }
}

class FakeElement {
  constructor(id = "", tagName = "div") {
    this.id = id;
    this.tagName = tagName;
    this.classList = new FakeClassList();
    this.style = {};
    this.dataset = {};
    this.hidden = false;
    this.textContent = "";
    this.innerHTML = "";
    this._attributes = Object.create(null);
    this._listeners = Object.create(null);
    this._queries = new Map();
  }

  setAttribute(name, value) {
    this._attributes[name] = String(value);
  }

  getAttribute(name) {
    return name in this._attributes ? this._attributes[name] : null;
  }

  hasAttribute(name) {
    return name in this._attributes;
  }

  addEventListener(type, handler) {
    if (!this._listeners[type]) {
      this._listeners[type] = [];
    }
    this._listeners[type].push(handler);
  }

  removeEventListener(type, handler) {
    const list = this._listeners[type];
    if (!list) {
      return;
    }
    const index = list.indexOf(handler);
    if (index >= 0) {
      list.splice(index, 1);
    }
  }

  dispatch(type, extra = {}) {
    const list = this._listeners[type] || [];
    for (const handler of list) {
      handler({
        type,
        target: this,
        preventDefault() {},
        stopPropagation() {},
        ...extra,
      });
    }
  }

  querySelector(selector) {
    return this._queries.get(selector) ?? null;
  }

  focus() {}

  blur() {}

  closest() {
    return null;
  }
}

class FakePath2D {
  moveTo() {}
  lineTo() {}
  closePath() {}
  arc() {}
  ellipse() {}
  rect() {}
}

function createContext2D() {
  const target = {};
  const gradient = () => ({ addColorStop() {} });

  return new Proxy(target, {
    get(object, property) {
      if (property === "createLinearGradient" || property === "createRadialGradient") {
        return gradient;
      }
      if (property === "createPattern") {
        return () => ({});
      }
      if (property === "measureText") {
        return () => ({ width: 12 });
      }
      if (property in object) {
        return object[property];
      }
      return () => undefined;
    },
    set(object, property, value) {
      object[property] = value;
      return true;
    },
  });
}

/* ---------- harness ---------- */

function createHarness(options = {}) {
  const search = options.search ?? "";
  const clock = { ms: 0 };
  const rafQueue = [];
  const elements = new Map();
  const windowListeners = Object.create(null);
  const documentListeners = Object.create(null);

  const ctx = createContext2D();

  const lifePips = [0, 1, 2].map(() => new FakeElement("life-pip", "i"));
  const levelButtons = [
    new FakeElement("levelButton1", "button"),
    new FakeElement("levelButton2", "button"),
  ];
  levelButtons[0].dataset.level = "1";
  levelButtons[1].dataset.level = "2";

  function getElement(id) {
    let element = elements.get(id);
    if (element) {
      return element;
    }

    element = new FakeElement(id);
    if (id === "bossHud") {
      element._queries.set(".boss-status-text", new FakeElement("bossStatus", "span"));
    }
    if (id === "gameCanvas") {
      element.tagName = "canvas";
      element.getContext = () => ctx;
    }
    if (id === "footerTip") {
      element.innerHTML = DEFAULT_TIP_HTML;
    }
    elements.set(id, element);
    return element;
  }

  const documentStub = {
    hidden: false,
    activeElement: null,
    getElementById(id) {
      return getElement(id);
    },
    querySelectorAll(selector) {
      if (selector === ".life-pip") {
        return lifePips;
      }
      if (selector === ".level-select-button") {
        return levelButtons;
      }
      return [];
    },
    addEventListener(type, handler) {
      if (!documentListeners[type]) {
        documentListeners[type] = [];
      }
      documentListeners[type].push(handler);
    },
    createElement(tagName) {
      return new FakeElement("", tagName);
    },
  };

  const windowStub = {
    location: { search },
    devicePixelRatio: 1,
    addEventListener(type, handler) {
      if (!windowListeners[type]) {
        windowListeners[type] = [];
      }
      windowListeners[type].push(handler);
    },
    removeEventListener() {},
  };

  const sandbox = {
    window: windowStub,
    document: documentStub,
    performance: { now: () => clock.ms },
    requestAnimationFrame(callback) {
      rafQueue.push(callback);
      return rafQueue.length;
    },
    cancelAnimationFrame() {},
    Path2D: FakePath2D,
    Element: FakeElement,
    URLSearchParams,
    console,
  };

  vm.createContext(sandbox);
  vm.runInContext(GAME_CODE, sandbox, { filename: GAME_PATH });

  function runFrames(count, dtMs = DT_MS) {
    for (let i = 0; i < count; i += 1) {
      if (rafQueue.length !== 1) {
        throw new Error(`期望队列里只有 1 个 RAF 回调，实际 ${rafQueue.length} 个`);
      }
      const callback = rafQueue.shift();
      clock.ms += dtMs;
      callback(clock.ms);
    }
  }

  function runFor(seconds, dtMs = DT_MS) {
    runFrames(Math.ceil((seconds * 1000) / dtMs), dtMs);
  }

  function pressKey(code) {
    const list = windowListeners.keydown || [];
    for (const handler of list) {
      handler({
        code,
        repeat: false,
        target: null,
        preventDefault() {},
        stopPropagation() {},
      });
    }
  }

  function releaseKey(code) {
    const list = windowListeners.keyup || [];
    for (const handler of list) {
      handler({ code, target: null, preventDefault() {} });
    }
  }

  return {
    search,
    api: windowStub.__SPACE_SHOOTER_DEBUG__,
    elements,
    getElement,
    levelButtons,
    lifePips,
    runFrames,
    runFor,
    pressKey,
    releaseKey,
    rafQueue,
    clock,
  };
}

/* ---------- 断言工具 ---------- */

let passed = 0;
let failed = 0;
const failures = [];

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function assertEqual(actual, expected, message) {
  if (actual !== expected) {
    throw new Error(`${message}：期望 ${JSON.stringify(expected)}，实际 ${JSON.stringify(actual)}`);
  }
}

function check(name, run) {
  try {
    run();
    passed += 1;
    console.log(`  ✓ ${name}`);
  } catch (error) {
    failed += 1;
    failures.push(`${name}\n      ${error.message}`);
    console.error(`  ✗ ${name}\n      ${error.message}`);
  }
}

/* ---------- 场景 ---------- */

console.log("第二关「废弃矿场」验收");

const h = createHarness({ search: "?debug=1&level=2" });
const d = h.api;

if (!d) {
  console.error("未拿到 window.__SPACE_SHOOTER_DEBUG__，?debug=1 失效");
  process.exit(1);
}

function snapshot() {
  return d.snapshot();
}

// 冻结刷怪：停在指定波次、把击杀配额填满、放一架不动的哑机防止波次推进。
function freezeSpawning(waveIndex) {
  d.skipToWave(waveIndex);
  d.setWaveKills(snapshot().waveQuota);
  d.spawnEnemyAt(900, 40, { kind: "charger" });
  // 清掉前一场景可能残留的玩家子弹，避免污染分数断言。
  d.clearBullets();
}

// 用子弹在场上逐个点杀敌机，直到本波结束（用于统计实际生成序列）。
function autoPlayWave(waveIndex) {
  d.skipToWave(waveIndex);
  const seen = new Map();
  let guard = 0;
  let current = snapshot();

  while (current.wave === waveIndex && current.levelFlow !== "idle" && guard < 6000) {
    for (const enemy of current.enemies) {
      seen.set(enemy.id, enemy.kind);
      d.spawnBulletAt(enemy.x, enemy.y + 20);
      if (enemy.kind === "sapper") {
        d.spawnBulletAt(enemy.x, enemy.y + 20);
      }
    }
    h.runFrames(1);
    current = snapshot();
    guard += 1;
  }

  // 自动点杀可能留下脱靶子弹，清掉后再做后续断言。
  d.clearBullets();
  return { snap: current, kinds: [...seen.values()], frames: guard };
}

check("启动：第二关 0 分 / 3 命 / intro 横幅 / 无岩石", () => {
  const s = snapshot();
  assertEqual(s.level, 2, "关卡");
  assertEqual(s.score, 0, "分数");
  assertEqual(s.lives, 3, "生命");
  assertEqual(s.state, "playing", "状态");
  assertEqual(s.levelFlow, "intro", "流程");
  assertEqual(s.levelBannerVisible, true, "横幅可见");
  assertEqual(s.levelBannerTitle, "LEVEL 02 // 废弃矿场", "横幅标题");
  assertEqual(s.rocks.length, 0, "初始无岩石");
  assertEqual(s.killLabelText, "WAVE / 波次", "击毁标签");
  assertEqual(s.killCountText, "00/08", "击毁读数");
  assertEqual(s.bossNameText, "EXCAVATOR-02 // 矿脉钻机", "Boss 名称");
  assertEqual(s.bossPhaseText, "PHASE 1 // DRILL", "Boss 阶段文案");
  assertEqual(s.bossWarningTitleText, "大型钻机接近", "预警标题");
  assertEqual(s.bossWarningSubText, "EXCAVATOR-02 INBOUND", "预警副标题");
});

check("intro 1.5s 后进入 Wave 1：4 块岩石（2 大 2 小）+ 波次横幅", () => {
  h.runFor(1.6);
  const s = snapshot();
  assertEqual(s.wave, 1, "波次");
  assertEqual(s.levelFlow, "waveBanner", "流程");
  assertEqual(s.rocks.length, 4, "岩石数量");
  assertEqual(s.rocks.filter((rock) => rock.size === "large").length, 2, "大岩石");
  assertEqual(s.rocks.filter((rock) => rock.size === "small").length, 2, "小岩石");
  assertEqual(s.levelBannerTitle, "WAVE 1/3", "波次横幅");
  assertEqual(s.killCountText, "00/08", "击毁读数");
});

check("横幅结束开始刷怪：同屏上限 4，Wave 1 只有 Charger", () => {
  h.runFor(1.6);
  let s = snapshot();
  assertEqual(s.levelFlow, "wave", "流程");
  assertEqual(s.levelBannerVisible, false, "横幅收起");

  h.runFor(3);
  s = snapshot();
  assert(s.enemies.length >= 1, `应有敌机，实际 ${s.enemies.length}`);
  assert(s.enemies.length <= 4, `同屏不得超过 4，实际 ${s.enemies.length}`);
  assert(s.enemies.every((enemy) => enemy.kind === "charger"), "Wave 1 不应出现 Sapper");
});

check("陨石不挡船、不造成接触伤害", () => {
  d.startLevel(2);
  h.runFor(1.6);
  const rock = snapshot().rocks[0];
  const before = snapshot();
  d.setPlayerPosition(rock.x, rock.y);
  h.runFrames(24);
  const after = snapshot();
  assertEqual(after.lives, before.lives, "生命不应变化");
  assert(Math.abs(after.player.x - rock.x) < 1, "位置不应被推开");
  assert(Math.abs(after.player.y - rock.y) < 1, "位置不应被推开");
});

check("小岩石 1 发碎、给 10 分、不计击杀配额", () => {
  freezeSpawning(1);
  const before = snapshot();
  const rockId = d.spawnRockAt(480, 300, 22, 1);
  assert(rockId !== null, "spawnRockAt 失败");
  d.spawnBulletAt(480, 340);
  h.runFrames(6);
  const s = snapshot();
  assert(!s.rocks.some((rock) => rock.id === rockId), "小岩石应被击碎");
  assertEqual(s.score, before.score + 10, "岩石得分");
  assertEqual(s.destroyedEnemyCount, before.destroyedEnemyCount, "岩石不计击毁");
});

check("扫掠检测：高速子弹不会穿小岩石", () => {
  freezeSpawning(1);
  const rockId = d.spawnRockAt(500, 320, 22, 1);
  d.spawnBulletAt(500, 372, -6000);
  h.runFrames(1);
  const s = snapshot();
  assert(!s.rocks.some((rock) => rock.id === rockId), "高速子弹不应穿过小岩石");
});

check("大岩石 2 发碎：第一发只掉血，第二发才给分", () => {
  freezeSpawning(2);
  const before = snapshot();
  const rockId = d.spawnRockAt(480, 300, 38, 2);

  d.spawnBulletAt(480, 350);
  h.runFrames(6);
  let s = snapshot();
  let rock = s.rocks.find((candidate) => candidate.id === rockId);
  assert(Boolean(rock), "第一发后大岩石应仍然存在");
  assertEqual(rock.hp, 1, "第一发后 hp");
  assertEqual(s.score, before.score, "未击碎不加分");

  d.spawnBulletAt(480, 350);
  h.runFrames(6);
  s = snapshot();
  assert(!s.rocks.some((candidate) => candidate.id === rockId), "第二发应击碎");
  assertEqual(s.score, before.score + 10, "击碎得分");
});

check("Boss 震碎岩石不给分", () => {
  freezeSpawning(1);
  const before = snapshot();
  const destroyed = d.damageRockAt(420, 300, 2, "boss");
  assert(destroyed, "damageRockAt 失败");
  const s = snapshot();
  assertEqual(s.score, before.score, "Boss 震碎不应加分");
  assert(!s.rocks.some((rock) => Math.abs(rock.x - 420) < 0.5 && Math.abs(rock.y - 300) < 0.5), "岩石应被移除");
});

check("Sapper：2 发击杀、250 分、第一发只掉血", () => {
  freezeSpawning(1);
  const before = snapshot();
  // 从 holdY 下方生成，保证它在下降过程中不会横移，子弹瞄准稳定。
  const sapperId = d.spawnEnemyAt(480, 180, { kind: "sapper" });
  assert(sapperId !== null, "spawnEnemyAt 失败");

  let s = snapshot();
  let sapper = s.enemies.find((enemy) => enemy.id === sapperId);
  assertEqual(sapper.kind, "sapper", "类型");
  assertEqual(sapper.hp, 2, "hp");
  assertEqual(sapper.maxHp, 2, "maxHp");
  assertEqual(sapper.points, 250, "分数");

  d.spawnBulletAt(480, sapper.y + 20);
  h.runFrames(1);
  s = snapshot();
  sapper = s.enemies.find((enemy) => enemy.id === sapperId);
  assert(Boolean(sapper), "第一发后应仍然存在");
  assertEqual(sapper.hp, 1, "第一发后 hp");
  assertEqual(s.score, before.score, "第一发不加分");

  d.spawnBulletAt(480, sapper.y + 20);
  h.runFrames(1);
  s = snapshot();
  assert(!s.enemies.some((enemy) => enemy.id === sapperId), "第二发应击杀");
  assertEqual(s.score, before.score + 250, "Sapper 得分");
  assertEqual(s.destroyedEnemyCount, before.destroyedEnemyCount + 1, "击毁计数");
});

check("Sapper 远程：慢速瞄准弹、无预警、优先打前方岩石", () => {
  freezeSpawning(2);
  d.setPlayerPosition(480, 500);
  const rockId = d.spawnRockAt(560, 380, 22, 1);
  d.spawnEnemyAt(480, 230, { kind: "sapper" });
  const scoreBefore = snapshot().score;

  let firstShot = null;
  for (let frame = 0; frame < 260 && !firstShot; frame += 1) {
    h.runFrames(1);
    const s = snapshot();
    if (s.enemyBullets.length > 0) {
      assertEqual(s.bossWarnings.length, 0, "Sapper 子弹不应创建预警");
      firstShot = s.enemyBullets[0];
    }
  }

  assert(Boolean(firstShot), "Sapper 应在 4.4s 内开火");
  assertEqual(firstShot.owner, "sapper", "子弹来源");
  const speed = Math.hypot(firstShot.vx, firstShot.vy);
  assert(Math.abs(speed - 180) < 1, `弹速应约 180，实际 ${speed.toFixed(1)}`);
  assert(firstShot.vx > 20, `应瞄准右侧岩石（vx>0），实际 vx=${firstShot.vx}`);

  h.runFor(2);
  const s = snapshot();
  assert(!s.rocks.some((rock) => rock.id === rockId), "岩石应被 Sapper 子弹打碎");
  assertEqual(s.score, scoreBefore, "敌方子弹打碎岩石不给分");
});

check("Sapper 子弹命中玩家：掉 1 条命并进入无敌帧", () => {
  freezeSpawning(3);
  for (const rock of snapshot().rocks) {
    d.damageRockAt(rock.x, rock.y, 99, "boss");
  }
  d.setPlayerPosition(700, 520);
  d.spawnEnemyAt(700, 240, { kind: "sapper" });

  const before = snapshot();
  let hit = false;
  let afterHit = null;
  for (let frame = 0; frame < 480 && !hit; frame += 1) {
    h.runFrames(1);
    const s = snapshot();
    if (s.lives < before.lives) {
      hit = true;
      afterHit = s;
    }
  }

  assert(hit, `Sapper 子弹应命中玩家，生命 ${snapshot().lives} / ${before.lives}`);
  assert(
    afterHit.player.invulnerable > 0 || afterHit.lives === 0,
    "命中瞬间应进入无敌帧",
  );
});

check("Wave 2：配额 10、3 只 Sapper、5 块岩石，清空后进入 Wave 3", () => {
  d.skipToWave(2);
  const s0 = snapshot();
  assertEqual(s0.rocks.length, 5, "Wave 2 岩石数量");
  assertEqual(s0.killCountText, "00/10", "Wave 2 HUD");

  // 先清掉岩石，避免自动点杀时子弹被掩体挡住。
  for (const rock of s0.rocks) {
    d.damageRockAt(rock.x, rock.y, 99, "boss");
  }

  const { snap, kinds } = autoPlayWave(2);
  assertEqual(kinds.filter((kind) => kind === "sapper").length, 3, "Sapper 数量");
  assertEqual(kinds.filter((kind) => kind === "charger").length, 7, "Charger 数量");
  assertEqual(snap.wave, 3, "应进入 Wave 3");
  assertEqual(snap.levelFlow, "waveBanner", "Wave 3 横幅");
  assertEqual(snap.levelBannerTitle, "WAVE 3/3", "横幅标题");
});

check("Wave 3：配额 12、5 只 Sapper、清空后进入 Boss 预警 + 3 块岩石", () => {
  d.skipToWave(3);
  const s0 = snapshot();
  assertEqual(s0.rocks.length, 6, "Wave 3 岩石数量");
  for (const rock of s0.rocks) {
    d.damageRockAt(rock.x, rock.y, 99, "boss");
  }

  const { snap, kinds } = autoPlayWave(3);
  assertEqual(kinds.filter((kind) => kind === "sapper").length, 5, "Sapper 数量");
  assertEqual(kinds.length, 12, "总生成数应等于配额（无漏杀）");
  assertEqual(snap.levelFlow, "idle", "流程回到 idle");
  assertEqual(snap.bossEncounter, "warning", "进入 Boss 预警");
  assertEqual(snap.bossWarningVisible, true, "预警可见");
  assertEqual(snap.bossWarningTitleText, "大型钻机接近", "预警标题");
  assertEqual(snap.levelBannerVisible, false, "Boss 预警期间关卡横幅收起");
  assertEqual(snap.rocks.length, 3, "Boss 布局 3 块岩石");

  // 2.2s 预警后生成 Boss 2。
  h.runFor(2.4);
  const s = snapshot();
  assertEqual(s.bossEncounter, "boss", "Boss 阶段");
  assertEqual(s.boss.state, "entering", "入场中");
  assertEqual(s.boss.level, 2, "Boss 关卡");
  assertEqual(s.boss.kind, "excavator", "Boss 类型");
  assertEqual(s.boss.maxHp, 2200, "Boss 血量");
  assertEqual(s.boss.hp, 2200, "Boss 初始血量");
  assertEqual(s.boss.reward, 8000, "Boss 奖励");
  assertEqual(s.bossHudVisible, true, "Boss HUD 可见");
  assert(Math.abs(s.boss.x - W / 2) < 0.01, "入场期间 x 固定");
});

check("Boss 2 入场无横闪：到达 y=142 时 x 仍为 480", () => {
  let guard = 0;
  while (snapshot().boss && snapshot().boss.state === "entering" && guard < 300) {
    h.runFrames(1);
    guard += 1;
  }
  const s = snapshot();
  assertEqual(s.boss.state, "active", "应进入 active");
  assert(Math.abs(s.boss.x - 480) < 0.6, `不应横向闪现，x=${s.boss.x.toFixed(2)}`);
  assert(Math.abs(s.boss.y - 142) < 10, `入场高度 y=${s.boss.y.toFixed(2)}`);
  assertEqual(s.bossPhaseText, "PHASE 1 // DRILL", "HUD 阶段");
});

check("Boss 2 Phase 1：5 发碎石扇形、无预警", () => {
  // Boss 战的碎石/冲锋会持续消耗生命，测试期间保持无敌，避免提前进入结算。
  d.setLives(3);
  d.setInvulnerable(999);
  const before = snapshot().bossBullets.length;
  d.triggerBossAttack("shards");
  const s = snapshot();
  assertEqual(s.bossBullets.length - before, 5, "碎石数量");
  assertEqual(s.bossWarnings.length, 0, "第二关碎石无预警");
});

check("Boss 2 冲锋：起手后扫掠撞碎路径岩石且不给分", () => {
  d.setPlayerPosition(840, 500);
  const before = snapshot();
  d.triggerBossAttack("charge");
  h.runFor(0.9);
  const mid = snapshot();
  assert(
    ["windup", "dash", "recover", "idle"].includes(mid.boss.chargeState),
    `冲锋状态异常：${mid.boss.chargeState}`,
  );
  h.runFor(1.2);
  const s = snapshot();
  assert(s.rocks.length < before.rocks.length, "冲锋应摧毁路径岩石");
  assertEqual(s.score, before.score, "Boss 撞碎岩石不给分");
});

check("Boss 2 50% 转阶段：冲击波清空岩石、核心暴露、不伤害玩家、只触发一次", () => {
  const before = snapshot();
  d.setBossHealth(1100);
  let s = snapshot();
  assertEqual(s.boss.phaseTwo, true, "phaseTwo");
  assertEqual(s.boss.coreExposed, true, "coreExposed");
  assertEqual(s.boss.phaseTransitions, 1, "转阶段次数");
  assertEqual(s.rocks.length, 0, "冲击波应震碎全部岩石");
  assertEqual(s.lives, before.lives, "冲击波不伤害玩家");
  assertEqual(s.score, before.score, "冲击波不给分");
  assertEqual(s.bossPhaseText, "PHASE 2 // CORE", "HUD 阶段");

  d.setBossHealth(1100);
  assertEqual(snapshot().boss.phaseTransitions, 1, "phaseTwo 只能触发一次");
});

check("Boss 2 Phase 2：10 发径向碎石", () => {
  const before = snapshot().bossBullets.length;
  d.triggerBossAttack("shards");
  assertEqual(snapshot().bossBullets.length - before, 10, "径向碎石数量");
});

check("Boss 2 Phase 2：冲锋为双段，方向反弹并覆盖两侧边界", () => {
  d.triggerBossAttack("charge");
  const seen = [];
  let lastState = null;
  let maxChargeCount = 0;
  let minX = Infinity;
  let maxX = -Infinity;

  for (let frame = 0; frame < 600; frame += 1) {
    h.runFrames(1);
    const s = snapshot();
    if (!s.boss) {
      break;
    }
    const chargeState = s.boss.chargeState;
    if (chargeState !== lastState) {
      seen.push(chargeState);
      lastState = chargeState;
    }
    maxChargeCount = Math.max(maxChargeCount, s.boss.chargeCount ?? 0);
    minX = Math.min(minX, s.boss.x);
    maxX = Math.max(maxX, s.boss.x);
    if (
      maxChargeCount >= 2 &&
      chargeState === "idle" &&
      seen.filter((value) => value === "dash").length >= 2
    ) {
      break;
    }
  }

  const dashes = seen.filter((value) => value === "dash").length;
  assert(dashes >= 2, `应有两段冲锋，实际 ${dashes}，序列 ${seen.join("→")}`);
  assertEqual(maxChargeCount, 2, "双冲计数");
  assert(minX <= 130, `应冲到左边界，minX=${minX.toFixed(1)}`);
  assert(maxX >= W - 130, `应冲到右边界，maxX=${maxX.toFixed(1)}`);
});

check("Boss 2 核心 24 伤害 / 身体 12 伤害", () => {
  let boss = snapshot().boss;
  const coreBefore = boss.hp;
  d.spawnBulletAt(boss.x, boss.y + 8 + 22);
  h.runFrames(1);
  boss = snapshot().boss;
  assertEqual(coreBefore - boss.hp, 24, "核心伤害");

  const bodyBefore = boss.hp;
  d.spawnBulletAt(boss.x + 60, boss.y + 30);
  h.runFrames(1);
  boss = snapshot().boss;
  assertEqual(bodyBefore - boss.hp, 12, "身体伤害");
});

check("Boss 2 击破：奖励 8000、文案「矿区突破」", () => {
  const before = snapshot();
  assertEqual(before.state, "playing", "击破前应仍在战斗");
  assert(before.lives > 0, "击破前应有生命（测试保持无敌）");
  d.setBossHealth(0);
  h.runFrames(1);
  const s = snapshot();
  assertEqual(s.boss.defeated, true, "defeated");
  assertEqual(s.state, "gameover", "状态");
  assertEqual(s.outcome, "victory", "结果");
  assertEqual(s.overlayVisible, true, "结算层可见");
  assertEqual(s.overlayTitle, "矿区突破", "胜利文案");
  assertEqual(s.score, before.score + 8000, "击破奖励");
  assertEqual(
    h.getElement("outcomeSummary").textContent,
    "EXCAVATOR-02 击破奖励 +8000",
    "结算摘要",
  );
});

check("重开：保持第二关、回到 Wave 1 前的 intro、0 分 3 命、单 RAF 循环", () => {
  d.restart();
  const s = snapshot();
  assertEqual(s.level, 2, "关卡");
  assertEqual(s.score, 0, "分数");
  assertEqual(s.lives, 3, "生命");
  assertEqual(s.levelFlow, "intro", "流程");
  assertEqual(s.wave, 0, "波次");
  assertEqual(s.rocks.length, 0, "岩石已清空");
  assertEqual(s.enemyBullets.length, 0, "敌方子弹已清空");
  assertEqual(s.boss, null, "Boss 已清空");
  assertEqual(s.overlayVisible, false, "结算层隐藏");
  assertEqual(s.levelBannerVisible, true, "intro 横幅");
  assertEqual(h.rafQueue.length, 1, "只有一个 RAF 回调");
});

check("第二关死亡：文案「矿区失守」，重开从 Wave 1", () => {
  d.startLevel(2);
  h.runFor(1.6);
  h.runFor(1.6);
  d.setLives(0);
  h.runFrames(1);
  const s = snapshot();
  assertEqual(s.state, "gameover", "状态");
  assertEqual(s.outcome, "defeat", "结果");
  assertEqual(s.overlayTitle, "矿区失守", "失败文案");

  d.restart();
  const after = snapshot();
  assertEqual(after.level, 2, "重开关卡");
  assertEqual(after.wave, 0, "回到 Wave 1 之前");
  assertEqual(after.levelFlow, "intro", "intro");
  assertEqual(after.score, 0, "0 分");
  assertEqual(after.lives, 3, "3 命");
});

check("暂停冻结横幅计时，恢复后继续", () => {
  d.startLevel(2);
  h.pressKey("KeyP");
  let s = snapshot();
  assertEqual(s.paused, true, "暂停");
  assert(h.getElement("stage").classList.contains("is-paused"), "stage 暂停类");
  const frozen = s.waveBannerClock;
  h.runFrames(12);
  s = snapshot();
  assertEqual(s.waveBannerClock, frozen, "横幅计时冻结");

  h.pressKey("KeyP");
  assertEqual(snapshot().paused, false, "恢复");
  h.runFrames(6);
  assert(snapshot().waveBannerClock < frozen, "恢复后计时继续");
});

check("顶栏 01 / 02 按钮：点击立即切关并同步 UI", () => {
  h.levelButtons[1].dispatch("click");
  let s = snapshot();
  assertEqual(s.level, 2, "切到第二关");
  assertEqual(h.levelButtons[1].getAttribute("aria-pressed"), "true", "aria-pressed 02");
  assertEqual(h.levelButtons[0].getAttribute("aria-pressed"), "false", "aria-pressed 01");
  assert(h.levelButtons[1].classList.contains("is-active"), "is-active 02");
  assertEqual(h.getElement("brandEyebrow").textContent, "ORBITAL ARCADE / 02", "品牌眉标");

  h.levelButtons[0].dispatch("click");
  s = snapshot();
  assertEqual(s.level, 1, "切回第一关");
  assertEqual(h.levelButtons[0].getAttribute("aria-pressed"), "true", "aria-pressed 01");
  assertEqual(h.getElement("brandEyebrow").textContent, "ORBITAL ARCADE / 01", "品牌眉标");
  assertEqual(h.getElement("levelBanner").hidden, true, "第一关不显示关卡横幅");
  assertEqual(s.killLabelText, "KILLS / 击毁", "击毁标签");
  assert(h.getElement("footerTip").innerHTML.includes("<strong>10</strong>"), "页脚提示恢复");
});

check("第一关回归：10 击杀触发预警、Boss 1600 HP、扇形/锁定、文案与奖励不变", () => {
  d.startLevel(1);
  let guard = 0;
  while (snapshot().bossEncounter === "idle" && guard < 4000) {
    const current = snapshot();
    for (const enemy of current.enemies) {
      d.spawnBulletAt(enemy.x, enemy.y + 20);
    }
    h.runFrames(1);
    guard += 1;
  }

  let s = snapshot();
  assertEqual(s.bossEncounter, "warning", "应进入 Boss 预警");
  assertEqual(s.bossWarningTitleText, "大型敌机接近", "第一关预警标题");
  assertEqual(s.bossWarningSubText, "BOSS INCOMING", "第一关预警副标题");

  h.runFor(2.4);
  s = snapshot();
  assertEqual(s.boss.maxHp, 1600, "Boss 1 血量");
  assertEqual(s.boss.reward, 5000, "Boss 1 奖励");
  assertEqual(s.bossNameText, "BOSS // 歼星母舰", "Boss 1 名称");
  assertEqual(s.bossPhaseText, "PHASE 1", "Boss 1 阶段");

  let activeGuard = 0;
  while (snapshot().boss && snapshot().boss.state === "entering" && activeGuard < 300) {
    h.runFrames(1);
    activeGuard += 1;
  }

  d.triggerBossAttack("fan");
  s = snapshot();
  assertEqual(s.bossWarnings.length, 1, "第一关扇形预警");
  assertEqual(s.bossWarnings[0].type, "fan", "预警类型");
  h.runFor(1);
  s = snapshot();
  assertEqual(s.bossBullets.length, 9, "第一关 Phase 1 扇形 9 发");

  d.setBossHealth(800);
  s = snapshot();
  assertEqual(s.boss.phaseTwo, true, "Boss 1 阶段二");
  assertEqual(s.boss.phaseTransitions, 1, "Boss 1 转阶段次数");
  assertEqual(s.bossPhaseText, "PHASE 2 // LOCK", "Boss 1 阶段文案");

  const before = snapshot();
  d.setBossHealth(0);
  h.runFrames(1);
  s = snapshot();
  assertEqual(s.overlayTitle, "防线守住了", "第一关胜利文案");
  assertEqual(s.score, before.score + 5000, "第一关击破奖励");
  assertEqual(
    h.getElement("outcomeSummary").textContent,
    "BOSS 击破奖励 +5000",
    "第一关结算摘要",
  );
});

/* ---------- 入口/回归 ---------- */

const direct = createHarness({ search: "?level=2" });

check("?level=2 直达第二关（无 debug 参数也可用）", () => {
  assertEqual(direct.api, undefined, "无 debug 时不应暴露接口");
  assertEqual(direct.getElement("levelBanner").hidden, false, "关卡横幅可见");
  assertEqual(
    direct.getElement("levelBannerTitle").textContent,
    "LEVEL 02 // 废弃矿场",
    "横幅标题",
  );
  assertEqual(
    direct.getElement("brandEyebrow").textContent,
    "ORBITAL ARCADE / 02",
    "品牌眉标",
  );
  direct.runFrames(3);
});

const fallback = createHarness({ search: "" });

check("默认启动仍是第一关，文案/数值不变", () => {
  assertEqual(fallback.api, undefined, "无 debug 时不应暴露接口");
  assertEqual(fallback.getElement("levelBanner").hidden, true, "不显示关卡横幅");
  assertEqual(fallback.getElement("killLabel").textContent, "KILLS / 击毁", "击毁标签");
  assertEqual(fallback.getElement("bossName").textContent, "BOSS // 歼星母舰", "Boss 名称");
  assertEqual(fallback.getElement("bossWarningTitle").textContent, "大型敌机接近", "预警标题");
  assertEqual(fallback.getElement("bossHpText").textContent, "1600 / 1600", "Boss HP 文案");
  assertEqual(
    fallback.getElement("bossHealthBar").getAttribute("aria-valuemax"),
    "1600",
    "HP 条最大值",
  );
  assert(fallback.getElement("footerTip").innerHTML.includes("<strong>10</strong>"), "页脚提示");
  fallback.runFrames(6);
});

/* ---------- 汇总 ---------- */

console.log("");
if (failed === 0) {
  console.log(`全部通过：${passed} 项`);
  process.exit(0);
}

console.log(`通过 ${passed} 项，失败 ${failed} 项：`);
for (const failure of failures) {
  console.log(`  - ${failure}`);
}
process.exit(1);
