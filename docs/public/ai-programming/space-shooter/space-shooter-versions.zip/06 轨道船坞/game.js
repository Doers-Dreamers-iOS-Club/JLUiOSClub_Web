/* ============================================================
   深空防线 — 单文件游戏逻辑
   ------------------------------------------------------------
   游戏世界固定为 960 × 600，CSS 只负责缩放画面。
   整局游戏只运行一个 requestAnimationFrame 循环；重新开始
   只重置状态，不会再次注册循环，因此连续重开不会加速。
   ============================================================ */
(() => {
  "use strict";

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");
  const stage = document.getElementById("stage");
  const scoreOutput = document.getElementById("score");
  const killCountOutput = document.getElementById("killCount");
  const livesCount = document.getElementById("livesCount");
  const lifePips = Array.from(document.querySelectorAll(".life-pip"));
  const bossWarningEl = document.getElementById("bossWarning");
  const bossWarningTimer = document.getElementById("bossWarningTimer");
  const bossHud = document.getElementById("bossHud");
  const bossHealthBar = document.getElementById("bossHealthBar");
  const bossHealthFill = document.getElementById("bossHealthFill");
  const bossHpText = document.getElementById("bossHpText");
  const bossPhaseText = document.getElementById("bossPhase");
  const bossStatusText = bossHud ? bossHud.querySelector(".boss-status-text") : null;
  const pauseOverlay = document.getElementById("pauseOverlay");
  const overlay = document.getElementById("gameOverOverlay");
  const outcomeEyebrow = document.getElementById("outcomeEyebrow");
  const gameOverTitle = document.getElementById("gameOverTitle");
  const outcomeSummary = document.getElementById("outcomeSummary");
  const finalLabel = document.getElementById("finalLabel");
  const finalScoreOutput = document.getElementById("finalScore");
  const restartButton = document.getElementById("restartButton");

  const levelSelect = document.getElementById("levelSelect");
  const levelButtons = Array.from(document.querySelectorAll(".level-select-button"));
  const levelBannerEl = document.getElementById("levelBanner");
  const levelBannerKicker = document.getElementById("levelBannerKicker");
  const levelBannerTitle = document.getElementById("levelBannerTitle");
  const levelBannerSub = document.getElementById("levelBannerSub");
  const bossNameOutput = document.getElementById("bossName");
  const bossWarningKicker = document.getElementById("bossWarningKicker");
  const bossWarningTitle = document.getElementById("bossWarningTitle");
  const bossWarningSub = document.getElementById("bossWarningSub");
  const killLabel = document.getElementById("killLabel");
  const footerTip = document.getElementById("footerTip");
  const brandEyebrow = document.getElementById("brandEyebrow");
  // 第一关页脚提示的原始标记（含 <strong>），切回第一关时原样恢复。
  const levelOneFooterTipHtml = footerTip ? footerTip.innerHTML : "";

  if (
    !canvas ||
    !ctx ||
    !stage ||
    !scoreOutput ||
    !killCountOutput ||
    !overlay ||
    !restartButton ||
    !bossWarningEl ||
    !bossWarningTimer ||
    !bossHud ||
    !bossHealthBar ||
    !bossHealthFill ||
    !bossHpText ||
    !bossPhaseText ||
    !pauseOverlay ||
    !outcomeEyebrow ||
    !gameOverTitle ||
    !outcomeSummary ||
    !finalLabel ||
    !levelSelect ||
    !levelBannerEl ||
    !levelBannerKicker ||
    !levelBannerTitle ||
    !levelBannerSub ||
    !bossNameOutput ||
    !bossWarningKicker ||
    !bossWarningTitle ||
    !bossWarningSub ||
    !killLabel ||
    !footerTip ||
    !brandEyebrow ||
    levelButtons.length === 0
  ) {
    throw new Error("游戏初始化失败：缺少必要的页面元素。");
  }

  const W = 960;
  const H = 600;
  const MAX_LIVES = 3;
  const PLAYER_SPEED = 390;
  const PLAYER_FIRE_INTERVAL = 0.14;
  const BULLET_SPEED = 760;
  const SCORE_PER_ENEMY = 100;
  const INITIAL_SPAWN_DELAY = 0.55;
  const MIN_SPAWN_INTERVAL = 0.46;
  const PLAYER_HALF_W = 26;
  const PLAYER_HALF_H = 29;
  const INVULNERABLE_TIME = 1.25;
  const MUZZLE_FLASH_TIME = 0.08;
  const TAU = Math.PI * 2;

  const BOSS_KILL_TARGET = 10;
  const BOSS_MAX_HP = 1600;
  const PLAYER_BOSS_DAMAGE = 12;
  const BOSS_REWARD = 5000;
  const BOSS_WARNING_TIME = 2.2;
  const BOSS_ENTRY_TARGET_Y = 142;
  const BOSS_FAN_WARNING_TIME = 0.95;
  const BOSS_LOCK_WARNING_TIME = 1.15;
  const BOSS_LOCK_RADIUS = 56;
  const BOSS_FAN_SPREAD = 0.46;
  const BOSS_FAN_SPREAD_PHASE_TWO = 0.52;
  const BOSS_FAN_SHOTS = 9;
  const BOSS_FAN_SHOTS_PHASE_TWO = 11;
  const BOSS_FAN_BULLET_SPEED = 255;
  const BOSS_FAN_BULLET_SPEED_PHASE_TWO = 285;
  const BOSS_ATTACK_COOLDOWN = 2.65;
  const BOSS_ATTACK_COOLDOWN_PHASE_TWO = 2.2;

  // 第二关参数集中在此，方便实测调参；逻辑里不要写魔法数字。
  const LEVEL2_BOSS_HP = 2200;
  const LEVEL2_BOSS_REWARD = 8000;
  const LEVEL2_CORE_DAMAGE = 24;
  const LEVEL2_CORE_OFFSET_Y = 8;
  const LEVEL2_CORE_RADIUS = 18;
  const BOSS2_EDGE_MARGIN = 118;
  const BOSS2_MOVE_SPEED = 105;
  const BOSS2_MOVE_SPEED_PHASE_TWO = 130;
  const BOSS2_CHARGE_INTERVAL = 3.2;
  const BOSS2_CHARGE_INTERVAL_PHASE_TWO = 2.6;
  const BOSS2_CHARGE_WINDUP = 0.8;
  const BOSS2_CHARGE_WINDUP_PHASE_TWO = 0.6;
  const BOSS2_CHARGE_SPEED = 900;
  const BOSS2_CHARGE_RECOVER = 0.6;
  const BOSS2_SHARD_INTERVAL = 2.4;
  const BOSS2_SHARD_INTERVAL_PHASE_TWO = 2.0;
  const BOSS2_SHARD_SPEED = 220;
  const BOSS2_SHARD_COUNT = 5;
  const BOSS2_SHARD_COUNT_PHASE_TWO = 10;
  const BOSS2_SHARD_SPREAD = 0.62;
  const BOSS2_FIRST_CHARGE_DELAY = 2.2;
  const BOSS2_FIRST_SHARD_DELAY = 1.6;

  const SAPPER_HP = 2;
  const SAPPER_POINTS = 250;
  const SAPPER_FIRE_INTERVAL = 1.8;
  const SAPPER_BULLET_SPEED = 180;
  const SAPPER_DESCENT_SPEED = 70;
  const SAPPER_HOLD_Y_MIN = 190;
  const SAPPER_HOLD_Y_MAX = 300;
  const SAPPER_STRAFE_RANGE = 30;
  const SAPPER_TARGET_RANGE_X = 140;
  const SAPPER_TARGET_RANGE_Y = 260;

  const ROCK_SCORE = 10;
  const WAVE_BANNER_TIME = 1.5;
  const LEVEL2_WAVE_COUNT = 3;
  const LEVEL2_MAX_ON_SCREEN = 4;

  // 第三关参数集中在此，方便实测调参；逻辑里不要写魔法数字。
  const LEVEL3_BOSS_HP = 3000;
  const LEVEL3_BOSS_REWARD = 12000;
  const LEVEL3_WAVE_COUNT = 3;
  const LEVEL3_MAX_ON_SCREEN = 5;
  const BOSS3_ENTRY_TARGET_Y = 146;
  const BOSS3_EDGE_MARGIN = 130;
  const BOSS3_MOVE_SPEED = 115;
  const BOSS3_MOVE_SPEED_PHASE_TWO = 145;
  const BOSS3_BURST_INTERVAL = 2.6;
  const BOSS3_BURST_INTERVAL_PHASE_TWO = 2.0;
  const BOSS3_BURST_COUNT = 5;
  const BOSS3_BURST_COUNT_PHASE_TWO = 7;
  const BOSS3_BURST_SPEED = 280;
  const BOSS3_BURST_SPEED_PHASE_TWO = 310;
  const BOSS3_BURST_SPREAD = 0.5;
  const BOSS3_BURST_DOWNWARD_LIMIT = 0.55;
  const BOSS3_LASER_INTERVAL = 4.5;
  const BOSS3_FIRST_BURST_DELAY = 1.2;
  const BOSS3_FIRST_LASER_DELAY = 4.5;

  const LASER_WARNING_TIME = 1.0;
  const LASER_ACTIVE_TIME = 0.7;
  const LASER_WIDTH = 26;
  const BOSS3_LASER_WARNING_TIME = 0.85;
  const BOSS3_LASER_ACTIVE_TIME = 0.6;
  const LEVEL3_LASER_INTERVAL_WAVE_TWO = 7.0;
  const LEVEL3_LASER_INTERVAL_WAVE_THREE = 5.5;
  const LEVEL3_FIRST_LASER_WAVE_TWO = 5.0;
  const LEVEL3_FIRST_LASER_WAVE_THREE = 4.0;

  /* ---------- 关卡配置（文案/数值的唯一来源） ---------- */

  const LEVEL_CONFIG = Object.freeze({
    1: Object.freeze({
      id: 1,
      label: "01",
      title: "LEVEL 01 // 深空防线",
      eyebrow: "ORBITAL ARCADE / 01",
      killsLabel: "KILLS / 击毁",
      victoryTitle: "防线守住了",
      defeatTitle: "防线失守",
      rewardPrefix: "BOSS 击破奖励 +",
      boss: Object.freeze({
        name: "BOSS // 歼星母舰",
        maxHp: BOSS_MAX_HP,
        reward: BOSS_REWARD,
        warningKicker: "PROXIMITY ALERT // 高能反应",
        warningTitle: "大型敌机接近",
        warningSub: "BOSS INCOMING",
        phaseOneLabel: "PHASE 1",
        phaseTwoLabel: "PHASE 2 // LOCK",
        phaseOneStatus: "主反应堆在线",
        phaseTwoStatus: "锁定协议已启动",
      }),
    }),
    2: Object.freeze({
      id: 2,
      label: "02",
      title: "LEVEL 02 // 废弃矿场",
      eyebrow: "ORBITAL ARCADE / 02",
      killsLabel: "WAVE / 波次",
      victoryTitle: "矿区突破",
      defeatTitle: "矿区失守",
      rewardPrefix: "EXCAVATOR-02 击破奖励 +",
      waves: Object.freeze([
        Object.freeze({ quota: 8, spawnInterval: 0.9 }),
        Object.freeze({ quota: 10, spawnInterval: 0.8 }),
        Object.freeze({ quota: 12, spawnInterval: 0.75 }),
      ]),
      boss: Object.freeze({
        name: "EXCAVATOR-02 // 矿脉钻机",
        maxHp: LEVEL2_BOSS_HP,
        reward: LEVEL2_BOSS_REWARD,
        warningKicker: "DRILL SIGNAL // 钻机信号",
        warningTitle: "大型钻机接近",
        warningSub: "EXCAVATOR-02 INBOUND",
        phaseOneLabel: "PHASE 1 // DRILL",
        phaseTwoLabel: "PHASE 2 // CORE",
        phaseOneStatus: "钻头在线",
        phaseTwoStatus: "核心暴露",
      }),
    }),
    3: Object.freeze({
      id: 3,
      label: "03",
      title: "LEVEL 03 // 轨道船坞",
      eyebrow: "ORBITAL ARCADE / 03",
      killsLabel: "WAVE / 波次",
      victoryTitle: "船坞肃清",
      defeatTitle: "船坞失守",
      rewardPrefix: "AEGIS-03 击破奖励 +",
      waves: Object.freeze([
        Object.freeze({ quota: 10, spawnInterval: 0.85 }),
        Object.freeze({ quota: 12, spawnInterval: 0.78 }),
        Object.freeze({ quota: 14, spawnInterval: 0.72 }),
      ]),
      boss: Object.freeze({
        name: "AEGIS-03 // 环轨母舰",
        maxHp: LEVEL3_BOSS_HP,
        reward: LEVEL3_BOSS_REWARD,
        warningKicker: "CAPITAL SIGNAL // 母舰信号",
        warningTitle: "大型母舰接近",
        warningSub: "AEGIS-03 INBOUND",
        phaseOneLabel: "PHASE 1 // SCREEN",
        phaseTwoLabel: "PHASE 2 // OVERDRIVE",
        phaseOneStatus: "护航屏在线",
        phaseTwoStatus: "过载：激光栅格",
      }),
    }),
  });

  // 岩石只挡子弹、不挡船；坐标固定，避免随机布局导致测试不稳定。
  const ROCK_LAYOUTS = Object.freeze({
    1: Object.freeze([
      Object.freeze({ x: 230, y: 210, radius: 40, size: "large" }),
      Object.freeze({ x: 730, y: 180, radius: 38, size: "large" }),
      Object.freeze({ x: 420, y: 300, radius: 24, size: "small" }),
      Object.freeze({ x: 640, y: 330, radius: 22, size: "small" }),
    ]),
    2: Object.freeze([
      Object.freeze({ x: 180, y: 190, radius: 40, size: "large" }),
      Object.freeze({ x: 760, y: 250, radius: 38, size: "large" }),
      Object.freeze({ x: 330, y: 300, radius: 24, size: "small" }),
      Object.freeze({ x: 500, y: 170, radius: 22, size: "small" }),
      Object.freeze({ x: 680, y: 350, radius: 22, size: "small" }),
    ]),
    3: Object.freeze([
      Object.freeze({ x: 170, y: 220, radius: 40, size: "large" }),
      Object.freeze({ x: 790, y: 200, radius: 38, size: "large" }),
      Object.freeze({ x: 480, y: 155, radius: 36, size: "large" }),
      Object.freeze({ x: 300, y: 330, radius: 24, size: "small" }),
      Object.freeze({ x: 600, y: 320, radius: 22, size: "small" }),
      Object.freeze({ x: 720, y: 360, radius: 22, size: "small" }),
    ]),
    boss: Object.freeze([
      Object.freeze({ x: 180, y: 200, radius: 40, size: "large" }),
      Object.freeze({ x: 780, y: 200, radius: 38, size: "large" }),
      Object.freeze({ x: 300, y: 300, radius: 24, size: "small" }),
    ]),
  });

  // 波次生成序列：保证 Sapper 数量约为 3 / 5；序列用完后补 Charger，生成器不会停死。
  const WAVE_SPAWN_SEQUENCES = Object.freeze({
    1: Object.freeze([]),
    2: Object.freeze([
      "charger",
      "charger",
      "charger",
      "sapper",
      "charger",
      "charger",
      "sapper",
      "charger",
      "charger",
      "sapper",
    ]),
    3: Object.freeze([
      "charger",
      "charger",
      "charger",
      "sapper",
      "charger",
      "sapper",
      "charger",
      "charger",
      "sapper",
      "charger",
      "sapper",
      "sapper",
    ]),
  });

  const WAVE_SUBTITLES = Object.freeze([
    "矿脉接触 // ORE CONTACT",
    "深层信号 // DEEP SIGNAL",
    "钻机预热 // DRILL WARMUP",
  ]);

  // 第三关没有独立编成：全部生成 Charger，由波次配额与激光栅格提供压力。
  const LEVEL3_WAVE_SUBTITLES = Object.freeze([
    "船坞外围 // DRYDOCK PERIMETER",
    "船体接驳 // HULL LINK",
    "母舰核心 // CORE APPROACH",
  ]);

  // 左右炮口的唯一坐标来源：飞船局部坐标（机头方向为 -Y）。
  // 绘制炮口和生成子弹都通过 getMuzzleWorldPositions() 从这里换算，
  // 因此横移、侧倾和重开后，子弹出生点始终与对应炮口重合。
  const CANNON_OFFSETS = Object.freeze([
    Object.freeze({ side: "left", x: -13, y: -26 }),
    Object.freeze({ side: "right", x: 13, y: -26 }),
  ]);

  const State = Object.freeze({
    PLAYING: "playing",
    PAUSED: "paused",
    GAME_OVER: "gameover",
  });

  const keys = new Set();
  const stars = [];
  let bullets = [];
  let enemies = [];
  let particles = [];
  let player = createPlayer();
  let state = State.PLAYING;
  let score = 0;
  let lives = MAX_LIVES;
  let elapsed = 0;
  let spawnClock = INITIAL_SPAWN_DELAY;
  let fireClock = 0;
  let muzzleFlashClock = 0;
  let lastShotMuzzles = [];
  let shakeClock = 0;
  let damageFlash = 0;
  let nextEnemyId = 1;
  let lastFrameTime = performance.now();
  let destroyedEnemyCount = 0;
  let bossEncounter = "idle";
  let bossWarningClock = 0;
  let boss = null;
  let bossBullets = [];
  let bossWarnings = [];
  let bossAttackTimer = 0;
  let nextBossAttack = "fan";
  let bossRewardAwarded = false;
  let outcome = null;

  // 第二关状态：关卡、波次流程、岩石与敌方子弹。
  let currentLevel = 1;
  let levelFlow = "idle";
  let wave = 0;
  let waveKills = 0;
  let waveBannerClock = 0;
  let spawnIndex = 0;
  let rocks = [];
  let enemyBullets = [];
  let nextRockId = 1;
  let lasers = [];
  let nextLaserId = 1;
  let levelLaserTimer = 0;
  const dust = [];

  function random(min, max) {
    return min + Math.random() * (max - min);
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function padScore(value) {
    return String(value).padStart(6, "0");
  }

  function formatWarningTime(seconds) {
    const tenths = Math.ceil(Math.max(0, seconds) * 10);
    return `${(tenths / 10).toFixed(1)}s`;
  }

  function circlesRectsOverlap(ax, ay, ahw, ahh, bx, by, bhw, bhh) {
    return Math.abs(ax - bx) < ahw + bhw && Math.abs(ay - by) < ahh + bhh;
  }

  function createPlayer() {
    return {
      x: W / 2,
      y: H - 76,
      tilt: 0,
      invulnerable: 0,
      hitHalfW: 15,
      hitHalfH: 18,
    };
  }

  // 与 Canvas 的 translate(player.x, player.y) + rotate(player.tilt)
  // 使用同一套变换，保证炮口绘制位置和子弹出生点严格一致。
  function getMuzzleWorldPositions() {
    const cos = Math.cos(player.tilt);
    const sin = Math.sin(player.tilt);

    return CANNON_OFFSETS.map((cannon) => ({
      side: cannon.side,
      x: player.x + cannon.x * cos - cannon.y * sin,
      y: player.y + cannon.x * sin + cannon.y * cos,
    }));
  }

  /* ---------- 初始化与画面尺寸 ---------- */

  function initStars() {
    stars.length = 0;
    for (let i = 0; i < 118; i += 1) {
      stars.push({
        x: random(6, W - 6),
        y: random(6, H - 6),
        size: random(0.7, 1.9),
        speed: random(13, 68),
        alpha: random(0.22, 0.82),
        twinkle: random(0, TAU),
        twinkleSpeed: random(0.5, 2.1),
      });
    }
  }

  function initDust() {
    dust.length = 0;
    for (let i = 0; i < 46; i += 1) {
      dust.push({
        x: random(0, W),
        y: random(0, H),
        size: random(1, 3.2),
        speedX: random(-14, -4),
        speedY: random(6, 20),
        alpha: random(0.08, 0.28),
        phase: random(0, TAU),
      });
    }
  }

  function setupCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
  }

  function getWaveCount(level = currentLevel) {
    const waves = LEVEL_CONFIG[level]?.waves;
    return waves ? waves.length : 0;
  }

  function getWaveConfig(waveIndex = wave, level = currentLevel) {
    const waves = LEVEL_CONFIG[level]?.waves;
    if (!waves || waves.length === 0) {
      return null;
    }
    return waves[clamp(waveIndex, 1, waves.length) - 1];
  }

  function getWaveQuota(waveIndex = wave) {
    return getWaveConfig(waveIndex)?.quota ?? 0;
  }

  function hasWaveFlow(level = currentLevel) {
    return Boolean(LEVEL_CONFIG[level]?.waves);
  }

  function updateHud() {
    scoreOutput.textContent = padScore(score);

    // 有波次流程的关卡（第二、三关）显示「本波击杀 / 配额」，Boss 战与结算回落到总击毁数。
    if (hasWaveFlow() && levelFlow !== "idle") {
      const quota = getWaveQuota();
      killCountOutput.textContent = `${String(waveKills).padStart(2, "0")}/${String(
        quota,
      ).padStart(2, "0")}`;
    } else {
      killCountOutput.textContent = String(destroyedEnemyCount).padStart(2, "0");
    }

    livesCount.textContent = String(lives);
    lifePips.forEach((pip, index) => {
      pip.classList.toggle("is-empty", index >= lives);
    });
  }

  function updateBossHud() {
    if (!boss) {
      bossHud.hidden = true;
      return;
    }

    const config = LEVEL_CONFIG[boss.level]?.boss ?? LEVEL_CONFIG[1].boss;
    const healthRatio = clamp(boss.hp / boss.maxHp, 0, 1);
    bossHud.hidden = false;
    bossHealthFill.style.width = `${(healthRatio * 100).toFixed(2)}%`;
    bossHpText.textContent = `${Math.ceil(boss.hp)} / ${boss.maxHp}`;
    bossHealthBar.setAttribute("aria-valuemax", String(boss.maxHp));
    bossHealthBar.setAttribute("aria-valuenow", String(Math.ceil(boss.hp)));
    bossNameOutput.textContent = config.name;
    bossPhaseText.textContent = boss.phaseTwo
      ? config.phaseTwoLabel
      : config.phaseOneLabel;
    bossHud.classList.toggle("is-phase-two", boss.phaseTwo);
    bossHud.classList.toggle("is-excavator", boss.level === 2);
    bossHud.classList.toggle("is-aegis", boss.level === 3);

    if (bossStatusText) {
      bossStatusText.textContent = boss.phaseTwo
        ? config.phaseTwoStatus
        : config.phaseOneStatus;
    }
  }

  function resetBossState() {
    const config = LEVEL_CONFIG[currentLevel].boss;

    destroyedEnemyCount = 0;
    bossEncounter = "idle";
    bossWarningClock = 0;
    boss = null;
    bossBullets = [];
    bossWarnings = [];
    bossAttackTimer = 0;
    nextBossAttack = "fan";
    bossRewardAwarded = false;
    outcome = null;

    bossWarningEl.hidden = true;
    bossWarningKicker.textContent = config.warningKicker;
    bossWarningTitle.textContent = config.warningTitle;
    bossWarningSub.textContent = config.warningSub;
    bossWarningTimer.textContent = formatWarningTime(BOSS_WARNING_TIME);
    bossHud.hidden = true;
    bossHud.classList.remove("is-phase-two", "is-excavator", "is-aegis");
    bossHealthFill.style.width = "100%";
    bossHealthBar.setAttribute("aria-valuemax", String(config.maxHp));
    bossHealthBar.setAttribute("aria-valuenow", String(config.maxHp));
    bossHpText.textContent = `${config.maxHp} / ${config.maxHp}`;
    bossNameOutput.textContent = config.name;
    bossPhaseText.textContent = config.phaseOneLabel;
    if (bossStatusText) {
      bossStatusText.textContent = config.phaseOneStatus;
    }
  }

  /* ---------- 关卡入口、横幅与关卡化 UI ---------- */

  function readLevelFromUrl() {
    const value = new URLSearchParams(window.location.search).get("level");
    if (value === "3") {
      return 3;
    }
    return value === "2" ? 2 : 1;
  }

  function syncLevelUi() {
    const levelConfig = LEVEL_CONFIG[currentLevel];

    levelButtons.forEach((button) => {
      const isActive = Number(button.dataset.level) === currentLevel;
      button.classList.toggle("is-active", isActive);
      button.setAttribute("aria-pressed", isActive ? "true" : "false");
    });

    brandEyebrow.textContent = levelConfig.eyebrow;
    killLabel.textContent = levelConfig.killsLabel;
    if (currentLevel === 2) {
      footerTip.textContent = "清空 3 波敌机后进入 BOSS 战 · 陨石可挡子弹";
    } else if (currentLevel === 3) {
      footerTip.textContent = "清空 3 波敌机后进入 BOSS 战 · 躲避激光栅格";
    } else {
      footerTip.innerHTML = levelOneFooterTipHtml;
    }
  }

  function showLevelBanner(kicker, title, sub, duration) {
    levelBannerKicker.textContent = kicker;
    levelBannerTitle.textContent = title;
    levelBannerSub.textContent = sub;
    levelBannerEl.hidden = false;
    waveBannerClock = duration;
  }

  function hideLevelBanner() {
    levelBannerEl.hidden = true;
  }

  function setLevel(nextLevel) {
    currentLevel = nextLevel === 2 || nextLevel === 3 ? nextLevel : 1;
    resetRound();
    canvas.focus({ preventScroll: true });
  }

  /* ---------- 一局的生命周期 ---------- */

  function resetRound() {
    const levelConfig = LEVEL_CONFIG[currentLevel];

    state = State.PLAYING;
    score = 0;
    lives = MAX_LIVES;
    elapsed = 0;
    spawnClock = INITIAL_SPAWN_DELAY;
    fireClock = 0;
    muzzleFlashClock = 0;
    lastShotMuzzles = [];
    shakeClock = 0;
    damageFlash = 0;
    nextEnemyId = 1;
    player = createPlayer();
    bullets = [];
    enemies = [];
    particles = [];
    rocks = [];
    enemyBullets = [];
    nextRockId = 1;
    lasers = [];
    nextLaserId = 1;
    levelLaserTimer = 0;
    levelFlow = hasWaveFlow() ? "intro" : "idle";
    wave = 0;
    waveKills = 0;
    spawnIndex = 0;
    waveBannerClock = 0;
    keys.clear();
    resetBossState();

    overlay.hidden = true;
    overlay.classList.remove("is-victory");
    pauseOverlay.hidden = true;
    stage.classList.remove("is-over", "is-paused");
    outcomeEyebrow.textContent = "MISSION FAILED";
    outcomeEyebrow.classList.add("danger");
    // 结算层默认文案按关卡设置，避免短暂显示另一关的文案。
    gameOverTitle.textContent = levelConfig.defeatTitle;
    outcomeSummary.hidden = true;
    outcomeSummary.textContent = "";
    finalLabel.textContent = "本局得分";
    finalScoreOutput.textContent = padScore(0);

    if (currentLevel === 2) {
      showLevelBanner(
        "SECTOR 02",
        levelConfig.title,
        "EXCAVATION SECTOR",
        WAVE_BANNER_TIME,
      );
    } else if (currentLevel === 3) {
      showLevelBanner(
        "SECTOR 03",
        levelConfig.title,
        "ORBITAL DRYDOCK",
        WAVE_BANNER_TIME,
      );
    } else {
      levelBannerEl.hidden = true;
      waveBannerClock = 0;
    }

    syncLevelUi();
    updateHud();
    lastFrameTime = performance.now();
  }

  function restartGame() {
    resetRound();
    canvas.focus({ preventScroll: true });
  }

  function finishRound(result) {
    if (state === State.GAME_OVER) {
      return;
    }

    const levelConfig = LEVEL_CONFIG[currentLevel];
    const reward = boss ? boss.reward : levelConfig.boss.reward;

    state = State.GAME_OVER;
    outcome = result;
    keys.clear();
    shakeClock = 0;
    damageFlash = 0;
    bossWarningEl.hidden = true;
    bossHud.hidden = true;
    pauseOverlay.hidden = true;
    levelBannerEl.hidden = true;
    stage.classList.remove("is-paused");

    const won = result === "victory";

    if (won && !bossRewardAwarded) {
      bossRewardAwarded = true;
      score += reward;
    }

    updateHud();
    overlay.classList.toggle("is-victory", won);
    stage.classList.add("is-over");
    outcomeEyebrow.textContent = won ? "MISSION COMPLETE" : "MISSION FAILED";
    outcomeEyebrow.classList.toggle("danger", !won);
    gameOverTitle.textContent = won
      ? levelConfig.victoryTitle
      : levelConfig.defeatTitle;
    outcomeSummary.hidden = !won;
    outcomeSummary.textContent = won
      ? `${levelConfig.rewardPrefix}${reward}`
      : "";
    finalLabel.textContent = won ? "最终得分" : "本局得分";
    finalScoreOutput.textContent = padScore(score);
    overlay.hidden = false;
    restartButton.focus({ preventScroll: true });
  }

  function resolveRoundOutcome() {
    if (state !== State.PLAYING) {
      return;
    }

    // 同一帧双方归零时，玩家失败优先；Boss 奖励也只在真正胜利时结算。
    if (lives <= 0) {
      finishRound("defeat");
      return;
    }

    if (boss && boss.defeated) {
      finishRound("victory");
    }
  }

  function pauseGame() {
    if (state !== State.PLAYING) {
      return;
    }

    state = State.PAUSED;
    // 暂停只冻结游戏更新，不清空按键状态；暂停期间松开的键仍由 keyup 移除。
    pauseOverlay.hidden = false;
    stage.classList.add("is-paused");
  }

  function resumeGame() {
    if (state !== State.PAUSED) {
      return;
    }

    state = State.PLAYING;
    pauseOverlay.hidden = true;
    stage.classList.remove("is-paused");
    lastFrameTime = performance.now();
    canvas.focus({ preventScroll: true });
  }

  /* ---------- 键盘输入 ---------- */

  function isGameKey(code) {
    return (
      code === "Space" ||
      code.startsWith("Arrow") ||
      code === "KeyW" ||
      code === "KeyA" ||
      code === "KeyS" ||
      code === "KeyD"
    );
  }

  function isPauseKey(code) {
    return code === "KeyP" || code === "Escape";
  }

  function isInteractiveTarget(target) {
    return (
      target instanceof Element &&
      Boolean(target.closest("button, a, input, textarea, select"))
    );
  }

  window.addEventListener("keydown", (event) => {
    const code = event.code;
    const gameKey = isGameKey(code);
    const pauseKey = isPauseKey(code);
    const onControl = isInteractiveTarget(event.target);

    // 阻止方向键滚动页面 / 空格键触发页面滚动。按钮聚焦时保留原生激活。
    if ((gameKey || pauseKey) && !onControl) {
      event.preventDefault();
    }

    if (state === State.GAME_OVER) {
      if ((code === "Enter" || code === "Space") && !onControl) {
        restartGame();
      }
      return;
    }

    if (pauseKey) {
      if (event.repeat) {
        return;
      }

      if (state === State.PLAYING) {
        pauseGame();
      } else if (state === State.PAUSED) {
        resumeGame();
      }
      return;
    }

    if (state === State.PAUSED) {
      return;
    }

    if (gameKey) {
      keys.add(code);
    }
  });

  window.addEventListener("keyup", (event) => {
    // 暂停中也同步松开状态，恢复时不会继续保留已经放开的键。
    keys.delete(event.code);
  });

  window.addEventListener("blur", () => {
    keys.clear();
  });

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      keys.clear();
    }
  });

  restartButton.addEventListener("click", () => {
    restartGame();
  });

  levelButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setLevel(Number(button.dataset.level));
    });
  });

  canvas.addEventListener("pointerdown", () => {
    canvas.focus({ preventScroll: true });
  });

  /* ---------- 玩家 ---------- */

  function updatePlayer(dt) {
    const left = keys.has("ArrowLeft") || keys.has("KeyA");
    const right = keys.has("ArrowRight") || keys.has("KeyD");
    const up = keys.has("ArrowUp") || keys.has("KeyW");
    const down = keys.has("ArrowDown") || keys.has("KeyS");

    let dx = Number(right) - Number(left);
    let dy = Number(down) - Number(up);

    if (dx !== 0 && dy !== 0) {
      const diagonal = Math.SQRT1_2;
      dx *= diagonal;
      dy *= diagonal;
    }

    player.x = clamp(
      player.x + dx * PLAYER_SPEED * dt,
      PLAYER_HALF_W + 6,
      W - PLAYER_HALF_W - 6,
    );
    player.y = clamp(
      player.y + dy * PLAYER_SPEED * dt,
      PLAYER_HALF_H + 6,
      H - PLAYER_HALF_H - 6,
    );

    const targetTilt = dx * 0.16;
    const smoothing = 1 - Math.exp(-12 * dt);
    player.tilt += (targetTilt - player.tilt) * smoothing;

    if (player.invulnerable > 0) {
      player.invulnerable = Math.max(0, player.invulnerable - dt);
    }
  }

  function updateShooting(dt) {
    fireClock = Math.max(0, fireClock - dt);

    if (!keys.has("Space") || fireClock > 0) {
      return;
    }

    // 双发等离子弹；任一发命中即可摧毁一架敌机。
    // 每发子弹都从当前帧对应的炮口世界坐标出生。
    const muzzles = getMuzzleWorldPositions();
    lastShotMuzzles = muzzles.map((muzzle) => ({ ...muzzle }));

    for (const muzzle of muzzles) {
      bullets.push({
        x: muzzle.x,
        y: muzzle.y,
        originX: muzzle.x,
        originY: muzzle.y,
        side: muzzle.side,
        vy: -BULLET_SPEED,
        halfW: 2.5,
        halfH: 9,
      });
    }

    muzzleFlashClock = MUZZLE_FLASH_TIME;
    fireClock = PLAYER_FIRE_INTERVAL;
  }

  /* ---------- 敌机 ---------- */

  function createEnemy(options = {}) {
    const kind = options.kind === "sapper" ? "sapper" : "charger";
    const isSapper = kind === "sapper";
    const speedRamp = Math.min(elapsed * 2.1, 105);
    const startX = clamp(
      options.x ?? random(56, W - 56),
      52,
      W - 52,
    );
    const sway = isSapper ? 0 : options.sway ?? random(7, 25);
    const maxHp = Math.max(
      1,
      Math.round(options.hp ?? (isSapper ? SAPPER_HP : 1)),
    );

    return {
      id: nextEnemyId++,
      kind,
      x: startX,
      baseX: startX,
      y: options.y ?? -38,
      speed: isSapper
        ? SAPPER_DESCENT_SPEED
        : options.speed ?? random(92, 128) + speedRamp,
      sway,
      swayRate: random(1.1, 2.2),
      phase: random(0, TAU),
      age: 0,
      hp: maxHp,
      maxHp,
      points: isSapper ? SAPPER_POINTS : SCORE_PER_ENEMY,
      holdY: isSapper
        ? random(SAPPER_HOLD_Y_MIN, SAPPER_HOLD_Y_MAX)
        : null,
      strafePhase: isSapper ? random(0, TAU) : 0,
      fireTimer: isSapper ? random(0.8, 1.6) : 0,
      fireFlash: 0,
      hitFlash: 0,
      destroyed: false,
      hasHitPlayer: false,
      hitHalfW: isSapper ? 19 : 17,
      hitHalfH: isSapper ? 15 : 14,
    };
  }

  function spawnEnemy(kind = "charger") {
    const enemy = createEnemy({ kind });
    enemies.push(enemy);
    return enemy;
  }

  function updateSpawner(dt) {
    // 第 10 架普通敌机被击毁后永久停用普通生成器，直到重开。
    if (bossEncounter !== "idle" || destroyedEnemyCount >= BOSS_KILL_TARGET) {
      return;
    }

    spawnClock -= dt;
    if (spawnClock > 0) {
      return;
    }

    spawnEnemy();

    // 难度随时间平缓上升，但每局都会从同样的基础速度与间隔开始。
    const interval = Math.max(
      MIN_SPAWN_INTERVAL,
      0.95 - elapsed * 0.0075,
    );
    spawnClock = interval * random(0.88, 1.12);
  }

  function updateEnemies(dt) {
    for (let i = enemies.length - 1; i >= 0; i -= 1) {
      const enemy = enemies[i];
      enemy.age += dt;
      enemy.hitFlash = Math.max(0, enemy.hitFlash - dt);
      enemy.fireFlash = Math.max(0, enemy.fireFlash - dt);

      if (enemy.kind === "sapper") {
        updateSapper(enemy, dt);
        continue;
      }

      enemy.y += enemy.speed * dt;
      enemy.x = clamp(
        enemy.baseX + Math.sin(enemy.age * enemy.swayRate + enemy.phase) * enemy.sway,
        20,
        W - 20,
      );

      if (enemy.y - enemy.hitHalfH > H + 34) {
        enemies.splice(i, 1);
      }
    }
  }

  // Sapper：下降到停驻高度后小幅横移，按固定间隔打慢速瞄准弹（无预警）。
  function updateSapper(enemy, dt) {
    if (enemy.y < enemy.holdY) {
      enemy.y = Math.min(enemy.holdY, enemy.y + SAPPER_DESCENT_SPEED * dt);
      return;
    }

    enemy.x = clamp(
      enemy.baseX + Math.sin(enemy.age * 0.8 + enemy.strafePhase) * SAPPER_STRAFE_RANGE,
      24,
      W - 24,
    );

    enemy.fireTimer -= dt;
    if (enemy.fireTimer <= 0) {
      fireSapperShot(enemy);
    }
  }

  /* ---------- 岩石掩体（第二关） ---------- */

  function createRock(x, y, radius, size = null, hp = null) {
    const actualSize = size ?? (radius >= 32 ? "large" : "small");
    const maxHp = Math.max(
      1,
      Math.round(hp ?? (actualSize === "large" ? 2 : 1)),
    );
    const shape = [];
    const vertexCount = 9;

    for (let i = 0; i < vertexCount; i += 1) {
      shape.push({
        angle: (TAU * i) / vertexCount + random(-0.09, 0.09),
        factor: random(0.76, 1.02),
      });
    }

    return {
      id: nextRockId++,
      x,
      y,
      radius,
      size: actualSize,
      hp: maxHp,
      maxHp,
      hitFlash: 0,
      rotation: random(0, TAU),
      spin: random(-0.15, 0.15),
      shape,
    };
  }

  function createRockLayout(layoutKey) {
    const layout = ROCK_LAYOUTS[layoutKey] ?? [];
    return layout.map((spec) => createRock(spec.x, spec.y, spec.radius, spec.size));
  }

  function resetRocksForWave(waveIndex) {
    rocks = createRockLayout(waveIndex);
  }

  function resetRocksForBoss() {
    rocks = createRockLayout("boss");
  }

  function damageRock(rock, amount, source) {
    if (!rock || rock.hp <= 0) {
      return;
    }

    rock.hp -= amount;
    rock.hitFlash = 0.14;
    burst(rock.x, rock.y, 4, "#ffd8a0", 110);

    if (rock.hp <= 0) {
      destroyRock(rock, source);
    }
  }

  function destroyRock(rock, source) {
    const index = rocks.indexOf(rock);
    if (index === -1) {
      return;
    }

    rocks.splice(index, 1);
    rock.hp = 0;
    burst(
      rock.x,
      rock.y,
      rock.size === "large" ? 20 : 11,
      "#c9d7e2",
      rock.size === "large" ? 205 : 160,
    );

    // 只有玩家打碎的岩石给分；Boss 震碎/冲锋撞碎不给分，也不计入击杀配额。
    if (source === "player") {
      score += ROCK_SCORE;
      updateHud();
    }
  }

  // 线段 vs 圆：高速子弹单帧位移约 12.7px，必须用扫掠检测防止穿小岩石。
  function segmentCircleHit(x0, y0, x1, y1, cx, cy, radius) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const lengthSq = dx * dx + dy * dy;
    let t = 0;

    if (lengthSq > 1e-6) {
      t = clamp(((cx - x0) * dx + (cy - y0) * dy) / lengthSq, 0, 1);
    }

    const offsetX = x0 + dx * t - cx;
    const offsetY = y0 + dy * t - cy;
    return offsetX * offsetX + offsetY * offsetY <= radius * radius;
  }

  function findRockHit(x0, y0, x1, y1, radius) {
    for (const rock of rocks) {
      if (segmentCircleHit(x0, y0, x1, y1, rock.x, rock.y, rock.radius + radius)) {
        return rock;
      }
    }

    return null;
  }

  function updateRocks(dt) {
    if (rocks.length === 0) {
      return;
    }

    for (const rock of rocks) {
      rock.rotation += rock.spin * dt;
      rock.hitFlash = Math.max(0, rock.hitFlash - dt);
    }
  }

  // Boss 冲锋扫掠：用本帧 oldX→newX 的横向范围判断，避免高速穿过岩石时漏判。
  function destroyRocksInSweep(oldX, newX, centerY, halfH) {
    const minX = Math.min(oldX, newX);
    const maxX = Math.max(oldX, newX);

    for (let i = rocks.length - 1; i >= 0; i -= 1) {
      const rock = rocks[i];
      const overlapsX =
        rock.x + rock.radius >= minX && rock.x - rock.radius <= maxX;
      const overlapsY = Math.abs(rock.y - centerY) <= halfH + rock.radius;

      if (overlapsX && overlapsY) {
        destroyRock(rock, "boss");
      }
    }
  }

  /* ---------- Sapper 射击与敌方子弹 ---------- */

  function findSapperTarget() {
    let best = null;
    let bestDistance = Infinity;

    for (const rock of rocks) {
      if (rock.y <= player.y - SAPPER_TARGET_RANGE_Y) {
        continue;
      }
      if (rock.y >= player.y - 24) {
        continue;
      }
      if (Math.abs(rock.x - player.x) > SAPPER_TARGET_RANGE_X) {
        continue;
      }

      const distance = Math.hypot(rock.x - player.x, rock.y - player.y);
      if (distance < bestDistance) {
        best = rock;
        bestDistance = distance;
      }
    }

    return best ?? player;
  }

  function fireSapperShot(enemy) {
    const target = findSapperTarget();
    const originX = enemy.x;
    const originY = enemy.y + 16;
    const dx = target.x - originX;
    const dy = target.y - originY;
    const distance = Math.hypot(dx, dy) || 1;

    enemyBullets.push({
      x: originX,
      y: originY,
      prevX: originX,
      prevY: originY,
      vx: (dx / distance) * SAPPER_BULLET_SPEED,
      vy: (dy / distance) * SAPPER_BULLET_SPEED,
      radius: 5,
      owner: "sapper",
    });

    enemy.fireFlash = 0.12;
    enemy.fireTimer = SAPPER_FIRE_INTERVAL * random(0.94, 1.06);
    burst(originX, originY, 4, "#ffb066", 80);
  }

  function updateEnemyBullets(dt) {
    if (enemyBullets.length === 0) {
      return;
    }

    for (let i = enemyBullets.length - 1; i >= 0; i -= 1) {
      const shot = enemyBullets[i];

      shot.prevX = shot.x;
      shot.prevY = shot.y;
      shot.x += shot.vx * dt;
      shot.y += shot.vy * dt;

      if (
        shot.y - shot.radius > H + 32 ||
        shot.x < -36 ||
        shot.x > W + 36 ||
        shot.y < -80
      ) {
        enemyBullets.splice(i, 1);
        continue;
      }

      // 岩石先挡子弹：命中即造成 1 点岩石伤害并移除子弹。
      if (rocks.length > 0) {
        const rock = findRockHit(shot.prevX, shot.prevY, shot.x, shot.y, shot.radius);
        if (rock) {
          damageRock(rock, 1, "enemy");
          enemyBullets.splice(i, 1);
          continue;
        }
      }

      if (
        circlesRectsOverlap(
          player.x,
          player.y,
          player.hitHalfW,
          player.hitHalfH,
          shot.x,
          shot.y,
          shot.radius,
          shot.radius,
        )
      ) {
        enemyBullets.splice(i, 1);
        if (player.invulnerable <= 0) {
          loseLife();
        }
      }
    }
  }

  /* ---------- 第二/三关波次状态机 ---------- */

  function getMaxOnScreen(level = currentLevel) {
    return level === 3 ? LEVEL3_MAX_ON_SCREEN : LEVEL2_MAX_ON_SCREEN;
  }

  function getWaveSubtitle(level, waveIndex) {
    if (level === 3) {
      return LEVEL3_WAVE_SUBTITLES[waveIndex - 1] ?? "";
    }
    return WAVE_SUBTITLES[waveIndex - 1] ?? "";
  }

  function getWaveLaserInterval(waveIndex) {
    if (currentLevel !== 3) {
      return 0;
    }
    return waveIndex >= 3
      ? LEVEL3_LASER_INTERVAL_WAVE_THREE
      : LEVEL3_LASER_INTERVAL_WAVE_TWO;
  }

  function startLevelBossEncounter() {
    levelFlow = "idle";
    hideLevelBanner();
    if (currentLevel === 2) {
      resetRocksForBoss();
    } else {
      rocks = [];
    }
    enemyBullets = [];
    bossBullets = [];
    bossWarnings = [];
    lasers = [];
    levelLaserTimer = 0;
    beginBossWarning();
  }

  function startWave(nextWave) {
    const waveCount = getWaveCount();
    const waveIndex = clamp(nextWave, 1, waveCount);

    wave = waveIndex;
    waveKills = 0;
    spawnIndex = 0;
    if (currentLevel === 2) {
      resetRocksForWave(waveIndex);
    } else {
      rocks = [];
    }
    lasers = [];
    levelLaserTimer = 0;
    if (currentLevel === 3) {
      if (waveIndex === 2) {
        levelLaserTimer = LEVEL3_FIRST_LASER_WAVE_TWO;
      } else if (waveIndex === 3) {
        levelLaserTimer = LEVEL3_FIRST_LASER_WAVE_THREE;
      }
    }
    // 波间无 Boss，清掉残留敌方子弹；玩家子弹保留。
    enemyBullets = [];
    bossBullets = [];
    bossWarnings = [];

    levelFlow = "waveBanner";
    spawnClock = 0.35;
    showLevelBanner(
      currentLevel === 3 ? "SECTOR 03" : "SECTOR 02",
      `WAVE ${waveIndex}/${waveCount}`,
      getWaveSubtitle(currentLevel, waveIndex),
      WAVE_BANNER_TIME,
    );
    updateHud();
  }

  function updateWaveFlow(dt) {
    // 预警/Boss 由现有 bossEncounter 接管。
    if (bossEncounter !== "idle") {
      return;
    }

    if (levelFlow === "intro") {
      waveBannerClock -= dt;
      if (waveBannerClock <= 0) {
        startWave(1);
      }
      return;
    }

    if (levelFlow === "waveBanner") {
      waveBannerClock -= dt;
      if (waveBannerClock <= 0) {
        hideLevelBanner();
        levelFlow = "wave";
        spawnClock = 0.35;
      }
      return;
    }

    if (levelFlow !== "wave") {
      return;
    }

    updateWaveSpawner(dt);
    if (currentLevel === 3) {
      updateLevelLaserSpawner(dt);
    }

    // 配额达成且场上清空才进入下一波。
    if (waveKills >= getWaveQuota() && enemies.length === 0) {
      if (wave < getWaveCount()) {
        startWave(wave + 1);
      } else {
        // 最后一波清空后直接进入 2.2s Boss 预警，不再加清场横幅。
        startLevelBossEncounter();
      }
    }
  }

  function updateWaveSpawner(dt) {
    if (waveKills >= getWaveQuota()) {
      return;
    }

    // 同屏上限：槽满时把计时钳在 0，槽位一空只补一只，避免爆发式生成。
    if (enemies.length >= getMaxOnScreen()) {
      spawnClock = Math.max(spawnClock, 0);
      return;
    }

    spawnClock -= dt;
    if (spawnClock > 0) {
      return;
    }

    spawnEnemy(pickWaveEnemyKind(wave, spawnIndex));
    spawnIndex += 1;

    const config = getWaveConfig();
    spawnClock = config.spawnInterval * random(0.9, 1.1);
  }

  function pickWaveEnemyKind(waveIndex, index) {
    // 第三关没有编成序列：全部生成 Charger，压力来自配额与激光栅格。
    if (currentLevel === 3) {
      return "charger";
    }

    const sequence = WAVE_SPAWN_SEQUENCES[waveIndex] ?? [];
    if (index < sequence.length) {
      return sequence[index];
    }
    // 序列用完但配额未达成（敌机飞走）时继续补 Charger，生成器不会停死。
    return "charger";
  }

  /* ---------- 第三关激光栅格 ---------- */

  function spawnLaserGate(x, options = {}) {
    if (currentLevel !== 3) {
      return null;
    }

    const warningTime = options.warningTime ?? LASER_WARNING_TIME;
    const activeTime = options.activeTime ?? LASER_ACTIVE_TIME;
    const laser = {
      id: nextLaserId++,
      x: clamp(x, 48, W - 48),
      state: "warning",
      timer: warningTime,
      warningTime,
      activeTime,
      width: options.width ?? LASER_WIDTH,
      source: options.source ?? "wave",
    };

    lasers.push(laser);
    return laser.id;
  }

  function updateLevelLaserSpawner(dt) {
    if (
      currentLevel !== 3 ||
      bossEncounter !== "idle" ||
      levelFlow !== "wave" ||
      wave < 2 ||
      lasers.length > 0
    ) {
      return;
    }

    levelLaserTimer -= dt;
    if (levelLaserTimer > 0) {
      return;
    }

    spawnLaserGate(player.x, { source: "wave" });
    // 计时从“下一次生成”倒推，扣除本次预警+持续时间，保证两次激光的
    // 起始间隔接近配置的 7.0s / 5.5s，而不是再叠加 1.7s。
    levelLaserTimer = Math.max(
      0.5,
      getWaveLaserInterval(wave) - (LASER_WARNING_TIME + LASER_ACTIVE_TIME),
    );
  }

  function updateLasers(dt) {
    if (lasers.length === 0) {
      return;
    }

    for (let i = lasers.length - 1; i >= 0; i -= 1) {
      const laser = lasers[i];
      laser.timer -= dt;

      if (laser.state === "warning") {
        if (laser.timer <= 0) {
          laser.state = "active";
          laser.timer = laser.activeTime;
          burst(laser.x, H - 24, 12, "#ff8ad8", 190);
          shakeClock = Math.max(shakeClock, 0.16);
        }
        continue;
      }

      if (laser.timer <= 0) {
        lasers.splice(i, 1);
        continue;
      }

      // 固定纵列：只判横向重叠，贯穿整个画面高度；无敌帧防止一束光连续掉命。
      if (
        player.invulnerable <= 0 &&
        Math.abs(player.x - laser.x) <= laser.width / 2 + player.hitHalfW
      ) {
        loseLife();
      }
    }
  }

  /* ---------- Boss 战 ---------- */

  function beginBossWarning() {
    if (bossEncounter !== "idle") {
      return;
    }

    const config = LEVEL_CONFIG[currentLevel].boss;

    bossEncounter = "warning";
    bossWarningClock = BOSS_WARNING_TIME;
    bossWarningKicker.textContent = config.warningKicker;
    bossWarningTitle.textContent = config.warningTitle;
    bossWarningSub.textContent = config.warningSub;
    bossWarningEl.hidden = false;
    hideLevelBanner();
    bossWarningTimer.textContent = formatWarningTime(bossWarningClock);
    bossHud.hidden = true;
    // 清空残余普通敌机与激光，预警结束后场上只保留这一架 Boss。
    enemies.length = 0;
    lasers = [];
    levelLaserTimer = 0;
  }

  function createBoss(level = currentLevel) {
    const bossLevel = level === 2 || level === 3 ? level : 1;
    const config = LEVEL_CONFIG[bossLevel].boss;

    const created = {
      level: bossLevel,
      kind: bossLevel === 2 ? "excavator" : bossLevel === 3 ? "aegis" : "cruiser",
      x: W / 2,
      y: -90,
      targetY: bossLevel === 3 ? BOSS3_ENTRY_TARGET_Y : BOSS_ENTRY_TARGET_Y,
      hp: config.maxHp,
      maxHp: config.maxHp,
      reward: config.reward,
      state: "entering",
      phaseTwo: false,
      phaseTransitions: 0,
      age: 0,
      hitHalfW: bossLevel === 3 ? 104 : 92,
      hitHalfH: bossLevel === 3 ? 44 : 47,
      hitFlash: 0,
      muzzleFlash: 0,
      defeated: false,
    };

    if (bossLevel === 2) {
      Object.assign(created, {
        moveDir: 1,
        moveSpeed: BOSS2_MOVE_SPEED,
        chargeState: "idle",
        chargeClock: 0,
        chargeTimer: BOSS2_FIRST_CHARGE_DELAY,
        chargeDir: 1,
        chargeFromX: W / 2,
        chargeCount: 0,
        shardTimer: BOSS2_FIRST_SHARD_DELAY,
        coreExposed: false,
        coreRadius: LEVEL2_CORE_RADIUS,
        waveClock: 0,
        drillAngle: 0,
      });
    }

    if (bossLevel === 3) {
      Object.assign(created, {
        moveDir: 1,
        moveSpeed: BOSS3_MOVE_SPEED,
        burstTimer: BOSS3_FIRST_BURST_DELAY,
        laserTimer: BOSS3_FIRST_LASER_DELAY,
        waveClock: 0,
      });
    }

    return created;
  }

  function spawnBoss() {
    bossWarningEl.hidden = true;
    bossEncounter = "boss";
    boss = createBoss(currentLevel);
    bossAttackTimer = 1.15;
    updateBossHud();
    burst(
      W / 2,
      54,
      currentLevel === 2 ? 30 : 32,
      currentLevel === 2 ? "#ffb066" : currentLevel === 3 ? "#8cf5ff" : "#ff7ca2",
      210,
    );
    shakeClock = 0.34;
  }

  function enterBossPhaseTwo() {
    if (!boss || boss.phaseTwo || boss.defeated) {
      return;
    }

    boss.phaseTwo = true;
    boss.phaseTransitions += 1;
    nextBossAttack = "lock";
    if (bossWarnings.length === 0) {
      bossAttackTimer = Math.min(bossAttackTimer, 0.7);
    }
    updateBossHud();
    burst(boss.x, boss.y, 36, "#72eeff", 240);
    shakeClock = 0.3;
  }

  /* ---------- Boss 2 · EXCAVATOR-02 / 矿脉钻机 ---------- */

  function enterBoss2PhaseTwo() {
    if (!boss || boss.level !== 2 || boss.phaseTwo || boss.defeated) {
      return;
    }

    boss.phaseTwo = true;
    boss.phaseTransitions += 1;
    boss.coreExposed = true;
    boss.waveClock = 0.7;

    // 转阶段冲击波：震碎剩余岩石，不伤害玩家，后半场变开阔地。
    for (let i = rocks.length - 1; i >= 0; i -= 1) {
      destroyRock(rocks[i], "boss");
    }
    enemyBullets = [];

    boss.chargeTimer = Math.min(boss.chargeTimer, 1);
    boss.shardTimer = Math.min(boss.shardTimer, 0.8);
    boss.chargeCount = 0;

    updateBossHud();
    burst(boss.x, boss.y, 46, "#ffd37a", 300);
    burst(boss.x, boss.y, 26, "#8cf5ff", 220);
    shakeClock = 0.42;
  }

  function updateBoss2(dt) {
    if (!boss || boss.level !== 2 || boss.state !== "active" || boss.defeated) {
      return;
    }

    boss.waveClock = Math.max(0, boss.waveClock - dt);
    boss.moveSpeed = boss.phaseTwo
      ? BOSS2_MOVE_SPEED_PHASE_TWO
      : BOSS2_MOVE_SPEED;

    const spin =
      boss.chargeState === "windup"
        ? 26
        : boss.chargeState === "dash"
          ? 34
          : 1.8;
    boss.drillAngle = (boss.drillAngle + spin * dt) % TAU;

    updateBoss2Charge(dt);

    // 冲锋/起手/恢复期间不执行常规横移。
    if (boss.chargeState === "idle") {
      boss.x += boss.moveDir * boss.moveSpeed * dt;
      if (boss.x >= W - BOSS2_EDGE_MARGIN) {
        boss.x = W - BOSS2_EDGE_MARGIN;
        boss.moveDir = -1;
      } else if (boss.x <= BOSS2_EDGE_MARGIN) {
        boss.x = BOSS2_EDGE_MARGIN;
        boss.moveDir = 1;
      }
    }

    boss.y = boss.targetY + Math.sin(boss.age * 1.35) * 9;

    boss.shardTimer -= dt;
    if (boss.shardTimer <= 0) {
      fireBoss2Shards();
    }
  }

  function updateBoss2Charge(dt) {
    if (boss.chargeState === "idle") {
      boss.chargeTimer -= dt;

      if (boss.chargeTimer <= 0) {
        boss.chargeState = "windup";
        boss.chargeClock = boss.phaseTwo
          ? BOSS2_CHARGE_WINDUP_PHASE_TWO
          : BOSS2_CHARGE_WINDUP;
        boss.chargeDir = Math.sign(player.x - boss.x) || 1;
        if (boss.x < 150) {
          boss.chargeDir = 1;
        }
        if (boss.x > W - 150) {
          boss.chargeDir = -1;
        }
        boss.chargeFromX = boss.x;
      }
      return;
    }

    boss.chargeClock -= dt;

    if (boss.chargeState === "windup") {
      if (boss.chargeClock <= 0) {
        const targetX =
          boss.chargeDir < 0 ? BOSS2_EDGE_MARGIN : W - BOSS2_EDGE_MARGIN;
        const distance = Math.abs(targetX - boss.x);
        boss.chargeState = "dash";
        boss.chargeClock = Math.max(0.18, distance / BOSS2_CHARGE_SPEED);
        boss.chargeFromX = boss.x;
      }
      return;
    }

    if (boss.chargeState === "dash") {
      const oldX = boss.x;
      boss.x = clamp(
        boss.x + boss.chargeDir * BOSS2_CHARGE_SPEED * dt,
        BOSS2_EDGE_MARGIN,
        W - BOSS2_EDGE_MARGIN,
      );
      destroyRocksInSweep(oldX, boss.x, boss.y, boss.hitHalfH);

      if (
        boss.x <= BOSS2_EDGE_MARGIN ||
        boss.x >= W - BOSS2_EDGE_MARGIN ||
        boss.chargeClock <= 0
      ) {
        boss.chargeState = "recover";
        boss.chargeClock = BOSS2_CHARGE_RECOVER;
        if (boss.phaseTwo && boss.chargeCount === 0) {
          boss.chargeCount = 1;
        }
      }
      return;
    }

    if (boss.chargeState === "recover" && boss.chargeClock <= 0) {
      if (boss.phaseTwo && boss.chargeCount === 1) {
        // Phase 2 双冲：第二段起手更短，方向相反。
        boss.chargeCount = 2;
        boss.chargeState = "windup";
        boss.chargeClock = BOSS2_CHARGE_WINDUP_PHASE_TWO;
        boss.chargeDir *= -1;
        boss.chargeFromX = boss.x;
      } else {
        boss.chargeState = "idle";
        boss.chargeTimer = boss.phaseTwo
          ? BOSS2_CHARGE_INTERVAL_PHASE_TWO
          : BOSS2_CHARGE_INTERVAL;
        boss.chargeCount = 0;
        // 冲锋停在边界，常规横移立刻朝内，避免贴边卡住。
        if (boss.x <= BOSS2_EDGE_MARGIN) {
          boss.moveDir = 1;
        } else if (boss.x >= W - BOSS2_EDGE_MARGIN) {
          boss.moveDir = -1;
        }
      }
    }
  }

  function fireBoss2Shards() {
    if (!boss || boss.level !== 2 || boss.state !== "active" || boss.defeated) {
      return;
    }

    const originX = boss.x;
    const originY = boss.y + 34;
    const count = boss.phaseTwo
      ? BOSS2_SHARD_COUNT_PHASE_TWO
      : BOSS2_SHARD_COUNT;

    if (boss.phaseTwo) {
      // Phase 2：10 发径向碎石，整圈均匀分布并缓慢旋转。
      const offset = boss.age * 0.6;
      for (let i = 0; i < count; i += 1) {
        const angle = offset + (TAU * i) / count;
        bossBullets.push({
          x: originX,
          y: originY,
          prevX: originX,
          prevY: originY,
          vx: Math.cos(angle) * BOSS2_SHARD_SPEED,
          vy: Math.sin(angle) * BOSS2_SHARD_SPEED,
          radius: 6.5,
          phaseTwo: true,
          level: 2,
        });
      }
    } else {
      // Phase 1：5 发向下扇形，中心角朝玩家并夹在下压范围。
      const straightDown = Math.PI / 2;
      const aimAngle = Math.atan2(player.y - originY, player.x - originX);
      const centerAngle = clamp(
        aimAngle,
        straightDown - BOSS2_SHARD_SPREAD,
        straightDown + BOSS2_SHARD_SPREAD,
      );
      const lastIndex = Math.max(1, count - 1);

      for (let i = 0; i < count; i += 1) {
        const angle =
          centerAngle -
          BOSS2_SHARD_SPREAD +
          (BOSS2_SHARD_SPREAD * 2 * i) / lastIndex;

        bossBullets.push({
          x: originX,
          y: originY,
          prevX: originX,
          prevY: originY,
          vx: Math.cos(angle) * BOSS2_SHARD_SPEED,
          vy: Math.sin(angle) * BOSS2_SHARD_SPEED,
          radius: 6.5,
          phaseTwo: false,
          level: 2,
        });
      }
    }

    // 第二关碎石无开火预警，直接生成子弹。
    boss.muzzleFlash = 0.2;
    burst(originX, originY, 12, "#ffb066", 160);
    boss.shardTimer = boss.phaseTwo
      ? BOSS2_SHARD_INTERVAL_PHASE_TWO
      : BOSS2_SHARD_INTERVAL;
  }

  /* ---------- Boss 3 · AEGIS-03 / 环轨母舰 ---------- */

  function enterBoss3PhaseTwo() {
    if (!boss || boss.level !== 3 || boss.phaseTwo || boss.defeated) {
      return;
    }

    boss.phaseTwo = true;
    boss.phaseTransitions += 1;
    boss.waveClock = 0.8;
    boss.burstTimer = 1.0;
    boss.laserTimer = 1.2;

    // 转阶段清空激光，给玩家一个短暂呼吸窗口；不伤害玩家。
    lasers = [];

    updateBossHud();
    burst(boss.x, boss.y, 48, "#ff8ad8", 320);
    burst(boss.x, boss.y, 28, "#8cf5ff", 240);
    shakeClock = 0.42;
  }

  function updateBoss3(dt) {
    if (!boss || boss.level !== 3 || boss.state !== "active" || boss.defeated) {
      return;
    }

    boss.waveClock = Math.max(0, boss.waveClock - dt);
    boss.moveSpeed = boss.phaseTwo
      ? BOSS3_MOVE_SPEED_PHASE_TWO
      : BOSS3_MOVE_SPEED;

    boss.x += boss.moveDir * boss.moveSpeed * dt;
    if (boss.x >= W - BOSS3_EDGE_MARGIN) {
      boss.x = W - BOSS3_EDGE_MARGIN;
      boss.moveDir = -1;
    } else if (boss.x <= BOSS3_EDGE_MARGIN) {
      boss.x = BOSS3_EDGE_MARGIN;
      boss.moveDir = 1;
    }

    boss.y = boss.targetY + Math.sin(boss.age * 1.15) * 10;

    boss.burstTimer -= dt;
    if (boss.burstTimer <= 0) {
      fireBoss3Burst();
    }

    if (boss.phaseTwo) {
      boss.laserTimer -= dt;
      if (boss.laserTimer <= 0) {
        spawnLaserGate(player.x, {
          source: "boss",
          warningTime: BOSS3_LASER_WARNING_TIME,
          activeTime: BOSS3_LASER_ACTIVE_TIME,
        });
        boss.laserTimer = BOSS3_LASER_INTERVAL;
        burst(boss.x, boss.y + 42, 8, "#ff8ad8", 120);
      }
    }
  }

  function fireBoss3Burst() {
    if (!boss || boss.level !== 3 || boss.state !== "active" || boss.defeated) {
      return;
    }

    const originX = boss.x;
    const originY = boss.y + 48;
    const count = boss.phaseTwo
      ? BOSS3_BURST_COUNT_PHASE_TWO
      : BOSS3_BURST_COUNT;
    const speed = boss.phaseTwo
      ? BOSS3_BURST_SPEED_PHASE_TWO
      : BOSS3_BURST_SPEED;
    const straightDown = Math.PI / 2;
    const aimAngle = Math.atan2(player.y - originY, player.x - originX);
    const centerAngle = clamp(
      aimAngle,
      straightDown - BOSS3_BURST_DOWNWARD_LIMIT,
      straightDown + BOSS3_BURST_DOWNWARD_LIMIT,
    );
    const lastIndex = Math.max(1, count - 1);

    for (let i = 0; i < count; i += 1) {
      const angle =
        centerAngle -
        BOSS3_BURST_SPREAD +
        (BOSS3_BURST_SPREAD * 2 * i) / lastIndex;

      bossBullets.push({
        x: originX,
        y: originY,
        prevX: originX,
        prevY: originY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: 6,
        phaseTwo: boss.phaseTwo,
        level: 3,
      });
    }

    boss.muzzleFlash = 0.2;
    burst(originX, originY, 12, "#8cf5ff", 160);
    boss.burstTimer = boss.phaseTwo
      ? BOSS3_BURST_INTERVAL_PHASE_TWO
      : BOSS3_BURST_INTERVAL;
  }

  function damageBoss(amount) {
    if (!boss || boss.defeated) {
      return;
    }

    boss.hitFlash = 0.14;
    boss.hp = Math.max(0, boss.hp - amount);
    updateBossHud();

    if (!boss.phaseTwo && boss.hp > 0 && boss.hp <= boss.maxHp * 0.5) {
      if (boss.level === 2) {
        enterBoss2PhaseTwo();
      } else if (boss.level === 3) {
        enterBoss3PhaseTwo();
      } else {
        enterBossPhaseTwo();
      }
    }

    if (boss.hp <= 0) {
      defeatBoss();
    }
  }

  function defeatBoss() {
    if (!boss || boss.defeated) {
      return;
    }

    boss.defeated = true;
    boss.state = "defeated";
    boss.hp = 0;
    updateBossHud();
    burst(boss.x, boss.y, 92, "#ffd37a", 360);
    burst(
      boss.x,
      boss.y,
      54,
      boss.level === 2 ? "#ffb066" : boss.level === 3 ? "#8cf5ff" : "#ff5d94",
      290,
    );
    shakeClock = 0.72;
  }

  function startBossFanAttack() {
    if (!boss || boss.state !== "active") {
      return;
    }

    const originX = boss.x;
    const originY = boss.y + 42;
    const straightDown = Math.PI / 2;
    const aimAngle = Math.atan2(player.y - originY, player.x - originX);
    const centerAngle = clamp(aimAngle, straightDown - 0.62, straightDown + 0.62);
    const phaseTwo = boss.phaseTwo;

    bossWarnings.push({
      type: "fan",
      originX,
      originY,
      centerAngle,
      spread: phaseTwo ? BOSS_FAN_SPREAD_PHASE_TWO : BOSS_FAN_SPREAD,
      timer: BOSS_FAN_WARNING_TIME,
      duration: BOSS_FAN_WARNING_TIME,
      shotCount: phaseTwo ? BOSS_FAN_SHOTS_PHASE_TWO : BOSS_FAN_SHOTS,
      bulletSpeed: phaseTwo
        ? BOSS_FAN_BULLET_SPEED_PHASE_TWO
        : BOSS_FAN_BULLET_SPEED,
    });
  }

  function startBossLockAttack() {
    if (!boss || boss.state !== "active") {
      return;
    }

    bossWarnings.push({
      type: "lock",
      x: player.x,
      y: player.y,
      originX: boss.x,
      originY: boss.y + 38,
      radius: BOSS_LOCK_RADIUS,
      timer: BOSS_LOCK_WARNING_TIME,
      duration: BOSS_LOCK_WARNING_TIME,
    });
  }

  function startBossAttack() {
    if (!boss || boss.state !== "active" || boss.defeated) {
      return;
    }

    let attackType = "fan";

    if (boss.phaseTwo) {
      attackType = nextBossAttack === "lock" ? "lock" : "fan";
      nextBossAttack = attackType === "lock" ? "fan" : "lock";
    }

    if (attackType === "lock") {
      startBossLockAttack();
    } else {
      startBossFanAttack();
    }
  }

  function fireBossFan(warning) {
    if (!boss || boss.defeated) {
      return;
    }

    const count = warning.shotCount;
    const lastIndex = Math.max(1, count - 1);

    for (let i = 0; i < count; i += 1) {
      const angle =
        warning.centerAngle -
        warning.spread +
        (warning.spread * 2 * i) / lastIndex;

      bossBullets.push({
        x: warning.originX,
        y: warning.originY,
        vx: Math.cos(angle) * warning.bulletSpeed,
        vy: Math.sin(angle) * warning.bulletSpeed,
        radius: 6.5,
        phaseTwo: boss.phaseTwo,
      });
    }

    boss.muzzleFlash = 0.2;
    burst(warning.originX, warning.originY, 14, "#ff977c", 165);
    bossAttackTimer = boss.phaseTwo
      ? BOSS_ATTACK_COOLDOWN_PHASE_TWO
      : BOSS_ATTACK_COOLDOWN;
  }

  function resolveBossLock(warning) {
    const dx = Math.max(0, Math.abs(player.x - warning.x) - player.hitHalfW);
    const dy = Math.max(0, Math.abs(player.y - warning.y) - player.hitHalfH);
    const insideDanger = dx * dx + dy * dy <= warning.radius * warning.radius;

    burst(warning.x, warning.y, 34, insideDanger ? "#ffd37a" : "#ff8f7a", 280);
    shakeClock = Math.max(shakeClock, 0.34);

    if (insideDanger && player.invulnerable <= 0) {
      damageFlash = Math.max(damageFlash, 0.36);
      loseLife();
    }

    if (boss && !boss.defeated) {
      boss.muzzleFlash = 0.16;
      bossAttackTimer = boss.phaseTwo
        ? BOSS_ATTACK_COOLDOWN_PHASE_TWO
        : BOSS_ATTACK_COOLDOWN;
    }
  }

  function updateBossWarnings(dt) {
    for (let i = bossWarnings.length - 1; i >= 0; i -= 1) {
      const warning = bossWarnings[i];
      warning.timer -= dt;

      if (warning.timer > 0) {
        continue;
      }

      bossWarnings.splice(i, 1);
      if (warning.type === "fan") {
        fireBossFan(warning);
      } else {
        resolveBossLock(warning);
      }
    }
  }

  function updateBossEncounter(dt) {
    if (bossEncounter === "warning") {
      bossWarningClock = Math.max(0, bossWarningClock - dt);
      bossWarningTimer.textContent = formatWarningTime(bossWarningClock);
      if (bossWarningClock <= 0) {
        spawnBoss();
      }
      return;
    }

    if (bossEncounter !== "boss" || !boss || boss.defeated) {
      return;
    }

    boss.age += dt;
    boss.hitFlash = Math.max(0, boss.hitFlash - dt);
    boss.muzzleFlash = Math.max(0, boss.muzzleFlash - dt);

    if (boss.state === "entering") {
      boss.y = Math.min(boss.targetY, boss.y + 178 * dt);
      if (boss.y >= boss.targetY) {
        boss.state = "active";
        // 入场结束：横向/纵向摆动的相位从交战开始时重新起算。
        // boss.age 在入场阶段已累计约 1.3s；若不归零，下一帧会直接
        // 用这个相位算出 x≈646，使 Boss 在单帧内从 480 横向闪现约 166px。
        boss.age = 0;
        bossAttackTimer = 1.15;

        if (boss.level === 2) {
          boss.chargeTimer = BOSS2_FIRST_CHARGE_DELAY;
          boss.shardTimer = BOSS2_FIRST_SHARD_DELAY;
          updateBossHud();
        } else if (boss.level === 3) {
          boss.burstTimer = BOSS3_FIRST_BURST_DELAY;
          boss.laserTimer = BOSS3_FIRST_LASER_DELAY;
          updateBossHud();
        }
      }
      return;
    }

    if (boss.level === 2) {
      updateBoss2(dt);
      return;
    }

    if (boss.level === 3) {
      updateBoss3(dt);
      return;
    }

    const sweep = boss.phaseTwo ? 232 : 208;
    boss.x = clamp(
      W / 2 + Math.sin(boss.age * 0.7) * sweep,
      118,
      W - 118,
    );
    boss.y = boss.targetY + Math.sin(boss.age * 1.35) * 9;

    bossAttackTimer = Math.max(0, bossAttackTimer - dt);
    updateBossWarnings(dt);

    if (bossWarnings.length === 0 && bossAttackTimer <= 0) {
      startBossAttack();
    }
  }

  function updateBossBullets(dt) {
    for (let i = bossBullets.length - 1; i >= 0; i -= 1) {
      const shot = bossBullets[i];
      shot.prevX = shot.x;
      shot.prevY = shot.y;
      shot.x += shot.vx * dt;
      shot.y += shot.vy * dt;

      if (
        shot.y - shot.radius > H + 32 ||
        shot.x < -36 ||
        shot.x > W + 36 ||
        shot.y < -80
      ) {
        bossBullets.splice(i, 1);
        continue;
      }

      // 碎石被岩石挡住并造成 1 点岩石伤害。
      if (rocks.length > 0) {
        const rock = findRockHit(shot.prevX, shot.prevY, shot.x, shot.y, shot.radius);
        if (rock) {
          damageRock(rock, 1, "boss");
          bossBullets.splice(i, 1);
          continue;
        }
      }

      if (
        circlesRectsOverlap(
          player.x,
          player.y,
          player.hitHalfW,
          player.hitHalfH,
          shot.x,
          shot.y,
          shot.radius,
          shot.radius,
        )
      ) {
        bossBullets.splice(i, 1);
        if (player.invulnerable <= 0) {
          loseLife();
        }
      }
    }
  }

  function resolveBossBodyCollision() {
    if (!boss || boss.defeated || player.invulnerable > 0) {
      return;
    }

    if (
      circlesRectsOverlap(
        player.x,
        player.y,
        player.hitHalfW,
        player.hitHalfH,
        boss.x,
        boss.y,
        boss.hitHalfW,
        boss.hitHalfH,
      )
    ) {
      loseLife();
    }
  }

  /* ---------- 子弹与碰撞 ---------- */

  // 第二关 Phase 2 核心暴露：核心命中 2 倍伤害（24），其余身体 12。
  function getBossBulletDamage(bullet) {
    if (!boss || boss.level !== 2 || !boss.phaseTwo) {
      return PLAYER_BOSS_DAMAGE;
    }

    const coreX = boss.x;
    const coreY = boss.y + LEVEL2_CORE_OFFSET_Y;
    const reach = boss.coreRadius + Math.max(bullet.halfW, bullet.halfH);

    return Math.hypot(bullet.x - coreX, bullet.y - coreY) <= reach
      ? LEVEL2_CORE_DAMAGE
      : PLAYER_BOSS_DAMAGE;
  }

  function updateBullets(dt) {
    for (let i = bullets.length - 1; i >= 0; i -= 1) {
      const bullet = bullets[i];
      const prevY = bullet.y;
      bullet.y += bullet.vy * dt;

      if (bullet.y + bullet.halfH < -10) {
        bullets.splice(i, 1);
        continue;
      }

      // 1) 岩石先挡子弹：形成掩体，命中即 1 点岩石伤害并移除子弹。
      if (rocks.length > 0) {
        const rock = findRockHit(
          bullet.x,
          prevY,
          bullet.x,
          bullet.y,
          Math.max(bullet.halfW, 1),
        );
        if (rock) {
          bullets.splice(i, 1);
          damageRock(rock, 1, "player");
          continue;
        }
      }

      // 2) 敌机：多段 HP，只有最后一击才结算分数与击杀数。
      let hitEnemy = false;

      for (let j = enemies.length - 1; j >= 0; j -= 1) {
        const enemy = enemies[j];

        if (
          !enemy.destroyed &&
          circlesRectsOverlap(
            bullet.x,
            bullet.y,
            bullet.halfW,
            bullet.halfH,
            enemy.x,
            enemy.y,
            enemy.hitHalfW,
            enemy.hitHalfH,
          )
        ) {
          enemy.hp -= 1;
          enemy.hitFlash = 0.12;
          bullets.splice(i, 1);
          hitEnemy = true;

          if (enemy.hp > 0) {
            // Sapper 第一发只掉血：小爆裂、不移除、不加分、不计击杀。
            burst(enemy.x, enemy.y, 6, "#ff9c7a", 130);
            break;
          }

          // 先锁定结算标记，再把敌机移出数组。即使同帧有两发子弹命中，
          // 同一架敌机也只会结算一次分数和一次击毁数。
          enemy.destroyed = true;
          enemies.splice(j, 1);
          score += enemy.points;
          destroyedEnemyCount += 1;
          if (hasWaveFlow()) {
            waveKills += 1;
          }
          updateHud();
          burst(enemy.x, enemy.y, 16, "#ff719e", 185);

          // 第一关的 10 击杀触发 Boss 预警；第二关配额由波次状态机处理。
          if (currentLevel === 1 && destroyedEnemyCount >= BOSS_KILL_TARGET) {
            beginBossWarning();
          }
          break;
        }
      }

      if (hitEnemy) {
        continue;
      }

      // 3) Boss：第二关 Phase 2 核心 2 倍伤害。
      if (
        boss &&
        bossEncounter === "boss" &&
        !boss.defeated &&
        circlesRectsOverlap(
          bullet.x,
          bullet.y,
          bullet.halfW,
          bullet.halfH,
          boss.x,
          boss.y,
          boss.hitHalfW,
          boss.hitHalfH,
        )
      ) {
        bullets.splice(i, 1);
        burst(bullet.x, bullet.y, 7, "#89f7ff", 135);
        damageBoss(getBossBulletDamage(bullet));
      }
    }
  }

  function resolvePlayerCollisions() {
    for (let i = enemies.length - 1; i >= 0; i -= 1) {
      const enemy = enemies[i];

      if (enemy.hasHitPlayer) {
        continue;
      }

      const touchesPlayer = circlesRectsOverlap(
        player.x,
        player.y,
        player.hitHalfW,
        player.hitHalfH,
        enemy.x,
        enemy.y,
        enemy.hitHalfW,
        enemy.hitHalfH,
      );

      if (!touchesPlayer) {
        continue;
      }

      // 每架敌机只允许触发一次碰撞结算，并立即从场上移除。
      enemy.hasHitPlayer = true;
      enemies.splice(i, 1);
      burst(enemy.x, enemy.y, 10, "#ff9c7a", 135);

      if (player.invulnerable <= 0) {
        loseLife();
      }
    }
  }

  function loseLife() {
    lives = Math.max(0, lives - 1);
    player.invulnerable = INVULNERABLE_TIME;
    shakeClock = 0.34;
    damageFlash = 0.5;
    updateHud();
    burst(player.x, player.y, 24, "#ffd37a", 245);
    // 胜负在整帧更新末尾统一结算，以保证同帧双方归零时失败优先。
  }

  /* ---------- 粒子与背景 ---------- */

  function burst(x, y, count, color, power) {
    for (let i = 0; i < count; i += 1) {
      const angle = random(0, TAU);
      const speed = random(power * 0.25, power);
      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: random(0.28, 0.72),
        maxLife: 0.72,
        size: random(1.2, 3.4),
        color,
      });
    }
  }

  function updateParticles(dt) {
    for (let i = particles.length - 1; i >= 0; i -= 1) {
      const particle = particles[i];
      particle.life -= dt;
      if (particle.life <= 0) {
        particles.splice(i, 1);
        continue;
      }

      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= Math.pow(0.18, dt);
      particle.vy *= Math.pow(0.18, dt);
    }
  }

  function updateStars(dt) {
    for (const star of stars) {
      star.y += star.speed * dt;
      if (star.y > H + 4) {
        star.y = -4;
        star.x = random(6, W - 6);
      }
    }
  }

  // 第二关背景的缓慢矿尘/碎片视差。
  function updateDust(dt) {
    for (const mote of dust) {
      mote.x += mote.speedX * dt;
      mote.y += mote.speedY * dt;

      if (mote.y > H + 6) {
        mote.y = -6;
        mote.x = random(0, W);
      }
      if (mote.x < -6) {
        mote.x = W + 6;
        mote.y = random(0, H);
      }
    }
  }

  function updateEffects(dt) {
    shakeClock = Math.max(0, shakeClock - dt);
    damageFlash = Math.max(0, damageFlash - dt);
    muzzleFlashClock = Math.max(0, muzzleFlashClock - dt);
  }

  /* ---------- 主更新 ---------- */

  function update(dt) {
    elapsed += dt;
    updateStars(dt);
    updateEffects(dt);
    updatePlayer(dt);
    updateShooting(dt);

    if (currentLevel === 1) {
      updateSpawner(dt);
    } else {
      updateWaveFlow(dt);
      updateDust(dt);
    }

    updateEnemies(dt);
    updateBossEncounter(dt);
    if (currentLevel === 2) {
      updateRocks(dt);
    } else if (currentLevel === 3) {
      updateLasers(dt);
    }
    updateBossBullets(dt);
    updateEnemyBullets(dt);
    updateBullets(dt);
    resolvePlayerCollisions();
    resolveBossBodyCollision();

    if (state === State.PLAYING) {
      updateParticles(dt);
      resolveRoundOutcome();
    }
  }

  /* ---------- 绘制 ---------- */

  function drawBackdrop() {
    const isMineField = currentLevel === 2;
    const isDock = currentLevel === 3;
    const sky = ctx.createLinearGradient(0, 0, 0, H);

    if (isMineField) {
      // 第二关：暖琥珀 + 冷钢灰的废弃矿场。
      sky.addColorStop(0, "#1a1208");
      sky.addColorStop(0.45, "#120e0a");
      sky.addColorStop(1, "#06080c");
    } else if (isDock) {
      // 第三关：冷青 + 紫罗兰的轨道船坞。
      sky.addColorStop(0, "#081420");
      sky.addColorStop(0.46, "#071019");
      sky.addColorStop(1, "#03060c");
    } else {
      sky.addColorStop(0, "#06121f");
      sky.addColorStop(0.45, "#04101a");
      sky.addColorStop(1, "#040a12");
    }

    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, W, H);

    const nebulaA = ctx.createRadialGradient(
      W * 0.16,
      H * 0.18,
      8,
      W * 0.16,
      H * 0.18,
      W * 0.48,
    );
    if (isMineField) {
      nebulaA.addColorStop(0, "rgba(197, 118, 41, 0.16)");
      nebulaA.addColorStop(0.45, "rgba(140, 84, 36, 0.07)");
    } else if (isDock) {
      nebulaA.addColorStop(0, "rgba(46, 196, 220, 0.14)");
      nebulaA.addColorStop(0.45, "rgba(28, 118, 154, 0.06)");
    } else {
      nebulaA.addColorStop(0, "rgba(31, 139, 164, 0.13)");
      nebulaA.addColorStop(0.45, "rgba(20, 102, 140, 0.055)");
    }
    nebulaA.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = nebulaA;
    ctx.fillRect(0, 0, W, H);

    const nebulaB = ctx.createRadialGradient(
      W * 0.86,
      H * 0.74,
      10,
      W * 0.86,
      H * 0.74,
      W * 0.42,
    );
    if (isMineField) {
      nebulaB.addColorStop(0, "rgba(86, 102, 122, 0.12)");
      nebulaB.addColorStop(0.55, "rgba(52, 64, 80, 0.05)");
    } else if (isDock) {
      nebulaB.addColorStop(0, "rgba(120, 78, 208, 0.11)");
      nebulaB.addColorStop(0.55, "rgba(71, 44, 128, 0.045)");
    } else {
      nebulaB.addColorStop(0, "rgba(137, 40, 97, 0.09)");
      nebulaB.addColorStop(0.55, "rgba(93, 30, 84, 0.035)");
    }
    nebulaB.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = nebulaB;
    ctx.fillRect(0, 0, W, H);

    // 极淡的坐标网格，给驾驶舱一点仪表感。
    ctx.strokeStyle = isMineField
      ? "rgba(255, 196, 128, 0.04)"
      : isDock
        ? "rgba(114, 238, 255, 0.045)"
        : "rgba(115, 219, 255, 0.045)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 120; x < W; x += 120) {
      ctx.moveTo(x + 0.5, 0);
      ctx.lineTo(x + 0.5, H);
    }
    for (let y = 100; y < H; y += 100) {
      ctx.moveTo(0, y + 0.5);
      ctx.lineTo(W, y + 0.5);
    }
    ctx.stroke();

    // 顶部微光，暗示敌方来袭方向。
    const topGlow = ctx.createLinearGradient(0, 0, 0, 130);
    if (isMineField) {
      topGlow.addColorStop(0, "rgba(255, 179, 92, 0.07)");
      topGlow.addColorStop(1, "rgba(255, 179, 92, 0)");
    } else if (isDock) {
      topGlow.addColorStop(0, "rgba(114, 238, 255, 0.075)");
      topGlow.addColorStop(1, "rgba(114, 238, 255, 0)");
    } else {
      topGlow.addColorStop(0, "rgba(255, 93, 148, 0.075)");
      topGlow.addColorStop(1, "rgba(255, 93, 148, 0)");
    }
    ctx.fillStyle = topGlow;
    ctx.fillRect(0, 0, W, 130);

    if (isDock) {
      drawDockStructure();
    }
  }

  // 第三关的船坞桁架 / 环形泊位，纯装饰，不参与碰撞。
  function drawDockStructure() {
    ctx.save();

    // 顶部环形泊位。
    ctx.strokeStyle = "rgba(126, 226, 255, 0.12)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(W / 2, 92, 322, 104, 0, Math.PI * 0.08, Math.PI * 0.92);
    ctx.stroke();

    ctx.strokeStyle = "rgba(171, 129, 255, 0.1)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(W / 2, 92, 286, 82, 0, Math.PI * 0.12, Math.PI * 0.88);
    ctx.stroke();

    // 两侧停泊臂。
    ctx.strokeStyle = "rgba(126, 226, 255, 0.1)";
    ctx.lineWidth = 1.4;
    for (const side of [-1, 1]) {
      const x = W / 2 + side * 372;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 138);
      ctx.lineTo(x - side * 34, 166);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(x, 146, 7, 0, TAU);
      ctx.stroke();

      ctx.fillStyle = "rgba(126, 226, 255, 0.14)";
      ctx.fillRect(x - 1, 0, 2, 112);
    }

    // 底部船坞地标线。
    ctx.strokeStyle = "rgba(171, 129, 255, 0.07)";
    ctx.lineWidth = 1;
    ctx.setLineDash([26, 22]);
    ctx.beginPath();
    ctx.moveTo(70, H - 44);
    ctx.lineTo(W - 70, H - 44);
    ctx.stroke();
    ctx.setLineDash([]);

    // 顶部警示条。
    for (let i = 0; i < 18; i += 1) {
      ctx.fillStyle =
        i % 2 === 0 ? "rgba(255, 138, 216, 0.035)" : "rgba(126, 226, 255, 0.028)";
      ctx.fillRect(i * 54 + 8, 0, 22, 3);
    }

    ctx.restore();
  }

  function drawStars() {
    ctx.save();
    for (const star of stars) {
      const flicker =
        0.68 + 0.32 * Math.sin(elapsed * star.twinkleSpeed + star.twinkle);
      ctx.globalAlpha = star.alpha * flicker;
      ctx.fillStyle = star.speed > 45 ? "#c8f6ff" : "#a9c8dd";
      ctx.fillRect(star.x, star.y, star.size, star.size);
    }
    ctx.restore();
  }

  function drawDust() {
    if (dust.length === 0) {
      return;
    }

    ctx.save();
    for (const mote of dust) {
      const shimmer = 0.7 + 0.3 * Math.sin(elapsed * 0.9 + mote.phase);
      ctx.globalAlpha = mote.alpha * shimmer;
      if (currentLevel === 3) {
        ctx.fillStyle = mote.size > 2.2 ? "#bffcff" : "#6fb8d6";
      } else {
        ctx.fillStyle = mote.size > 2.2 ? "#e9b87a" : "#b78a5c";
      }
      ctx.fillRect(mote.x, mote.y, mote.size, mote.size);
    }
    ctx.restore();
  }

  // 陨石掩体：暖琥珀边缘 + 冷钢灰填充；只挡子弹，不挡飞船。
  function drawRocks() {
    if (rocks.length === 0) {
      return;
    }

    ctx.save();
    for (const rock of rocks) {
      ctx.save();
      ctx.translate(rock.x, rock.y);
      ctx.rotate(rock.rotation);

      const radius = rock.radius;
      const path = new Path2D();
      rock.shape.forEach((vertex, index) => {
        const x = Math.cos(vertex.angle) * radius * vertex.factor;
        const y = Math.sin(vertex.angle) * radius * vertex.factor;
        if (index === 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      });
      path.closePath();

      const fill = ctx.createLinearGradient(-radius, -radius, radius, radius);
      fill.addColorStop(0, rock.size === "large" ? "#3d4653" : "#333c47");
      fill.addColorStop(0.55, "#232b34");
      fill.addColorStop(1, "#0e141b");
      ctx.fillStyle = fill;
      ctx.fill(path);

      ctx.strokeStyle = "rgba(255, 196, 122, 0.52)";
      ctx.lineWidth = 1.4;
      ctx.stroke(path);

      // 内圈高光，给岩石一点体积感。
      ctx.strokeStyle = "rgba(190, 214, 232, 0.13)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, radius * 0.56, Math.PI * 1.08, Math.PI * 1.86);
      ctx.stroke();

      // 裂纹随 hp 出现。
      if (rock.hp < rock.maxHp) {
        ctx.strokeStyle = "rgba(255, 224, 176, 0.62)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(-radius * 0.34, -radius * 0.22);
        ctx.lineTo(radius * 0.08, radius * 0.16);
        ctx.lineTo(-radius * 0.06, radius * 0.46);
        ctx.stroke();
      }

      if (rock.hitFlash > 0) {
        ctx.globalAlpha = clamp(rock.hitFlash / 0.14, 0, 1) * 0.5;
        ctx.fillStyle = "#ffffff";
        ctx.fill(path);
        ctx.globalAlpha = 1;
      }

      ctx.restore();
    }
    ctx.restore();
  }

  // 炮口挂架：先画在机身下方，让机身盖住根部，形成连接结构。
  function drawCannonPylons() {
    ctx.save();
    for (const cannon of CANNON_OFFSETS) {
      const inward = Math.sign(cannon.x);

      ctx.beginPath();
      ctx.moveTo(inward * 6, -4);
      ctx.lineTo(cannon.x, -13);
      ctx.lineTo(cannon.x, -8.5);
      ctx.lineTo(inward * 9, -1);
      ctx.closePath();
      ctx.fillStyle = "#081b26";
      ctx.fill();
      ctx.strokeStyle = "rgba(114, 238, 255, 0.38)";
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.restore();
  }

  // 双炮管与发光炮口。炮口圆心就是 CANNON_OFFSETS 的局部坐标，
  // 与 getMuzzleWorldPositions() 换算出的子弹出生点完全对应。
  function drawCannonBarrels() {
    ctx.save();
    for (const cannon of CANNON_OFFSETS) {
      const { x, y } = cannon;
      const baseY = -5.5;

      ctx.beginPath();
      ctx.moveTo(x - 3.4, baseY);
      ctx.lineTo(x - 3.4, y + 2.2);
      ctx.lineTo(x - 2.1, y);
      ctx.lineTo(x + 2.1, y);
      ctx.lineTo(x + 3.4, y + 2.2);
      ctx.lineTo(x + 3.4, baseY);
      ctx.closePath();
      ctx.fillStyle = "#0a1d28";
      ctx.fill();
      ctx.strokeStyle = "rgba(124, 239, 255, 0.72)";
      ctx.lineWidth = 1.1;
      ctx.stroke();

      ctx.strokeStyle = "rgba(114, 238, 255, 0.28)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x - 1.2, baseY - 2);
      ctx.lineTo(x - 1.2, y + 5);
      ctx.moveTo(x + 1.2, baseY - 2);
      ctx.lineTo(x + 1.2, y + 5);
      ctx.stroke();

      // 炮口环、暗色膛口与轻微呼吸光，保证静止时也能清楚看见左右炮口。
      const pulse = 0.72 + 0.28 * Math.sin(elapsed * 12 + (x > 0 ? 1.5 : 0));
      ctx.save();
      ctx.shadowColor = "#8cf5ff";
      ctx.shadowBlur = 12;
      ctx.fillStyle = "#03121a";
      ctx.beginPath();
      ctx.arc(x, y, 4.2, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "#bafaff";
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.fillStyle = `rgba(188, 252, 255, ${pulse})`;
      ctx.beginPath();
      ctx.arc(x, y, 1.55, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }

  function drawMuzzleFlash() {
    if (muzzleFlashClock <= 0) {
      return;
    }

    const alpha = Math.min(1, muzzleFlashClock / MUZZLE_FLASH_TIME);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";

    for (const cannon of CANNON_OFFSETS) {
      const { x, y } = cannon;
      const plume = 10 + alpha * 9;
      const flare = ctx.createLinearGradient(x, y, x, y - plume);
      flare.addColorStop(0, `rgba(224, 255, 255, ${0.95 * alpha})`);
      flare.addColorStop(0.45, `rgba(114, 238, 255, ${0.62 * alpha})`);
      flare.addColorStop(1, "rgba(114, 238, 255, 0)");
      ctx.fillStyle = flare;
      ctx.beginPath();
      ctx.ellipse(x, y - plume * 0.45, 4.4, plume * 0.55, 0, 0, TAU);
      ctx.fill();
    }

    ctx.restore();
  }

  function drawPlayer() {
    if (lives <= 0) {
      return;
    }

    const blinking =
      player.invulnerable > 0 && Math.floor(player.invulnerable * 16) % 2 === 0;

    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.rotate(player.tilt);
    ctx.globalAlpha = blinking ? 0.36 : 1;

    // 尾焰
    const flame = 17 + Math.sin(elapsed * 44) * 4;
    const flameGradient = ctx.createLinearGradient(0, 20, 0, 25 + flame);
    flameGradient.addColorStop(0, "rgba(202, 253, 255, 0.95)");
    flameGradient.addColorStop(0.5, "rgba(98, 230, 255, 0.8)");
    flameGradient.addColorStop(1, "rgba(43, 116, 255, 0)");
    ctx.fillStyle = flameGradient;
    ctx.beginPath();
    ctx.moveTo(-7, 20);
    ctx.lineTo(7, 20);
    ctx.lineTo(0, 25 + flame);
    ctx.closePath();
    ctx.fill();

    drawCannonPylons();

    // 机翼与机身
    const hullPath = new Path2D();
    hullPath.moveTo(0, -29);
    hullPath.lineTo(6, -16);
    hullPath.lineTo(9, -6);
    hullPath.lineTo(20, 8);
    hullPath.lineTo(27, 17);
    hullPath.lineTo(14, 13);
    hullPath.lineTo(9, 22);
    hullPath.lineTo(4, 26);
    hullPath.lineTo(-4, 26);
    hullPath.lineTo(-9, 22);
    hullPath.lineTo(-14, 13);
    hullPath.lineTo(-27, 17);
    hullPath.lineTo(-20, 8);
    hullPath.lineTo(-9, -6);
    hullPath.lineTo(-6, -16);
    hullPath.closePath();

    ctx.save();
    ctx.shadowColor = "rgba(114, 238, 255, 0.85)";
    ctx.shadowBlur = 18;
    ctx.fillStyle = "#0b2633";
    ctx.fill(hullPath);
    ctx.restore();

    ctx.strokeStyle = "#7cefff";
    ctx.lineWidth = 1.7;
    ctx.stroke(hullPath);

    ctx.strokeStyle = "rgba(114, 238, 255, 0.45)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-19, 9);
    ctx.lineTo(-8, 3);
    ctx.moveTo(19, 9);
    ctx.lineTo(8, 3);
    ctx.moveTo(0, -24);
    ctx.lineTo(0, 16);
    ctx.stroke();

    const cockpit = ctx.createLinearGradient(0, -14, 0, 5);
    cockpit.addColorStop(0, "#d9ffff");
    cockpit.addColorStop(0.5, "#72eeff");
    cockpit.addColorStop(1, "#1e6b89");
    ctx.fillStyle = cockpit;
    ctx.beginPath();
    ctx.ellipse(0, -7, 4.2, 9, 0, 0, TAU);
    ctx.fill();

    ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
    ctx.beginPath();
    ctx.ellipse(-1.2, -10, 1.2, 3.2, -0.25, 0, TAU);
    ctx.fill();

    drawCannonBarrels();
    drawMuzzleFlash();

    ctx.restore();

    // 受击后的短暂护盾环。
    if (player.invulnerable > 0) {
      const shieldAlpha = 0.2 + Math.sin(elapsed * 18) * 0.08;
      ctx.save();
      ctx.strokeStyle = `rgba(114, 238, 255, ${shieldAlpha})`;
      ctx.lineWidth = 1;
      ctx.setLineDash([7, 9]);
      ctx.beginPath();
      ctx.arc(player.x, player.y, 33, 0, TAU);
      ctx.stroke();
      ctx.restore();
    }
  }

  function drawEnemies() {
    for (const enemy of enemies) {
      if (enemy.kind === "sapper") {
        drawSapperEnemy(enemy);
        continue;
      }

      drawChargerEnemy(enemy);
    }
  }

  function drawChargerEnemy(enemy) {
    const glowColor = enemy.id % 2 === 0 ? "#ff789f" : "#ff977c";
    const rotation = Math.sin(enemy.age * 2.2 + enemy.phase) * 0.08;

    ctx.save();
    ctx.translate(enemy.x, enemy.y);
    ctx.rotate(rotation);
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = 14;

    const body = new Path2D();
    body.moveTo(0, 17);
    body.lineTo(9, 8);
    body.lineTo(21, 4);
    body.lineTo(15, -3);
    body.lineTo(20, -11);
    body.lineTo(7, -8);
    body.lineTo(0, -16);
    body.lineTo(-7, -8);
    body.lineTo(-20, -11);
    body.lineTo(-15, -3);
    body.lineTo(-21, 4);
    body.lineTo(-9, 8);
    body.closePath();

    ctx.fillStyle = "#260b19";
    ctx.fill(body);
    ctx.strokeStyle = glowColor;
    ctx.lineWidth = 1.5;
    ctx.stroke(body);

    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(255, 132, 165, 0.54)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-13, -1);
    ctx.lineTo(13, -1);
    ctx.moveTo(-9, 9);
    ctx.lineTo(9, 9);
    ctx.stroke();

    const eye = ctx.createRadialGradient(0, 1, 0, 0, 1, 6);
    eye.addColorStop(0, "#fff0b8");
    eye.addColorStop(0.35, "#ffd37a");
    eye.addColorStop(1, "rgba(255, 93, 148, 0)");
    ctx.fillStyle = eye;
    ctx.beginPath();
    ctx.arc(0, 1, 6, 0, TAU);
    ctx.fill();

    ctx.fillStyle = "#fff6d6";
    ctx.beginPath();
    ctx.arc(0, 1, 1.8, 0, TAU);
    ctx.fill();

    if (enemy.hitFlash > 0) {
      ctx.globalAlpha = clamp(enemy.hitFlash / 0.12, 0, 1) * 0.6;
      ctx.fillStyle = "#ffffff";
      ctx.fill(body);
      ctx.globalAlpha = 1;
    }

    ctx.restore();
  }

  // Sapper：暖橙 / 钢灰的矿用无人机，双炮口朝下，让玩家一眼分辨远程威胁。
  function drawSapperEnemy(enemy) {
    const damaged = enemy.hp < enemy.maxHp;
    const glowColor = damaged ? "#ff8a5c" : "#ffb066";

    ctx.save();
    ctx.translate(enemy.x, enemy.y);
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = 14;

    const hull = new Path2D();
    hull.moveTo(-16, -12);
    hull.lineTo(16, -12);
    hull.lineTo(21, -2);
    hull.lineTo(15, 9);
    hull.lineTo(5, 5);
    hull.lineTo(3, 12);
    hull.lineTo(-3, 12);
    hull.lineTo(-5, 5);
    hull.lineTo(-15, 9);
    hull.lineTo(-21, -2);
    hull.closePath();

    const fill = ctx.createLinearGradient(0, -14, 0, 14);
    fill.addColorStop(0, "#3a2a1c");
    fill.addColorStop(0.5, "#241b16");
    fill.addColorStop(1, "#12161b");
    ctx.fillStyle = fill;
    ctx.fill(hull);
    ctx.strokeStyle = glowColor;
    ctx.lineWidth = 1.5;
    ctx.stroke(hull);

    ctx.shadowBlur = 0;

    // 两条下挂炮管。
    for (const barrelX of [-9, 9]) {
      ctx.fillStyle = "#0d1319";
      ctx.strokeStyle = "rgba(255, 176, 102, 0.62)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(barrelX - 2.6, 4);
      ctx.lineTo(barrelX - 2.6, 15);
      ctx.lineTo(barrelX + 2.6, 15);
      ctx.lineTo(barrelX + 2.6, 4);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = enemy.fireFlash > 0 ? "#fff1c8" : "#ffb066";
      ctx.beginPath();
      ctx.arc(barrelX, 15.5, enemy.fireFlash > 0 ? 3.4 : 2, 0, TAU);
      ctx.fill();
    }

    // 装甲接缝。
    ctx.strokeStyle = "rgba(255, 196, 140, 0.3)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-13, -5);
    ctx.lineTo(13, -5);
    ctx.moveTo(-9, 1);
    ctx.lineTo(9, 1);
    ctx.stroke();

    // 传感器眼：受击后闪烁，提示还剩一段 HP。
    const eye = ctx.createRadialGradient(0, -6, 0, 0, -6, 7);
    eye.addColorStop(0, damaged ? "#fff0e0" : "#fff6d6");
    eye.addColorStop(0.4, glowColor);
    eye.addColorStop(1, "rgba(255, 138, 92, 0)");
    ctx.fillStyle = eye;
    ctx.beginPath();
    ctx.arc(0, -6, 7, 0, TAU);
    ctx.fill();

    ctx.fillStyle = "#fffaf0";
    ctx.beginPath();
    ctx.arc(0, -6, 1.9, 0, TAU);
    ctx.fill();

    if (enemy.hitFlash > 0) {
      ctx.globalAlpha = clamp(enemy.hitFlash / 0.12, 0, 1) * 0.55;
      ctx.fillStyle = "#ffffff";
      ctx.fill(hull);
      ctx.globalAlpha = 1;
    }

    ctx.restore();
  }

  function drawEnemyBullets() {
    if (enemyBullets.length === 0) {
      return;
    }

    ctx.save();

    for (const shot of enemyBullets) {
      const speed = Math.hypot(shot.vx, shot.vy) || 1;

      ctx.shadowColor = "#ffb066";
      ctx.shadowBlur = 12;
      const tailX = shot.x - (shot.vx / speed) * 16;
      const tailY = shot.y - (shot.vy / speed) * 16;
      const tail = ctx.createLinearGradient(tailX, tailY, shot.x, shot.y);
      tail.addColorStop(0, "rgba(255, 176, 102, 0)");
      tail.addColorStop(1, "rgba(255, 211, 122, 0.8)");

      ctx.strokeStyle = tail;
      ctx.lineWidth = 3.4;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(tailX, tailY);
      ctx.lineTo(shot.x, shot.y);
      ctx.stroke();

      const orb = ctx.createRadialGradient(
        shot.x,
        shot.y,
        0,
        shot.x,
        shot.y,
        shot.radius + 3,
      );
      orb.addColorStop(0, "#fff6dd");
      orb.addColorStop(0.4, "#ffcf8a");
      orb.addColorStop(0.75, "#ff9a52");
      orb.addColorStop(1, "rgba(255, 138, 82, 0)");
      ctx.fillStyle = orb;
      ctx.beginPath();
      ctx.arc(shot.x, shot.y, shot.radius + 3, 0, TAU);
      ctx.fill();
    }

    ctx.restore();
  }

  // 第三关激光栅格：预警虚线纵列 → 亮束。画在敌机/飞船之下，避免遮住机体。
  function drawLasers() {
    if (lasers.length === 0) {
      return;
    }

    ctx.save();

    for (const laser of lasers) {
      const half = laser.width / 2;

      if (laser.state === "warning") {
        const progress = 1 - clamp(laser.timer / laser.warningTime, 0, 1);
        const pulse = 0.6 + Math.sin(elapsed * 22) * 0.22;

        const column = ctx.createLinearGradient(
          laser.x - half,
          0,
          laser.x + half,
          0,
        );
        column.addColorStop(0, "rgba(255, 138, 216, 0)");
        column.addColorStop(0.5, `rgba(255, 138, 216, ${0.09 + progress * 0.12})`);
        column.addColorStop(1, "rgba(255, 138, 216, 0)");
        ctx.fillStyle = column;
        ctx.fillRect(laser.x - half, 0, laser.width, H);

        ctx.setLineDash([12, 10]);
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = `rgba(255, 172, 236, ${0.44 + pulse * 0.3})`;
        for (const edge of [-half, half]) {
          ctx.beginPath();
          ctx.moveTo(laser.x + edge, 0);
          ctx.lineTo(laser.x + edge, H);
          ctx.stroke();
        }
        ctx.setLineDash([]);

        // 上下括号与倒计时。
        ctx.strokeStyle = `rgba(255, 211, 246, ${0.66 + pulse * 0.24})`;
        ctx.lineWidth = 2;
        for (const y of [18, H - 18]) {
          const dir = y < H / 2 ? 1 : -1;
          ctx.beginPath();
          ctx.moveTo(laser.x - half - 14, y);
          ctx.lineTo(laser.x - half - 4, y);
          ctx.moveTo(laser.x + half + 4, y);
          ctx.lineTo(laser.x + half + 14, y);
          ctx.moveTo(laser.x - half - 14, y);
          ctx.lineTo(laser.x - half - 14, y + dir * 8);
          ctx.moveTo(laser.x + half + 14, y);
          ctx.lineTo(laser.x + half + 14, y + dir * 8);
          ctx.stroke();
        }

        ctx.fillStyle = "rgba(255, 220, 250, 0.9)";
        ctx.font = '600 10px "SFMono-Regular", Consolas, monospace';
        ctx.textAlign = "center";
        ctx.fillText("GRID LOCK / 栅格锁定", laser.x, H - 44);
        ctx.fillStyle = "rgba(255, 176, 240, 0.98)";
        ctx.font = '700 15px "SFMono-Regular", Consolas, monospace';
        ctx.fillText(`T-${formatWarningTime(laser.timer)}`, laser.x, H - 26);
        continue;
      }

      const intensity = clamp(laser.timer / laser.activeTime, 0, 1);
      ctx.shadowColor = "#ff8ad8";
      ctx.shadowBlur = 24;

      const beam = ctx.createLinearGradient(
        laser.x - half - 12,
        0,
        laser.x + half + 12,
        0,
      );
      beam.addColorStop(0, "rgba(255, 94, 188, 0)");
      beam.addColorStop(0.3, `rgba(255, 94, 188, ${0.4 * intensity})`);
      beam.addColorStop(0.5, `rgba(255, 244, 255, ${0.96 * intensity})`);
      beam.addColorStop(0.7, `rgba(255, 94, 188, ${0.4 * intensity})`);
      beam.addColorStop(1, "rgba(255, 94, 188, 0)");
      ctx.fillStyle = beam;
      ctx.fillRect(laser.x - half - 12, 0, laser.width + 24, H);

      ctx.shadowBlur = 0;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(laser.x - 2.4, 0, 4.8, H);
      ctx.fillStyle = `rgba(255, 232, 255, ${0.9 * intensity})`;
      ctx.fillRect(laser.x - half, 0, 1.2, H);
      ctx.fillRect(laser.x + half - 1.2, 0, 1.2, H);
    }

    ctx.restore();
  }

  function drawBossWarnings() {
    if (bossWarnings.length === 0) {
      return;
    }

    ctx.save();

    for (const warning of bossWarnings) {
      const remaining = clamp(warning.timer / warning.duration, 0, 1);
      const urgency = 1 - remaining;
      const pulse = 0.72 + Math.sin(elapsed * 23) * 0.18;

      if (warning.type === "fan") {
        const radius = 860;
        ctx.save();
        ctx.translate(warning.originX, warning.originY);

        const fanGradient = ctx.createRadialGradient(0, 0, 20, 0, 0, 640);
        fanGradient.addColorStop(
          0,
          `rgba(255, 93, 148, ${0.2 + urgency * 0.09})`,
        );
        fanGradient.addColorStop(
          0.55,
          `rgba(255, 113, 158, ${0.1 + urgency * 0.06})`,
        );
        fanGradient.addColorStop(1, "rgba(255, 93, 148, 0)");

        ctx.fillStyle = fanGradient;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(
          0,
          0,
          radius,
          warning.centerAngle - warning.spread,
          warning.centerAngle + warning.spread,
        );
        ctx.closePath();
        ctx.fill();

        ctx.setLineDash([8, 9]);
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = `rgba(255, 146, 172, ${0.48 + pulse * 0.28})`;

        for (const edge of [-warning.spread, warning.spread]) {
          const angle = warning.centerAngle + edge;
          ctx.beginPath();
          ctx.moveTo(Math.cos(angle) * 24, Math.sin(angle) * 24);
          ctx.lineTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
          ctx.stroke();
        }

        ctx.setLineDash([2, 10]);
        ctx.strokeStyle = `rgba(255, 211, 122, ${0.34 + pulse * 0.22})`;
        ctx.beginPath();
        ctx.moveTo(Math.cos(warning.centerAngle) * 24, Math.sin(warning.centerAngle) * 24);
        ctx.lineTo(
          Math.cos(warning.centerAngle) * radius,
          Math.sin(warning.centerAngle) * radius,
        );
        ctx.stroke();

        ctx.setLineDash([]);
        ctx.lineWidth = 2;
        ctx.strokeStyle = `rgba(255, 160, 182, ${0.62 + pulse * 0.25})`;
        ctx.beginPath();
        ctx.arc(0, 0, 28, -Math.PI / 2, -Math.PI / 2 + TAU * remaining);
        ctx.stroke();

        const labelX = Math.cos(warning.centerAngle) * 235;
        const labelY = Math.sin(warning.centerAngle) * 235;
        ctx.fillStyle = "rgba(255, 186, 202, 0.86)";
        ctx.font = '600 10px "SFMono-Regular", Consolas, monospace';
        ctx.textAlign = "center";
        ctx.fillText("DANGER FAN / 危险扇区", labelX, labelY);
        ctx.fillStyle = "rgba(255, 222, 164, 0.96)";
        ctx.font = '700 15px "SFMono-Regular", Consolas, monospace';
        ctx.fillText(`T-${formatWarningTime(warning.timer)}`, labelX, labelY + 20);
        ctx.restore();
        continue;
      }

      const progress = 1 - remaining;
      const lockGradient = ctx.createRadialGradient(
        warning.x,
        warning.y,
        0,
        warning.x,
        warning.y,
        warning.radius,
      );
      lockGradient.addColorStop(0, `rgba(255, 211, 122, ${0.08 + urgency * 0.15})`);
      lockGradient.addColorStop(0.65, `rgba(255, 93, 148, ${0.08 + urgency * 0.12})`);
      lockGradient.addColorStop(1, "rgba(255, 93, 148, 0)");

      ctx.fillStyle = lockGradient;
      ctx.beginPath();
      ctx.arc(warning.x, warning.y, warning.radius, 0, TAU);
      ctx.fill();

      ctx.save();
      ctx.translate(warning.x, warning.y);

      ctx.setLineDash([6, 7]);
      ctx.lineWidth = 1.4;
      ctx.strokeStyle = `rgba(255, 155, 181, ${0.55 + pulse * 0.25})`;
      ctx.beginPath();
      ctx.arc(0, 0, warning.radius, 0, TAU);
      ctx.stroke();

      ctx.setLineDash([]);
      ctx.lineWidth = 2;
      ctx.strokeStyle = `rgba(255, 211, 122, ${0.48 + urgency * 0.36})`;
      ctx.beginPath();
      ctx.arc(
        0,
        0,
        warning.radius - 9,
        -Math.PI / 2,
        -Math.PI / 2 + TAU * progress,
      );
      ctx.stroke();

      ctx.strokeStyle = `rgba(255, 155, 181, ${0.45 + pulse * 0.25})`;
      ctx.lineWidth = 1;
      const cross = warning.radius + 15;
      ctx.beginPath();
      ctx.moveTo(-cross, 0);
      ctx.lineTo(-24, 0);
      ctx.moveTo(24, 0);
      ctx.lineTo(cross, 0);
      ctx.moveTo(0, -cross);
      ctx.lineTo(0, -24);
      ctx.moveTo(0, 24);
      ctx.lineTo(0, cross);
      ctx.stroke();

      ctx.fillStyle = `rgba(255, 224, 168, ${0.72 + pulse * 0.18})`;
      ctx.beginPath();
      ctx.arc(0, 0, 3.5, 0, TAU);
      ctx.fill();

      ctx.fillStyle = "rgba(255, 206, 181, 0.9)";
      ctx.font = '600 10px "SFMono-Regular", Consolas, monospace';
      ctx.textAlign = "center";
      ctx.fillText("LOCKED / 锁定", 0, -warning.radius - 28);
      ctx.fillStyle = "rgba(255, 226, 170, 0.96)";
      ctx.font = '700 15px "SFMono-Regular", Consolas, monospace';
      ctx.fillText(`T-${formatWarningTime(warning.timer)}`, 0, -warning.radius - 46);
      ctx.restore();

      ctx.setLineDash([3, 9]);
      ctx.strokeStyle = `rgba(255, 132, 165, ${0.24 + pulse * 0.2})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(warning.originX, warning.originY);
      ctx.lineTo(warning.x, warning.y);
      ctx.stroke();
    }

    ctx.restore();
  }

  function drawBoss() {
    if (!boss || boss.defeated) {
      return;
    }

    if (boss.level === 2) {
      drawBoss2();
      return;
    }

    if (boss.level === 3) {
      drawBoss3();
      return;
    }

    ctx.save();
    ctx.translate(boss.x, boss.y);
    ctx.shadowColor = boss.phaseTwo ? "#72eeff" : "#ff5d94";
    ctx.shadowBlur = boss.phaseTwo ? 32 : 26;

    const body = new Path2D();
    body.moveTo(-104, 8);
    body.lineTo(-72, -16);
    body.lineTo(-47, -36);
    body.lineTo(-20, -46);
    body.lineTo(0, -40);
    body.lineTo(20, -46);
    body.lineTo(47, -36);
    body.lineTo(72, -16);
    body.lineTo(104, 8);
    body.lineTo(66, 27);
    body.lineTo(42, 43);
    body.lineTo(0, 31);
    body.lineTo(-42, 43);
    body.lineTo(-66, 27);
    body.closePath();

    const hull = ctx.createLinearGradient(0, -48, 0, 44);
    hull.addColorStop(0, "#2b0c21");
    hull.addColorStop(0.52, "#180d1d");
    hull.addColorStop(1, "#0b1420");
    ctx.fillStyle = hull;
    ctx.fill(body);

    ctx.strokeStyle = boss.phaseTwo ? "#7df4ff" : "#ff719d";
    ctx.lineWidth = 2;
    ctx.stroke(body);

    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(255, 177, 198, 0.28)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-77, 11);
    ctx.lineTo(-35, 2);
    ctx.lineTo(0, 14);
    ctx.lineTo(35, 2);
    ctx.lineTo(77, 11);
    ctx.moveTo(-50, -23);
    ctx.lineTo(-28, -9);
    ctx.lineTo(0, -23);
    ctx.lineTo(28, -9);
    ctx.lineTo(50, -23);
    ctx.stroke();

    ctx.fillStyle = "rgba(8, 19, 29, 0.88)";
    ctx.strokeStyle = "rgba(255, 137, 164, 0.38)";
    for (const side of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(side * 58, -19);
      ctx.lineTo(side * 91, 1);
      ctx.lineTo(side * 72, 18);
      ctx.lineTo(side * 50, 6);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = "rgba(255, 119, 150, 0.62)";
      ctx.fillRect(side * 67 - 4, 23, 8, 10);
      ctx.fillStyle = "#ffd37a";
      ctx.beginPath();
      ctx.arc(side * 67, 34, 3.1, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(8, 19, 29, 0.88)";
    }

    for (const engineX of [-68, -38, 0, 38, 68]) {
      const engineGlow = ctx.createRadialGradient(
        engineX,
        -33,
        0,
        engineX,
        -33,
        10,
      );
      engineGlow.addColorStop(0, "rgba(255, 227, 164, 0.9)");
      engineGlow.addColorStop(0.38, "rgba(255, 146, 130, 0.48)");
      engineGlow.addColorStop(1, "rgba(255, 93, 148, 0)");
      ctx.fillStyle = engineGlow;
      ctx.beginPath();
      ctx.arc(engineX, -33, 10, 0, TAU);
      ctx.fill();
    }

    const coreRadius = 17 + Math.sin(elapsed * 5.4) * 2.4;
    const coreColor = boss.phaseTwo ? "#72eeff" : "#ffd37a";
    const core = ctx.createRadialGradient(0, 8, 0, 0, 8, coreRadius + 12);
    core.addColorStop(0, "#ffffff");
    core.addColorStop(0.22, coreColor);
    core.addColorStop(0.54, boss.phaseTwo ? "rgba(85, 228, 255, 0.55)" : "rgba(255, 93, 148, 0.68)");
    core.addColorStop(1, "rgba(255, 93, 148, 0)");

    ctx.fillStyle = core;
    ctx.beginPath();
    ctx.arc(0, 8, coreRadius + 12, 0, TAU);
    ctx.fill();

    ctx.strokeStyle = boss.phaseTwo ? "#c9fdff" : "#fff0c2";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(0, 8, coreRadius, 0, TAU);
    ctx.stroke();

    ctx.fillStyle = "#fff8df";
    ctx.beginPath();
    ctx.arc(0, 8, 5.2, 0, TAU);
    ctx.fill();

    if (boss.phaseTwo) {
      ctx.strokeStyle = "rgba(114, 238, 255, 0.78)";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 5]);
      ctx.beginPath();
      ctx.arc(0, 8, 29, 0, TAU);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    ctx.fillStyle = "#0a1a27";
    ctx.strokeStyle = "rgba(255, 145, 169, 0.56)";
    ctx.lineWidth = 1;
    for (const cannonX of [-44, 0, 44]) {
      ctx.fillRect(cannonX - 4, 26, 8, 13);
      ctx.strokeRect(cannonX - 4, 26, 8, 13);
      ctx.fillStyle = boss.phaseTwo ? "#b9fdff" : "#ffd37a";
      ctx.beginPath();
      ctx.arc(cannonX, 39, 2.8, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#0a1a27";
    }

    if (boss.muzzleFlash > 0) {
      const flashAlpha = clamp(boss.muzzleFlash / 0.2, 0, 1);
      ctx.globalAlpha = flashAlpha;
      ctx.fillStyle = boss.phaseTwo ? "#bffbff" : "#ffe0a3";
      for (const cannonX of [-44, 0, 44]) {
        ctx.beginPath();
        ctx.arc(cannonX, 41, 9 + flashAlpha * 4, 0, TAU);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    if (boss.hitFlash > 0) {
      ctx.globalAlpha = clamp(boss.hitFlash / 0.14, 0, 1) * 0.28;
      ctx.fillStyle = "#ffffff";
      ctx.fill(body);
      ctx.globalAlpha = 1;
    }

    ctx.restore();
  }

  /* ---------- Boss 2 绘制：矿用掘进机 ---------- */

  function drawBoss2() {
    const phaseTwo = boss.phaseTwo;
    const charging = boss.chargeState === "windup" || boss.chargeState === "dash";
    const dashing = boss.chargeState === "dash";

    ctx.save();
    ctx.translate(boss.x, boss.y);
    ctx.shadowColor = phaseTwo ? "#72eeff" : "#ffb066";
    ctx.shadowBlur = phaseTwo ? 28 : 22;

    // 冲锋速度线（双冲时更明显）。
    if (dashing) {
      ctx.strokeStyle = "rgba(255, 211, 122, 0.32)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 5; i += 1) {
        const y = -30 + i * 14;
        const near = 104 + i * 12;
        const far = 186 + i * 22;
        ctx.beginPath();
        ctx.moveTo(-boss.chargeDir * near, y);
        ctx.lineTo(-boss.chargeDir * far, y);
        ctx.stroke();
      }
    }

    const body = new Path2D();
    body.moveTo(-100, -8);
    body.lineTo(-80, -32);
    body.lineTo(-44, -44);
    body.lineTo(-16, -36);
    body.lineTo(0, -46);
    body.lineTo(16, -36);
    body.lineTo(44, -44);
    body.lineTo(80, -32);
    body.lineTo(100, -8);
    body.lineTo(88, 20);
    body.lineTo(56, 34);
    body.lineTo(22, 30);
    body.lineTo(0, 40);
    body.lineTo(-22, 30);
    body.lineTo(-56, 34);
    body.lineTo(-88, 20);
    body.closePath();

    const hull = ctx.createLinearGradient(0, -48, 0, 44);
    hull.addColorStop(0, "#333940");
    hull.addColorStop(0.46, "#1e252c");
    hull.addColorStop(1, "#0f151c");
    ctx.fillStyle = hull;
    ctx.fill(body);

    ctx.strokeStyle = phaseTwo ? "#9df6ff" : "#ffd37a";
    ctx.lineWidth = 2;
    ctx.stroke(body);

    ctx.shadowBlur = 0;

    // 两侧履带 / 缓冲装甲。
    for (const side of [-1, 1]) {
      ctx.fillStyle = "rgba(12, 18, 24, 0.92)";
      ctx.strokeStyle = "rgba(255, 196, 128, 0.38)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(side * 74, -18);
      ctx.lineTo(side * 96, -4);
      ctx.lineTo(side * 96, 16);
      ctx.lineTo(side * 70, 28);
      ctx.lineTo(side * 60, 10);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = "rgba(255, 196, 128, 0.18)";
      for (let i = 0; i < 4; i += 1) {
        const t = i / 3;
        const plateX = side * (66 + t * 26);
        const plateY = -8 + t * 20;
        ctx.fillRect(plateX - 3, plateY - 3, 6, 6);
      }
    }

    // 装甲接缝。
    ctx.strokeStyle = "rgba(255, 196, 128, 0.24)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-68, 4);
    ctx.lineTo(-28, 14);
    ctx.lineTo(0, 2);
    ctx.lineTo(28, 14);
    ctx.lineTo(68, 4);
    ctx.moveTo(-46, -22);
    ctx.lineTo(-22, -10);
    ctx.lineTo(0, -24);
    ctx.lineTo(22, -10);
    ctx.lineTo(46, -22);
    ctx.stroke();

    // 顶部排气口微光。
    for (const engineX of [-46, 46]) {
      const exhaust = ctx.createRadialGradient(
        engineX,
        -40,
        0,
        engineX,
        -40,
        12,
      );
      exhaust.addColorStop(0, "rgba(255, 227, 164, 0.82)");
      exhaust.addColorStop(0.42, "rgba(255, 168, 96, 0.38)");
      exhaust.addColorStop(1, "rgba(255, 120, 60, 0)");
      ctx.fillStyle = exhaust;
      ctx.beginPath();
      ctx.arc(engineX, -40, 12, 0, TAU);
      ctx.fill();
    }

    if (phaseTwo) {
      // Phase 2：核心暴露，亮青色圆点 + 瞄准括号，明确 2 倍伤害区域。
      const pulse = 1 + Math.sin(elapsed * 6.2) * 0.08;
      const coreRadius = boss.coreRadius * pulse;
      const coreGlow = ctx.createRadialGradient(
        0,
        LEVEL2_CORE_OFFSET_Y,
        0,
        0,
        LEVEL2_CORE_OFFSET_Y,
        coreRadius + 16,
      );
      coreGlow.addColorStop(0, "#ffffff");
      coreGlow.addColorStop(0.26, "#b9fdff");
      coreGlow.addColorStop(0.58, "rgba(114, 238, 255, 0.5)");
      coreGlow.addColorStop(1, "rgba(114, 238, 255, 0)");

      ctx.fillStyle = coreGlow;
      ctx.beginPath();
      ctx.arc(0, LEVEL2_CORE_OFFSET_Y, coreRadius + 16, 0, TAU);
      ctx.fill();

      ctx.strokeStyle = "#d8ffff";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(0, LEVEL2_CORE_OFFSET_Y, coreRadius, 0, TAU);
      ctx.stroke();

      ctx.strokeStyle = "rgba(255, 211, 122, 0.7)";
      ctx.lineWidth = 1.4;
      const bracket = coreRadius + 8;
      for (let i = 0; i < 4; i += 1) {
        const start = (TAU * i) / 4 + 0.2;
        ctx.beginPath();
        ctx.arc(0, LEVEL2_CORE_OFFSET_Y, bracket, start, start + 0.48);
        ctx.stroke();
      }
    } else {
      // Phase 1：钻机护盾覆盖核心，只有身体能打。
      ctx.fillStyle = "rgba(18, 24, 30, 0.94)";
      ctx.strokeStyle = "rgba(255, 211, 122, 0.5)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(0, LEVEL2_CORE_OFFSET_Y, 26, 0, TAU);
      ctx.fill();
      ctx.stroke();

      ctx.strokeStyle = "rgba(255, 196, 128, 0.32)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, LEVEL2_CORE_OFFSET_Y, 18, 0, TAU);
      ctx.stroke();

      for (let i = 0; i < 6; i += 1) {
        const angle = (TAU * i) / 6 + elapsed * 0.5;
        ctx.strokeStyle = "rgba(255, 211, 122, 0.46)";
        ctx.beginPath();
        ctx.moveTo(
          Math.cos(angle) * 11,
          Math.sin(angle) * 11 + LEVEL2_CORE_OFFSET_Y,
        );
        ctx.lineTo(
          Math.cos(angle) * 23,
          Math.sin(angle) * 23 + LEVEL2_CORE_OFFSET_Y,
        );
        ctx.stroke();
      }
    }

    // 钻头：起手/冲锋时高速旋转并带火花。
    ctx.save();
    ctx.translate(0, 26);
    ctx.fillStyle = "#141a20";
    ctx.strokeStyle = "rgba(255, 196, 128, 0.55)";
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(-19, -6);
    ctx.lineTo(19, -6);
    ctx.lineTo(13, 4);
    ctx.lineTo(-13, 4);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    for (let i = 0; i < 3; i += 1) {
      const angle = boss.drillAngle + (TAU * i) / 3;
      const bladeX = Math.cos(angle) * 13;
      const squash = Math.sin(angle);
      ctx.fillStyle = `rgba(255, 211, 122, ${
        0.24 + (charging ? 0.5 : 0.24)
      })`;
      ctx.beginPath();
      ctx.moveTo(bladeX * 0.35, -4);
      ctx.lineTo(bladeX, 8 + squash * 4);
      ctx.lineTo(-bladeX * 0.35, 14);
      ctx.closePath();
      ctx.fill();
    }

    ctx.fillStyle = charging ? "#fff3cd" : "#ffd37a";
    ctx.beginPath();
    ctx.moveTo(-6.5, 10);
    ctx.lineTo(0, 20 + (charging ? 3 : 0));
    ctx.lineTo(6.5, 10);
    ctx.closePath();
    ctx.fill();

    if (charging) {
      ctx.shadowColor = "#ffd37a";
      ctx.shadowBlur = 18;
      ctx.strokeStyle = "rgba(255, 239, 194, 0.7)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(0, 8, 18 + Math.sin(elapsed * 30) * 3, 0, TAU);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }
    ctx.restore();

    // 碎石发射口。
    for (const portX of [-44, 44]) {
      ctx.fillStyle = "#0d1319";
      ctx.strokeStyle = "rgba(255, 196, 128, 0.46)";
      ctx.lineWidth = 1;
      ctx.fillRect(portX - 5, 26, 10, 12);
      ctx.strokeRect(portX - 5, 26, 10, 12);
      ctx.fillStyle = phaseTwo ? "#b9fdff" : "#ffd37a";
      ctx.beginPath();
      ctx.arc(portX, 38, 2.6, 0, TAU);
      ctx.fill();
    }

    if (boss.muzzleFlash > 0) {
      const flashAlpha = clamp(boss.muzzleFlash / 0.2, 0, 1);
      ctx.globalAlpha = flashAlpha;
      ctx.fillStyle = "#ffdca0";
      for (const portX of [-44, 44]) {
        ctx.beginPath();
        ctx.arc(portX, 39, 8 + flashAlpha * 4, 0, TAU);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    if (boss.hitFlash > 0) {
      ctx.globalAlpha = clamp(boss.hitFlash / 0.14, 0, 1) * 0.3;
      ctx.fillStyle = "#ffffff";
      ctx.fill(body);
      ctx.globalAlpha = 1;
    }

    // 转阶段冲击波环。
    if (boss.waveClock > 0) {
      const progress = 1 - clamp(boss.waveClock / 0.7, 0, 1);
      const radius = 40 + progress * 400;
      ctx.strokeStyle = `rgba(255, 211, 122, ${(1 - progress) * 0.7})`;
      ctx.lineWidth = 3 - progress * 2;
      ctx.beginPath();
      ctx.arc(0, LEVEL2_CORE_OFFSET_Y, radius, 0, TAU);
      ctx.stroke();
    }

    ctx.restore();
  }

  /* ---------- Boss 3 绘制：环轨母舰 ---------- */

  function drawBoss3() {
    const phaseTwo = boss.phaseTwo;
    const accent = phaseTwo ? "#c4a6ff" : "#8cf5ff";
    const edge = phaseTwo ? "#ff8ad8" : "#72eeff";

    ctx.save();
    ctx.translate(boss.x, boss.y);
    ctx.shadowColor = accent;
    ctx.shadowBlur = phaseTwo ? 30 : 22;

    // 转阶段冲击波环。
    if (boss.waveClock > 0) {
      const progress = 1 - clamp(boss.waveClock / 0.8, 0, 1);
      const radius = 50 + progress * 460;
      ctx.strokeStyle = `rgba(196, 166, 255, ${(1 - progress) * 0.72})`;
      ctx.lineWidth = 3 - progress * 2;
      ctx.beginPath();
      ctx.arc(0, 4, radius, 0, TAU);
      ctx.stroke();
    }

    // 母舰主体：宽扁的环轨船体。
    const body = new Path2D();
    body.moveTo(-112, -2);
    body.lineTo(-88, -28);
    body.lineTo(-44, -42);
    body.lineTo(-16, -32);
    body.lineTo(0, -40);
    body.lineTo(16, -32);
    body.lineTo(44, -42);
    body.lineTo(88, -28);
    body.lineTo(112, -2);
    body.lineTo(98, 24);
    body.lineTo(56, 36);
    body.lineTo(22, 30);
    body.lineTo(0, 42);
    body.lineTo(-22, 30);
    body.lineTo(-56, 36);
    body.lineTo(-98, 24);
    body.closePath();

    const hull = ctx.createLinearGradient(0, -44, 0, 44);
    hull.addColorStop(0, phaseTwo ? "#322441" : "#273442");
    hull.addColorStop(0.5, "#151e29");
    hull.addColorStop(1, "#0a1119");
    ctx.fillStyle = hull;
    ctx.fill(body);
    ctx.strokeStyle = edge;
    ctx.lineWidth = 2;
    ctx.stroke(body);

    ctx.shadowBlur = 0;

    // 飞行甲板接缝。
    ctx.strokeStyle = phaseTwo
      ? "rgba(196, 166, 255, 0.3)"
      : "rgba(140, 245, 255, 0.24)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-84, 8);
    ctx.lineTo(-34, -4);
    ctx.lineTo(0, 8);
    ctx.lineTo(34, -4);
    ctx.lineTo(84, 8);
    ctx.moveTo(-58, -20);
    ctx.lineTo(-24, -8);
    ctx.lineTo(0, -20);
    ctx.lineTo(24, -8);
    ctx.lineTo(58, -20);
    ctx.stroke();

    // 侧舷炮座（装饰；Boss 3 不发射导弹）。
    for (const side of [-1, 1]) {
      const podX = side * 74;
      ctx.fillStyle = "rgba(9, 16, 24, 0.94)";
      ctx.strokeStyle = phaseTwo
        ? "rgba(255, 138, 216, 0.62)"
        : "rgba(140, 245, 255, 0.52)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(podX - 18, 2);
      ctx.lineTo(podX - 12, 28);
      ctx.lineTo(podX + 12, 28);
      ctx.lineTo(podX + 18, 2);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      for (const barrelX of [podX - 7, podX + 7]) {
        ctx.fillStyle = "#0a121a";
        ctx.fillRect(barrelX - 2.4, 26, 4.8, 11);
        ctx.fillStyle = phaseTwo ? "#ff8ad8" : "#8cf5ff";
        ctx.beginPath();
        ctx.arc(barrelX, 37, 2.4, 0, TAU);
        ctx.fill();
      }
    }

    // 舰桥。
    const bridge = new Path2D();
    bridge.moveTo(-26, -30);
    bridge.lineTo(-16, -46);
    bridge.lineTo(16, -46);
    bridge.lineTo(26, -30);
    bridge.lineTo(18, -18);
    bridge.lineTo(-18, -18);
    bridge.closePath();
    ctx.fillStyle = "rgba(12, 22, 32, 0.96)";
    ctx.fill(bridge);
    ctx.strokeStyle = edge;
    ctx.lineWidth = 1.2;
    ctx.stroke(bridge);

    // 舰桥窗光。
    const bridgeGlow = ctx.createLinearGradient(0, -44, 0, -22);
    bridgeGlow.addColorStop(0, phaseTwo ? "#ffd7f7" : "#d8ffff");
    bridgeGlow.addColorStop(1, phaseTwo ? "rgba(255, 138, 216, 0.12)" : "rgba(114, 238, 255, 0.12)");
    ctx.fillStyle = bridgeGlow;
    ctx.fillRect(-13, -40, 26, 7);

    // 中央主炮。
    ctx.fillStyle = "#0b141d";
    ctx.strokeStyle = phaseTwo
      ? "rgba(255, 138, 216, 0.6)"
      : "rgba(140, 245, 255, 0.55)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-11, 22);
    ctx.lineTo(11, 22);
    ctx.lineTo(8, 46);
    ctx.lineTo(-8, 46);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    const corePulse = 0.7 + Math.sin(elapsed * 6) * 0.2;
    const core = ctx.createRadialGradient(0, 30, 0, 0, 30, 18);
    core.addColorStop(0, "#ffffff");
    core.addColorStop(0.3, phaseTwo ? "#ff8ad8" : "#8cf5ff");
    core.addColorStop(1, phaseTwo ? "rgba(255, 94, 188, 0)" : "rgba(140, 245, 255, 0)");
    ctx.fillStyle = core;
    ctx.globalAlpha = corePulse;
    ctx.beginPath();
    ctx.arc(0, 30, 18, 0, TAU);
    ctx.fill();
    ctx.globalAlpha = 1;

    // 引擎。
    for (const engineX of [-62, -32, 32, 62]) {
      const exhaust = ctx.createRadialGradient(
        engineX,
        -36,
        0,
        engineX,
        -36,
        11,
      );
      exhaust.addColorStop(0, phaseTwo ? "rgba(255, 214, 248, 0.9)" : "rgba(214, 255, 255, 0.9)");
      exhaust.addColorStop(0.45, phaseTwo ? "rgba(255, 94, 188, 0.4)" : "rgba(114, 238, 255, 0.4)");
      exhaust.addColorStop(1, "rgba(114, 238, 255, 0)");
      ctx.fillStyle = exhaust;
      ctx.beginPath();
      ctx.arc(engineX, -36, 11, 0, TAU);
      ctx.fill();
    }

    // Phase 2：过载电弧。
    if (phaseTwo) {
      ctx.strokeStyle = "rgba(255, 138, 216, 0.45)";
      ctx.lineWidth = 1.2;
      for (let i = 0; i < 3; i += 1) {
        const angle = elapsed * 1.8 + (TAU * i) / 3;
        const radius = 96 + Math.sin(elapsed * 7 + i) * 8;
        ctx.beginPath();
        ctx.arc(0, 0, radius, angle, angle + 0.55);
        ctx.stroke();
      }
    } else {
      // Phase 1：护航屏弧线。
      ctx.strokeStyle = "rgba(140, 245, 255, 0.24)";
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 7]);
      ctx.beginPath();
      ctx.arc(0, 4, 118, Math.PI * 1.08, Math.PI * 1.92);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    if (boss.muzzleFlash > 0) {
      const flashAlpha = clamp(boss.muzzleFlash / 0.2, 0, 1);
      ctx.globalAlpha = flashAlpha;
      ctx.fillStyle = phaseTwo ? "#ffd7f7" : "#d8ffff";
      ctx.beginPath();
      ctx.arc(0, 47, 9 + flashAlpha * 5, 0, TAU);
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    if (boss.hitFlash > 0) {
      ctx.globalAlpha = clamp(boss.hitFlash / 0.14, 0, 1) * 0.3;
      ctx.fillStyle = "#ffffff";
      ctx.fill(body);
      ctx.globalAlpha = 1;
    }

    ctx.restore();
  }

  function drawBossBullets() {
    if (bossBullets.length === 0) {
      return;
    }

    ctx.save();
    ctx.shadowColor = "#ff6d86";
    ctx.shadowBlur = 14;

    for (const shot of bossBullets) {
      const isScrap = shot.level === 2;
      const isAegis = shot.level === 3;
      ctx.shadowColor = isAegis
        ? shot.phaseTwo
          ? "#c4a6ff"
          : "#8cf5ff"
        : isScrap
          ? "#ffb066"
          : "#ff6d86";

      const speed = Math.hypot(shot.vx, shot.vy) || 1;
      const tailX = shot.x - (shot.vx / speed) * 18;
      const tailY = shot.y - (shot.vy / speed) * 18;
      const tail = ctx.createLinearGradient(tailX, tailY, shot.x, shot.y);
      tail.addColorStop(
        0,
        isAegis
          ? "rgba(140, 245, 255, 0)"
          : isScrap
            ? "rgba(255, 176, 102, 0)"
            : "rgba(255, 93, 148, 0)",
      );
      tail.addColorStop(
        1,
        isAegis
          ? shot.phaseTwo
            ? "rgba(196, 166, 255, 0.86)"
            : "rgba(140, 245, 255, 0.86)"
          : isScrap
            ? "rgba(255, 211, 122, 0.82)"
            : "rgba(255, 211, 122, 0.76)",
      );

      ctx.strokeStyle = tail;
      ctx.lineWidth = 4;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(tailX, tailY);
      ctx.lineTo(shot.x, shot.y);
      ctx.stroke();

      const orb = ctx.createRadialGradient(
        shot.x,
        shot.y,
        0,
        shot.x,
        shot.y,
        shot.radius + 4,
      );
      orb.addColorStop(0, "#fff9e8");
      orb.addColorStop(
        0.35,
        isAegis
          ? shot.phaseTwo
            ? "#c4a6ff"
            : "#8cf5ff"
          : isScrap
            ? "#ffcf8a"
            : shot.phaseTwo
              ? "#ffb4ef"
              : "#ffd37a",
      );
      orb.addColorStop(
        0.72,
        isAegis ? "#7a5cff" : isScrap ? "#d8622f" : "#ff5d94",
      );
      orb.addColorStop(
        1,
        isAegis
          ? "rgba(122, 92, 255, 0)"
          : isScrap
            ? "rgba(216, 98, 47, 0)"
            : "rgba(255, 93, 148, 0)",
      );
      ctx.fillStyle = orb;
      ctx.beginPath();
      ctx.arc(shot.x, shot.y, shot.radius + 4, 0, TAU);
      ctx.fill();
    }

    ctx.restore();
  }

  function drawBullets() {
    ctx.save();
    ctx.shadowColor = "#89f7ff";
    ctx.shadowBlur = 12;
    for (const bullet of bullets) {
      const gradient = ctx.createLinearGradient(
        0,
        bullet.y - 15,
        0,
        bullet.y + 10,
      );
      gradient.addColorStop(0, "rgba(137, 247, 255, 0)");
      gradient.addColorStop(0.4, "#89f7ff");
      gradient.addColorStop(1, "#ffffff");
      ctx.fillStyle = gradient;
      ctx.fillRect(bullet.x - 1.8, bullet.y - 12, 3.6, 22);
    }
    ctx.restore();
  }

  function drawParticles() {
    ctx.save();
    for (const particle of particles) {
      const alpha = clamp(particle.life / particle.maxLife, 0, 1);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = particle.color;
      ctx.fillRect(
        particle.x - particle.size / 2,
        particle.y - particle.size / 2,
        particle.size,
        particle.size,
      );
    }
    ctx.restore();
  }

  function drawDamageFlash() {
    if (damageFlash <= 0 || state !== State.PLAYING) {
      return;
    }

    const flash = ctx.createRadialGradient(
      W / 2,
      H / 2,
      H * 0.2,
      W / 2,
      H / 2,
      H * 0.78,
    );
    flash.addColorStop(0, "rgba(255, 70, 120, 0)");
    flash.addColorStop(1, `rgba(255, 70, 120, ${damageFlash * 0.48})`);
    ctx.fillStyle = flash;
    ctx.fillRect(0, 0, W, H);
  }

  function render() {
    ctx.clearRect(0, 0, W, H);
    drawBackdrop();
    drawStars();
    if (currentLevel >= 2) {
      drawDust();
    }

    ctx.save();
    if (state === State.PLAYING && shakeClock > 0) {
      const strength = shakeClock * 16;
      ctx.translate(random(-strength, strength), random(-strength, strength));
    }

    drawRocks();
    drawBossWarnings();
    drawLasers();
    drawEnemies();
    drawBoss();
    drawBossBullets();
    drawEnemyBullets();
    drawBullets();
    drawParticles();
    drawPlayer();
    ctx.restore();

    drawDamageFlash();
  }

  /* ---------- 动画循环（全局唯一） ---------- */

  function frame(now) {
    const dt = Math.min(Math.max((now - lastFrameTime) / 1000, 0), 1 / 30);
    lastFrameTime = now;

    if (state === State.PLAYING) {
      update(dt);
    }

    render();
    requestAnimationFrame(frame);
  }

  /* ---------- 自动化验收接口（仅在 ?debug=1 时开启） ---------- */

  function installDebugApi() {
    const enabled = new URLSearchParams(window.location.search).has("debug");
    if (!enabled) {
      return;
    }

    window.__SPACE_SHOOTER_DEBUG__ = Object.freeze({
      snapshot() {
        return {
          state,
          level: currentLevel,
          levelFlow,
          wave,
          waveQuota: hasWaveFlow() ? getWaveQuota() : null,
          waveKills,
          waveBannerClock: Number(waveBannerClock.toFixed(3)),
          levelBannerVisible: !levelBannerEl.hidden,
          levelBannerTitle: levelBannerTitle.textContent,
          score,
          lives,
          elapsed: Number(elapsed.toFixed(4)),
          spawnClock: Number(spawnClock.toFixed(4)),
          player: {
            x: Number(player.x.toFixed(2)),
            y: Number(player.y.toFixed(2)),
            tilt: Number(player.tilt.toFixed(4)),
            invulnerable: Number(player.invulnerable.toFixed(3)),
          },
          muzzles: getMuzzleWorldPositions().map((muzzle) => ({
            side: muzzle.side,
            x: Number(muzzle.x.toFixed(2)),
            y: Number(muzzle.y.toFixed(2)),
          })),
          lastShotMuzzles: lastShotMuzzles.map((muzzle) => ({
            side: muzzle.side,
            x: Number(muzzle.x.toFixed(2)),
            y: Number(muzzle.y.toFixed(2)),
          })),
          enemies: enemies.map((enemy) => ({
            id: enemy.id,
            kind: enemy.kind,
            x: Number(enemy.x.toFixed(2)),
            y: Number(enemy.y.toFixed(2)),
            speed: Number(enemy.speed.toFixed(2)),
            hp: enemy.hp,
            maxHp: enemy.maxHp,
            points: enemy.points,
            holdY: enemy.holdY === null ? null : Number(enemy.holdY.toFixed(2)),
            destroyed: enemy.destroyed,
            hasHitPlayer: enemy.hasHitPlayer,
          })),
          rocks: rocks.map((rock) => ({
            id: rock.id,
            x: Number(rock.x.toFixed(2)),
            y: Number(rock.y.toFixed(2)),
            radius: rock.radius,
            size: rock.size,
            hp: rock.hp,
            maxHp: rock.maxHp,
          })),
          enemyBullets: enemyBullets.map((shot) => ({
            x: Number(shot.x.toFixed(2)),
            y: Number(shot.y.toFixed(2)),
            vx: Number(shot.vx.toFixed(2)),
            vy: Number(shot.vy.toFixed(2)),
            radius: shot.radius,
            owner: shot.owner,
          })),
          lasers: lasers.map((laser) => ({
            id: laser.id,
            x: Number(laser.x.toFixed(2)),
            state: laser.state,
            timer: Number(laser.timer.toFixed(3)),
            warningTime: laser.warningTime,
            activeTime: laser.activeTime,
            width: laser.width,
            source: laser.source,
          })),
          levelLaserTimer: Number(levelLaserTimer.toFixed(3)),
          bullets: bullets.map((bullet) => ({
            x: Number(bullet.x.toFixed(2)),
            y: Number(bullet.y.toFixed(2)),
            side: bullet.side ?? null,
            originX:
              bullet.originX === undefined ? null : Number(bullet.originX.toFixed(2)),
            originY:
              bullet.originY === undefined ? null : Number(bullet.originY.toFixed(2)),
          })),
          destroyedEnemyCount,
          bossEncounter,
          bossWarningClock: Number(bossWarningClock.toFixed(3)),
          bossWarningVisible: !bossWarningEl.hidden,
          bossWarningTimerText: bossWarningTimer.textContent,
          bossHudVisible: !bossHud.hidden,
          paused: state === State.PAUSED,
          pauseOverlayVisible: !pauseOverlay.hidden,
          bossRewardAwarded,
          outcome,
          boss: boss
            ? {
                level: boss.level,
                kind: boss.kind,
                x: Number(boss.x.toFixed(2)),
                y: Number(boss.y.toFixed(2)),
                hp: Number(boss.hp.toFixed(2)),
                maxHp: boss.maxHp,
                reward: boss.reward,
                state: boss.state,
                phaseTwo: boss.phaseTwo,
                phaseTransitions: boss.phaseTransitions,
                defeated: boss.defeated,
                hitHalfW: boss.hitHalfW,
                hitHalfH: boss.hitHalfH,
                coreExposed: Boolean(boss.coreExposed),
                chargeState: boss.chargeState ?? null,
                chargeCount: boss.chargeCount ?? null,
                chargeTimer:
                  boss.chargeTimer === undefined
                    ? null
                    : Number(boss.chargeTimer.toFixed(3)),
                shardTimer:
                  boss.shardTimer === undefined
                    ? null
                    : Number(boss.shardTimer.toFixed(3)),
                burstTimer:
                  boss.burstTimer === undefined
                    ? null
                    : Number(boss.burstTimer.toFixed(3)),
                laserTimer:
                  boss.laserTimer === undefined
                    ? null
                    : Number(boss.laserTimer.toFixed(3)),
              }
            : null,
          bossWarnings: bossWarnings.map((warning) => ({
            type: warning.type,
            timer: Number(warning.timer.toFixed(3)),
            duration: warning.duration,
            x: warning.x === undefined ? null : Number(warning.x.toFixed(2)),
            y: warning.y === undefined ? null : Number(warning.y.toFixed(2)),
            originX: Number(warning.originX.toFixed(2)),
            originY: Number(warning.originY.toFixed(2)),
            centerAngle:
              warning.centerAngle === undefined
                ? null
                : Number(warning.centerAngle.toFixed(4)),
            spread: warning.spread ?? null,
            radius: warning.radius ?? null,
            shotCount: warning.shotCount ?? null,
          })),
          bossBullets: bossBullets.map((shot) => ({
            x: Number(shot.x.toFixed(2)),
            y: Number(shot.y.toFixed(2)),
            vx: Number(shot.vx.toFixed(2)),
            vy: Number(shot.vy.toFixed(2)),
          })),
          killCountText: killCountOutput.textContent,
          killLabelText: killLabel.textContent,
          bossNameText: bossNameOutput.textContent,
          bossPhaseText: bossPhaseText.textContent,
          bossWarningTitleText: bossWarningTitle.textContent,
          bossWarningSubText: bossWarningSub.textContent,
          footerTipText: footerTip.textContent,
          overlayVisible: !overlay.hidden,
          overlayVictory: overlay.classList.contains("is-victory"),
          overlayTitle: gameOverTitle.textContent,
          outcomeSummaryVisible: !outcomeSummary.hidden,
          finalScore: finalScoreOutput.textContent,
        };
      },
      spawnEnemyAt(x, y, options = {}) {
        if (state !== State.PLAYING) {
          return null;
        }
        const enemy = createEnemy({
          x,
          y,
          kind: options.kind,
          hp: options.hp,
          speed: options.speed ?? 0,
          sway: options.sway ?? 0,
        });
        enemies.push(enemy);
        return enemy.id;
      },
      spawnBulletAt(x, y, vy = -BULLET_SPEED) {
        if (state !== State.PLAYING) {
          return false;
        }
        bullets.push({ x, y, vy, halfW: 2.5, halfH: 9 });
        return true;
      },
      clearBullets() {
        if (state !== State.PLAYING) {
          return false;
        }
        bullets = [];
        return true;
      },
      setPlayerPosition(x, y) {
        player.x = clamp(x, PLAYER_HALF_W + 6, W - PLAYER_HALF_W - 6);
        player.y = clamp(y, PLAYER_HALF_H + 6, H - PLAYER_HALF_H - 6);
      },
      setLives(value) {
        lives = clamp(Math.round(value), 0, MAX_LIVES);
        updateHud();
      },
      setInvulnerable(seconds) {
        player.invulnerable = Math.max(0, seconds);
      },
      spawnBossNow() {
        // 只用于第一关：跳过入场。第二关用 skipToBoss2() 走真实入场。
        if (state !== State.PLAYING || currentLevel !== 1) {
          return false;
        }
        bossWarningEl.hidden = true;
        bossEncounter = "boss";
        boss = createBoss(1);
        boss.y = boss.targetY;
        boss.state = "active";
        boss.age = 1.8;
        bossAttackTimer = 0.45;
        updateBossHud();
        return true;
      },
      setBossHealth(value) {
        if (!boss || state !== State.PLAYING) {
          return false;
        }
        boss.hp = clamp(value, 0, boss.maxHp);
        updateBossHud();
        if (!boss.phaseTwo && boss.hp > 0 && boss.hp <= boss.maxHp * 0.5) {
          if (boss.level === 2) {
            enterBoss2PhaseTwo();
          } else if (boss.level === 3) {
            enterBoss3PhaseTwo();
          } else {
            enterBossPhaseTwo();
          }
        }
        if (boss.hp <= 0) {
          defeatBoss();
        }
        return true;
      },
      triggerBossAttack(type = "fan") {
        if (!boss || state !== State.PLAYING || boss.state !== "active" || boss.defeated) {
          return false;
        }

        if (boss.level === 3) {
          if (type === "burst" || type === "fan") {
            fireBoss3Burst();
            return true;
          }
          if (type === "laser") {
            spawnLaserGate(player.x, {
              source: "boss",
              warningTime: BOSS3_LASER_WARNING_TIME,
              activeTime: BOSS3_LASER_ACTIVE_TIME,
            });
            return true;
          }
          if (type === "phase") {
            if (!boss.phaseTwo) {
              enterBoss3PhaseTwo();
            } else {
              lasers = [];
              boss.waveClock = 0.8;
            }
            return true;
          }
          return false;
        }

        if (boss.level === 2) {
          if (type === "charge") {
            boss.chargeState = "idle";
            boss.chargeTimer = 0;
            boss.chargeCount = 0;
            return true;
          }
          if (type === "shards" || type === "fan") {
            fireBoss2Shards();
            return true;
          }
          if (type === "burst") {
            if (!boss.phaseTwo) {
              enterBoss2PhaseTwo();
            } else {
              for (let i = rocks.length - 1; i >= 0; i -= 1) {
                destroyRock(rocks[i], "boss");
              }
              boss.waveClock = 0.7;
            }
            return true;
          }
          return false;
        }

        bossWarnings.length = 0;
        bossAttackTimer = 0;
        if (type === "lock") {
          startBossLockAttack();
        } else {
          startBossFanAttack();
        }
        return true;
      },
      startLevel(level) {
        setLevel(level);
        return true;
      },
      skipToWave(waveIndex) {
        if (state !== State.PLAYING || !hasWaveFlow()) {
          return false;
        }

        const targetWave = clamp(Math.round(waveIndex), 1, getWaveCount());

        bossEncounter = "idle";
        boss = null;
        bossBullets = [];
        bossWarnings = [];
        enemies = [];
        enemyBullets = [];
        lasers = [];

        // 立即进入指定波次，跳过 1.5s 横幅，便于自动化验收。
        startWave(targetWave);
        hideLevelBanner();
        levelFlow = "wave";
        waveBannerClock = 0;
        spawnClock = 0.1;
        updateHud();
        return true;
      },
      skipToBoss2() {
        if (state !== State.PLAYING || currentLevel !== 2) {
          return false;
        }

        enemies = [];
        bossBullets = [];
        bossWarnings = [];
        enemyBullets = [];
        lasers = [];
        wave = LEVEL2_WAVE_COUNT;
        waveKills = getWaveQuota();
        levelFlow = "idle";
        hideLevelBanner();
        resetRocksForBoss();
        beginBossWarning();
        // 缩短预警，但保留真实 Boss 入场（不设置 age=1.8）。
        bossWarningClock = 0.2;
        bossWarningTimer.textContent = formatWarningTime(bossWarningClock);
        updateHud();
        return true;
      },
      skipToBoss3() {
        if (state !== State.PLAYING || currentLevel !== 3) {
          return false;
        }

        enemies = [];
        bossBullets = [];
        bossWarnings = [];
        enemyBullets = [];
        lasers = [];
        rocks = [];
        wave = LEVEL3_WAVE_COUNT;
        waveKills = getWaveQuota();
        levelFlow = "idle";
        hideLevelBanner();
        beginBossWarning();
        // 缩短预警，但保留真实 Boss 入场（不设置 age=1.8）。
        bossWarningClock = 0.2;
        bossWarningTimer.textContent = formatWarningTime(bossWarningClock);
        updateHud();
        return true;
      },
      spawnLaserAt(x, options = {}) {
        if (state !== State.PLAYING || currentLevel !== 3) {
          return null;
        }
        return spawnLaserGate(x, options);
      },
      clearHazards() {
        if (state !== State.PLAYING) {
          return false;
        }
        lasers = [];
        enemyBullets = [];
        bossBullets = [];
        bossWarnings = [];
        return true;
      },
      setLaserTimer(value) {
        if (state !== State.PLAYING || currentLevel !== 3) {
          return false;
        }
        levelLaserTimer = Math.max(0, value);
        return true;
      },
      spawnRockAt(x, y, radius = 24, hp = null) {
        if (state !== State.PLAYING) {
          return null;
        }
        const rock = createRock(x, y, radius, null, hp);
        rocks.push(rock);
        return rock.id;
      },
      damageRockAt(x, y, amount = 1, source = "player") {
        if (state !== State.PLAYING) {
          return false;
        }
        const rock = rocks.find(
          (candidate) =>
            Math.hypot(candidate.x - x, candidate.y - y) <=
            candidate.radius + 12,
        );
        if (!rock) {
          return false;
        }
        damageRock(rock, amount, source);
        return true;
      },
      setWaveKills(value) {
        if (state !== State.PLAYING || !hasWaveFlow()) {
          return false;
        }
        waveKills = clamp(Math.round(value), 0, getWaveQuota());
        updateHud();
        return true;
      },
      restart() {
        restartGame();
      },
    });
  }

  /* ---------- 启动 ---------- */

  setupCanvas();
  initStars();
  initDust();
  currentLevel = readLevelFromUrl();
  resetRound();
  installDebugApi();
  window.addEventListener("resize", setupCanvas);
  requestAnimationFrame(frame);
})();
