#!/usr/bin/env node
/* ============================================================
   第三关「轨道船坞」Node vm 验收脚本
   ------------------------------------------------------------
   不引入任何 npm 依赖：用 vm 沙箱 stub DOM/Canvas，加载真实
   game.js，通过 ?debug=1 暴露的调试接口驱动并断言。
   运行：node tests/level3.test.js
   ============================================================ */
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.resolve(__dirname, "..");
const GAME_PATH = path.join(ROOT, "game.js");
const GAME_CODE = fs.readFileSync(GAME_PATH, "utf8");

const W = 960;
const H = 600;
const DEFAULT_TIP_HTML =
  "击毁 <strong>10</strong> 架普通敌机后进入 BOSS 战 · 预警含倒计时";
const DT_MS = 1000 / 60;

/* ---------- DOM / Canvas stub ---------- */

class FakeClassList {
  constructor() {
    this._names = new Set();
  }

  add(...names) {
    names.forEach((name) => this._names.add(name));
  }

  remove(...names) {
    names.forEach((name) => this._names.delete(name));
  }

  contains(name) {
    return this._names.has(name);
  }

  toggle(name, force) {
    const next = force === undefined ? !this._names.has(name) : Boolean(force);
    if (next) {
      this._names.add(name);
    } else {
      this._names.delete(name);
    }
    return next;
  }
}

class FakeElement {
  constructor(id = "", tagName = "div") {
    this.id = id;
    this.tagName = tagName;
    this.classList = new FakeClassList();
    this.style = {};
    this.dataset = {};
    this.hidden = false;
    this.textContent = "";
    this.innerHTML = "";
    this._attributes = Object.create(null);
    this._listeners = Object.create(null);
    this._queries = new Map();
  }

  setAttribute(name, value) {
    this._attributes[name] = String(value);
  }

  getAttribute(name) {
    return name in this._attributes ? this._attributes[name] : null;
  }

  hasAttribute(name) {
    return name in this._attributes;
  }

  addEventListener(type, handler) {
    if (!this._listeners[type]) {
      this._listeners[type] = [];
    }
    this._listeners[type].push(handler);
  }

  removeEventListener(type, handler) {
    const list = this._listeners[type];
    if (!list) {
      return;
    }
    const index = list.indexOf(handler);
    if (index >= 0) {
      list.splice(index, 1);
    }
  }

  dispatch(type, extra = {}) {
    const list = this._listeners[type] || [];
    for (const handler of list) {
      handler({
        type,
        target: this,
        preventDefault() {},
        stopPropagation() {},
        ...extra,
      });
    }
  }

  querySelector(selector) {
    return this._queries.get(selector) ?? null;
  }

  focus() {}

  blur() {}

  closest() {
    return null;
  }
}

class FakePath2D {
  moveTo() {}
  lineTo() {}
  closePath() {}
  arc() {}
  ellipse() {}
  rect() {}
}

function createContext2D() {
  const target = {};
  const gradient = () => ({ addColorStop() {} });

  return new Proxy(target, {
    get(object, property) {
      if (property === "createLinearGradient" || property === "createRadialGradient") {
        return gradient;
      }
      if (property === "createPattern") {
        return () => ({});
      }
      if (property === "measureText") {
        return () => ({ width: 12 });
      }
      if (property in object) {
        return object[property];
      }
      return () => undefined;
    },
    set(object, property, value) {
      object[property] = value;
      return true;
    },
  });
}

/* ---------- harness ---------- */

function createHarness(options = {}) {
  const search = options.search ?? "";
  const clock = { ms: 0 };
  const rafQueue = [];
  const elements = new Map();
  const windowListeners = Object.create(null);
  const documentListeners = Object.create(null);

  const ctx = createContext2D();

  const lifePips = [0, 1, 2].map(() => new FakeElement("life-pip", "i"));
  const levelButtons = [
    new FakeElement("levelButton1", "button"),
    new FakeElement("levelButton2", "button"),
    new FakeElement("levelButton3", "button"),
  ];
  levelButtons[0].dataset.level = "1";
  levelButtons[1].dataset.level = "2";
  levelButtons[2].dataset.level = "3";

  function getElement(id) {
    let element = elements.get(id);
    if (element) {
      return element;
    }

    element = new FakeElement(id);
    if (id === "bossHud") {
      element._queries.set(".boss-status-text", new FakeElement("bossStatus", "span"));
    }
    if (id === "gameCanvas") {
      element.tagName = "canvas";
      element.getContext = () => ctx;
    }
    if (id === "footerTip") {
      element.innerHTML = DEFAULT_TIP_HTML;
    }
    elements.set(id, element);
    return element;
  }

  const documentStub = {
    hidden: false,
    activeElement: null,
    getElementById(id) {
      return getElement(id);
    },
    querySelectorAll(selector) {
      if (selector === ".life-pip") {
        return lifePips;
      }
      if (selector === ".level-select-button") {
        return levelButtons;
      }
      return [];
    },
    addEventListener(type, handler) {
      if (!documentListeners[type]) {
        documentListeners[type] = [];
      }
      documentListeners[type].push(handler);
    },
    createElement(tagName) {
      return new FakeElement("", tagName);
    },
  };

  const windowStub = {
    location: { search },
    devicePixelRatio: 1,
    addEventListener(type, handler) {
      if (!windowListeners[type]) {
        windowListeners[type] = [];
      }
      windowListeners[type].push(handler);
    },
    removeEventListener() {},
  };

  const sandbox = {
    window: windowStub,
    document: documentStub,
    performance: { now: () => clock.ms },
    requestAnimationFrame(callback) {
      rafQueue.push(callback);
      return rafQueue.length;
    },
    cancelAnimationFrame() {},
    Path2D: FakePath2D,
    Element: FakeElement,
    URLSearchParams,
    console,
  };

  vm.createContext(sandbox);
  vm.runInContext(GAME_CODE, sandbox, { filename: GAME_PATH });

  function runFrames(count, dtMs = DT_MS) {
    for (let i = 0; i < count; i += 1) {
      if (rafQueue.length !== 1) {
        throw new Error(`期望队列里只有 1 个 RAF 回调，实际 ${rafQueue.length} 个`);
      }
      const callback = rafQueue.shift();
      clock.ms += dtMs;
      callback(clock.ms);
    }
  }

  function runFor(seconds, dtMs = DT_MS) {
    runFrames(Math.ceil((seconds * 1000) / dtMs), dtMs);
  }

  function pressKey(code) {
    const list = windowListeners.keydown || [];
    for (const handler of list) {
      handler({
        code,
        repeat: false,
        target: null,
        preventDefault() {},
        stopPropagation() {},
      });
    }
  }

  function releaseKey(code) {
    const list = windowListeners.keyup || [];
    for (const handler of list) {
      handler({ code, target: null, preventDefault() {} });
    }
  }

  return {
    search,
    api: windowStub.__SPACE_SHOOTER_DEBUG__,
    elements,
    getElement,
    levelButtons,
    lifePips,
    runFrames,
    runFor,
    pressKey,
    releaseKey,
    rafQueue,
    clock,
  };
}

/* ---------- 断言工具 ---------- */

let passed = 0;
let failed = 0;
const failures = [];

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function assertEqual(actual, expected, message) {
  if (actual !== expected) {
    throw new Error(`${message}：期望 ${JSON.stringify(expected)}，实际 ${JSON.stringify(actual)}`);
  }
}

function check(name, run) {
  try {
    run();
    passed += 1;
    console.log(`  ✓ ${name}`);
  } catch (error) {
    failed += 1;
    failures.push(`${name}\n      ${error.message}`);
    console.error(`  ✗ ${name}\n      ${error.message}`);
  }
}

/* ---------- 场景 ---------- */

console.log("第三关「轨道船坞」验收");

const h = createHarness({ search: "?debug=1&level=3" });
const d = h.api;

if (!d) {
  console.error("未拿到 window.__SPACE_SHOOTER_DEBUG__，?debug=1 失效");
  process.exit(1);
}

function snapshot() {
  return d.snapshot();
}

// 冻结刷怪：停在指定波次、把击杀配额填满、放一架不动的哑机防止波次推进。
function freezeSpawning(waveIndex) {
  d.skipToWave(waveIndex);
  d.setWaveKills(snapshot().waveQuota);
  d.spawnEnemyAt(900, 40, { kind: "charger" });
  d.clearBullets();
  d.clearHazards();
}

// 用子弹在场上逐个点杀敌机，直到本波结束（用于统计实际生成序列）。
function autoPlayWave(waveIndex) {
  d.skipToWave(waveIndex);
  d.setInvulnerable(999);
  d.setLives(3);
  const seen = new Map();
  let guard = 0;
  let current = snapshot();

  while (current.wave === waveIndex && current.levelFlow !== "idle" && guard < 8000) {
    for (const enemy of current.enemies) {
      seen.set(enemy.id, enemy.kind);
      d.spawnBulletAt(enemy.x, enemy.y + 20);
    }
    h.runFrames(1);
    current = snapshot();
    guard += 1;
  }

  // 自动点杀可能留下脱靶子弹/激光，清掉后再做后续断言。
  d.clearBullets();
  d.clearHazards();
  return { snap: current, kinds: [...seen.values()], frames: guard };
}

check("启动：第三关 0 分 / 3 命 / intro 横幅 / 无岩石 / 无激光", () => {
  const s = snapshot();
  assertEqual(s.level, 3, "关卡");
  assertEqual(s.score, 0, "分数");
  assertEqual(s.lives, 3, "生命");
  assertEqual(s.state, "playing", "状态");
  assertEqual(s.levelFlow, "intro", "流程");
  assertEqual(s.levelBannerVisible, true, "横幅可见");
  assertEqual(s.levelBannerTitle, "LEVEL 03 // 轨道船坞", "横幅标题");
  assertEqual(s.rocks.length, 0, "初始无岩石");
  assertEqual(s.lasers.length, 0, "初始无激光");
  assertEqual(s.killLabelText, "WAVE / 波次", "击毁标签");
  assertEqual(s.killCountText, "00/10", "击毁读数");
  assertEqual(s.bossNameText, "AEGIS-03 // 环轨母舰", "Boss 名称");
  assertEqual(s.bossPhaseText, "PHASE 1 // SCREEN", "Boss 阶段文案");
  assertEqual(s.bossWarningTitleText, "大型母舰接近", "预警标题");
  assertEqual(s.bossWarningSubText, "AEGIS-03 INBOUND", "预警副标题");
  const footer = h.getElement("footerTip").textContent;
  assert(footer.includes("激光栅格"), "页脚提示应说明激光栅格");
  assert(!footer.includes("追踪导弹"), "页脚不应再提追踪导弹");
});

check("intro 1.5s 后进入 Wave 1：10 配额 / 无岩石 / 波次横幅", () => {
  h.runFor(1.6);
  const s = snapshot();
  assertEqual(s.wave, 1, "波次");
  assertEqual(s.levelFlow, "waveBanner", "流程");
  assertEqual(s.waveQuota, 10, "配额");
  assertEqual(s.rocks.length, 0, "无岩石");
  assertEqual(s.lasers.length, 0, "无激光");
  assertEqual(s.levelBannerTitle, "WAVE 1/3", "波次横幅");
  assertEqual(
    h.getElement("levelBannerSub").textContent,
    "船坞外围 // DRYDOCK PERIMETER",
    "波次副标题",
  );
  assertEqual(s.killCountText, "00/10", "击毁读数");
});

check("Wave 1 刷怪：同屏上限 5、只有 Charger、不出现激光", () => {
  h.runFor(1.6);
  let s = snapshot();
  assertEqual(s.levelFlow, "wave", "流程");
  assertEqual(s.levelBannerVisible, false, "横幅收起");

  h.runFor(4);
  s = snapshot();
  assert(s.enemies.length >= 1, `应有敌机，实际 ${s.enemies.length}`);
  assert(s.enemies.length <= 5, `同屏不得超过 5，实际 ${s.enemies.length}`);
  assert(
    s.enemies.every((enemy) => enemy.kind === "charger"),
    "第三关只应出现 Charger",
  );
  assertEqual(s.lasers.length, 0, "Wave 1 不生成激光");
});

check("Charger：1 发击毁、100 分、计入波次配额", () => {
  freezeSpawning(1);
  const before = snapshot();
  const id = d.spawnEnemyAt(480, 200, { kind: "charger" });
  assert(id !== null, "spawnEnemyAt 失败");

  let s = snapshot();
  const charger = s.enemies.find((enemy) => enemy.id === id);
  assertEqual(charger.kind, "charger", "类型");
  assertEqual(charger.hp, 1, "hp");
  assertEqual(charger.points, 100, "分数");

  d.spawnBulletAt(charger.x, charger.y + 20);
  h.runFrames(2);
  s = snapshot();
  assert(!s.enemies.some((enemy) => enemy.id === id), "一发应击杀");
  assertEqual(s.score, before.score + 100, "Charger 得分");
  assertEqual(s.destroyedEnemyCount, before.destroyedEnemyCount + 1, "击毁计数");
  assertEqual(s.waveKills, before.waveKills + 1, "波次配额进度");
});

check("Wave 1 不生成激光：跑 6s 仍无激光", () => {
  d.startLevel(3);
  h.runFor(1.6);
  h.runFor(1.6);
  h.runFor(6);
  const s = snapshot();
  assertEqual(s.wave, 1, "仍在 Wave 1");
  assertEqual(s.lasers.length, 0, "Wave 1 不应生成激光");
});

check("激光栅格：预警不伤害，active 命中掉 1 命且只结算一次", () => {
  freezeSpawning(2);
  d.clearHazards();
  d.setPlayerPosition(480, 520);
  d.setLives(3);
  d.setInvulnerable(0);

  const laserId = d.spawnLaserAt(480, { warningTime: 0.5, activeTime: 0.5 });
  assert(laserId !== null, "spawnLaserAt 失败");

  h.runFrames(20);
  let s = snapshot();
  assertEqual(s.lives, 3, "预警阶段不伤害");
  assertEqual(s.lasers[0].state, "warning", "预警状态");

  h.runFrames(20);
  s = snapshot();
  assertEqual(s.lives, 2, "active 命中应掉 1 命");
  assert(s.player.invulnerable > 0, "命中瞬间应进入无敌帧");

  h.runFrames(40);
  s = snapshot();
  assertEqual(s.lives, 2, "无敌帧内不重复掉命");
  assertEqual(s.lasers.length, 0, "激光结束后应清理");
});

check("激光栅格：不在纵列内不受伤", () => {
  freezeSpawning(2);
  d.clearHazards();
  d.setPlayerPosition(200, 520);
  d.setLives(3);
  d.setInvulnerable(0);
  d.spawnLaserAt(700, { warningTime: 0.3, activeTime: 0.4 });
  h.runFor(1);
  assertEqual(snapshot().lives, 3, "不在纵列内不应掉命");
});

check("Wave 2 激光：首次 5.0s 生成并锁定玩家 x", () => {
  d.startLevel(3);
  d.skipToWave(2);
  d.setPlayerPosition(480, 520);
  d.setInvulnerable(999);
  d.setLives(3);
  d.clearHazards();

  h.runFor(4.8);
  assertEqual(snapshot().lasers.length, 0, "5.0s 前不应生成");
  h.runFor(0.3);
  const s = snapshot();
  assertEqual(s.lasers.length, 1, "5.0s 后应生成激光");
  assert(Math.abs(s.lasers[0].x - 480) <= 0.5, `激光应锁定玩家 x，实际 ${s.lasers[0].x}`);
  assertEqual(s.lasers[0].source, "wave", "波次激光来源");
});

check("波次切换清空激光：Wave 2 清空后无残留", () => {
  d.startLevel(3);
  d.skipToWave(2);
  d.setWaveKills(snapshot().waveQuota);
  d.spawnLaserAt(480, { warningTime: 2, activeTime: 2 });
  assertEqual(snapshot().lasers.length, 1, "测试激光已生成");

  h.runFrames(1);
  const s = snapshot();
  assertEqual(s.wave, 3, "应进入 Wave 3");
  assertEqual(s.levelFlow, "waveBanner", "Wave 3 横幅");
  assertEqual(s.lasers.length, 0, "波次切换应清空激光");
});

check("Wave 2：配额 12、只有 Charger，清空后进入 Wave 3", () => {
  const { snap, kinds } = autoPlayWave(2);
  assertEqual(kinds.length, 12, "总生成数应等于配额");
  assert(kinds.every((kind) => kind === "charger"), "第三关只应生成 Charger");
  assertEqual(snap.wave, 3, "应进入 Wave 3");
  assertEqual(snap.levelFlow, "waveBanner", "Wave 3 横幅");
  assertEqual(snap.levelBannerTitle, "WAVE 3/3", "横幅标题");
});

check("Wave 3：配额 14、只有 Charger，清空后进入 Boss 预警", () => {
  const { snap, kinds } = autoPlayWave(3);
  assertEqual(kinds.length, 14, "总生成数应等于配额");
  assert(kinds.every((kind) => kind === "charger"), "第三关只应生成 Charger");
  assertEqual(snap.levelFlow, "idle", "流程回到 idle");
  assertEqual(snap.bossEncounter, "warning", "进入 Boss 预警");
  assertEqual(snap.bossWarningVisible, true, "预警可见");
  assertEqual(snap.bossWarningTitleText, "大型母舰接近", "预警标题");
  assertEqual(snap.levelBannerVisible, false, "Boss 预警期间关卡横幅收起");
  assertEqual(snap.rocks.length, 0, "第三关无岩石");
  assertEqual(snap.lasers.length, 0, "Boss 预警时清空激光");

  h.runFor(2.4);
  const s = snapshot();
  assertEqual(s.bossEncounter, "boss", "Boss 阶段");
  assertEqual(s.boss.state, "entering", "入场中");
  assertEqual(s.boss.level, 3, "Boss 关卡");
  assertEqual(s.boss.kind, "aegis", "Boss 类型");
  assertEqual(s.boss.maxHp, 3000, "Boss 血量");
  assertEqual(s.boss.hp, 3000, "Boss 初始血量");
  assertEqual(s.boss.reward, 12000, "Boss 奖励");
  assertEqual(s.bossHudVisible, true, "Boss HUD 可见");
  assert(Math.abs(s.boss.x - W / 2) < 0.01, "入场期间 x 固定");
});

check("Boss 3 入场无横闪：到达 y≈146 时 x 仍为 480", () => {
  let guard = 0;
  while (snapshot().boss && snapshot().boss.state === "entering" && guard < 300) {
    h.runFrames(1);
    guard += 1;
  }
  const s = snapshot();
  assertEqual(s.boss.state, "active", "应进入 active");
  assert(Math.abs(s.boss.x - 480) < 0.6, `不应横向闪现，x=${s.boss.x.toFixed(2)}`);
  assert(Math.abs(s.boss.y - 146) < 12, `入场高度 y=${s.boss.y.toFixed(2)}`);
  assertEqual(s.bossPhaseText, "PHASE 1 // SCREEN", "HUD 阶段");
  assert(
    h.getElement("bossHud").classList.contains("is-aegis"),
    "Boss HUD 应带 is-aegis",
  );
});

check("Boss 3 Phase 1：5 发扇射、无预警、无导弹", () => {
  d.setLives(3);
  d.setInvulnerable(999);
  d.clearHazards();
  const before = snapshot().bossBullets.length;
  assertEqual(d.triggerBossAttack("burst"), true, "triggerBossAttack 失败");
  const s = snapshot();
  assertEqual(s.bossBullets.length - before, 5, "扇射数量");
  assertEqual(s.bossWarnings.length, 0, "第三关扇射无预警");
  assertEqual(d.triggerBossAttack("missiles"), false, "不应再有导弹攻击");
  assertEqual(snapshot().enemyBullets.length, 0, "场上不应有敌方导弹");
});

check("Boss 3 50% 转阶段：清空激光、不伤玩家、只触发一次", () => {
  d.setLives(3);
  d.setInvulnerable(999);
  d.clearHazards();
  d.spawnLaserAt(480, { source: "boss" });
  const before = snapshot();
  assertEqual(before.lasers.length, 1, "转阶段前应有激光");

  d.setBossHealth(1500);
  const s = snapshot();
  assertEqual(s.boss.phaseTwo, true, "phaseTwo");
  assertEqual(s.boss.phaseTransitions, 1, "转阶段次数");
  assertEqual(s.lasers.length, 0, "转阶段清空激光");
  assertEqual(s.lives, before.lives, "转阶段不伤害玩家");
  assertEqual(s.bossPhaseText, "PHASE 2 // OVERDRIVE", "HUD 阶段");

  d.setBossHealth(1500);
  assertEqual(snapshot().boss.phaseTransitions, 1, "phaseTwo 只能触发一次");
});

check("Boss 3 Phase 2：7 发扇射、1 道激光、无导弹", () => {
  d.clearHazards();
  const before = snapshot().bossBullets.length;
  d.triggerBossAttack("burst");
  assertEqual(snapshot().bossBullets.length - before, 7, "Phase 2 扇射数量");

  d.clearHazards();
  assertEqual(d.triggerBossAttack("laser"), true, "触发激光失败");
  const s = snapshot();
  assertEqual(s.lasers.length, 1, "Phase 2 激光数量");
  assertEqual(s.lasers[0].source, "boss", "激光来源");
  assertEqual(s.lasers[0].warningTime, 0.85, "Boss 激光预警");
  assertEqual(s.lasers[0].activeTime, 0.6, "Boss 激光持续");

  assertEqual(d.triggerBossAttack("missiles"), false, "Phase 2 不应再有导弹");
  assertEqual(snapshot().enemyBullets.length, 0, "场上不应有敌方导弹");
});

check("Boss 3 Phase 2 激光命中玩家：掉 1 命", () => {
  d.clearHazards();
  d.setLives(3);
  d.setInvulnerable(0);
  d.setPlayerPosition(480, 520);
  d.spawnLaserAt(480, { source: "boss", warningTime: 0.3, activeTime: 0.4 });
  h.runFor(1);
  const s = snapshot();
  assertEqual(s.lives, 2, "激光应掉 1 命");
  assert(s.player.invulnerable > 0, "应进入无敌帧");
});

check("Boss 3 身体 12 伤害，无核心倍率", () => {
  d.clearHazards();
  d.setLives(3);
  d.setInvulnerable(999);
  const before = snapshot().boss.hp;
  const boss = snapshot().boss;
  d.spawnBulletAt(boss.x, boss.y + 20);
  h.runFrames(2);
  const after = snapshot().boss.hp;
  assertEqual(before - after, 12, "身体伤害");
});

check("Boss 3 击破：奖励 12000、文案「船坞肃清」", () => {
  d.setLives(3);
  d.setInvulnerable(999);
  const before = snapshot();
  d.setBossHealth(0);
  h.runFrames(1);
  const s = snapshot();
  assertEqual(s.boss.defeated, true, "defeated");
  assertEqual(s.state, "gameover", "状态");
  assertEqual(s.outcome, "victory", "结果");
  assertEqual(s.overlayVisible, true, "结算层可见");
  assertEqual(s.overlayTitle, "船坞肃清", "胜利文案");
  assertEqual(s.score, before.score + 12000, "击破奖励");
  assertEqual(
    h.getElement("outcomeSummary").textContent,
    "AEGIS-03 击破奖励 +12000",
    "结算摘要",
  );
});

check("重开：保持第三关、回到 intro、0 分 3 命、清空激光、单 RAF", () => {
  d.restart();
  const s = snapshot();
  assertEqual(s.level, 3, "关卡");
  assertEqual(s.score, 0, "分数");
  assertEqual(s.lives, 3, "生命");
  assertEqual(s.levelFlow, "intro", "流程");
  assertEqual(s.wave, 0, "波次");
  assertEqual(s.lasers.length, 0, "激光已清空");
  assertEqual(s.enemyBullets.length, 0, "敌方子弹已清空");
  assertEqual(s.rocks.length, 0, "岩石为空");
  assertEqual(s.boss, null, "Boss 已清空");
  assertEqual(s.overlayVisible, false, "结算层隐藏");
  assertEqual(s.levelBannerVisible, true, "intro 横幅");
  assertEqual(h.rafQueue.length, 1, "只有一个 RAF 回调");
});

check("第三关死亡：文案「船坞失守」，重开从 Wave 1", () => {
  d.startLevel(3);
  h.runFor(1.6);
  h.runFor(1.6);
  d.setLives(0);
  h.runFrames(1);
  const s = snapshot();
  assertEqual(s.state, "gameover", "状态");
  assertEqual(s.outcome, "defeat", "结果");
  assertEqual(s.overlayTitle, "船坞失守", "失败文案");

  d.restart();
  const after = snapshot();
  assertEqual(after.level, 3, "重开关卡");
  assertEqual(after.wave, 0, "回到 Wave 1 之前");
  assertEqual(after.levelFlow, "intro", "intro");
  assertEqual(after.score, 0, "0 分");
  assertEqual(after.lives, 3, "3 命");
});

check("暂停冻结激光计时，恢复后继续", () => {
  d.startLevel(3);
  d.skipToWave(2);
  d.clearHazards();
  d.setPlayerPosition(200, 520);
  d.spawnLaserAt(700, { warningTime: 1.0, activeTime: 0.7 });

  h.pressKey("KeyP");
  let s = snapshot();
  assertEqual(s.paused, true, "暂停");
  const frozen = s.lasers[0].timer;
  h.runFrames(12);
  s = snapshot();
  assertEqual(s.lasers[0].timer, frozen, "激光计时冻结");

  h.pressKey("KeyP");
  assertEqual(snapshot().paused, false, "恢复");
  h.runFrames(6);
  assert(snapshot().lasers[0].timer < frozen, "恢复后计时继续");
});

check("顶栏 03 按钮：点击立即切关并同步 UI", () => {
  h.levelButtons[2].dispatch("click");
  let s = snapshot();
  assertEqual(s.level, 3, "切到第三关");
  assertEqual(h.levelButtons[2].getAttribute("aria-pressed"), "true", "aria-pressed 03");
  assertEqual(h.levelButtons[1].getAttribute("aria-pressed"), "false", "aria-pressed 02");
  assert(h.levelButtons[2].classList.contains("is-active"), "is-active 03");
  assertEqual(h.getElement("brandEyebrow").textContent, "ORBITAL ARCADE / 03", "品牌眉标");
  assertEqual(s.killLabelText, "WAVE / 波次", "击毁标签");
  const footer = h.getElement("footerTip").textContent;
  assert(footer.includes("激光栅格"), "页脚提示");
  assert(!footer.includes("追踪导弹"), "页脚不应再提追踪导弹");
});

check("切到第二关仍显示原关卡；切回第三关无残留", () => {
  d.startLevel(2);
  let s = snapshot();
  assertEqual(s.level, 2, "关卡");
  assertEqual(s.levelBannerTitle, "LEVEL 02 // 废弃矿场", "第二关 intro 横幅");
  h.runFor(1.6);
  s = snapshot();
  assertEqual(s.levelBannerTitle, "WAVE 1/3", "第二关波次横幅");
  assertEqual(s.rocks.length, 4, "第二关 Wave 1 岩石");
  assertEqual(s.killCountText, "00/08", "第二关读数");
  assertEqual(s.lasers.length, 0, "第二关无激光");

  d.startLevel(3);
  s = snapshot();
  assertEqual(s.level, 3, "切回第三关");
  assertEqual(s.rocks.length, 0, "岩石已清空");
  assertEqual(s.lasers.length, 0, "激光已清空");
  assertEqual(s.levelBannerTitle, "LEVEL 03 // 轨道船坞", "第三关横幅");
});

check("调试快照包含第三关字段，且不再暴露导弹字段", () => {
  d.startLevel(3);
  let s = snapshot();
  assert("lasers" in s, "lasers 字段");
  assert("levelLaserTimer" in s, "levelLaserTimer 字段");
  assert(!("destroyedMissileCount" in s), "不应再有 destroyedMissileCount");
  assertEqual(s.waveQuota, 10, "waveQuota");
  assertEqual(s.waveKills, 0, "waveKills");

  d.skipToBoss3();
  h.runFor(2.5);
  while (snapshot().boss && snapshot().boss.state === "entering") {
    h.runFrames(1);
  }
  s = snapshot();
  assert(s.boss, "Boss 应存在");
  assert("burstTimer" in s.boss, "Boss burstTimer 字段");
  assert("laserTimer" in s.boss, "Boss laserTimer 字段");
  assert(!("missileTimer" in s.boss), "Boss 不应再有 missileTimer");
});

check("连续切关/重开不增加 RAF 回调", () => {
  d.startLevel(1);
  d.startLevel(2);
  d.startLevel(3);
  d.restart();
  assertEqual(h.rafQueue.length, 1, "只有一个 RAF 回调");
});

/* ---------- 入口/回归 ---------- */

const direct = createHarness({ search: "?level=3" });

check("?level=3 直达第三关（无 debug 参数也可用）", () => {
  assertEqual(direct.api, undefined, "无 debug 时不应暴露接口");
  assertEqual(direct.getElement("levelBanner").hidden, false, "关卡横幅可见");
  assertEqual(
    direct.getElement("levelBannerTitle").textContent,
    "LEVEL 03 // 轨道船坞",
    "横幅标题",
  );
  assertEqual(
    direct.getElement("brandEyebrow").textContent,
    "ORBITAL ARCADE / 03",
    "品牌眉标",
  );
  assertEqual(direct.getElement("killLabel").textContent, "WAVE / 波次", "击毁标签");
  assert(
    direct.getElement("footerTip").textContent.includes("激光栅格"),
    "页脚提示",
  );
  direct.runFrames(3);
});

const fallback = createHarness({ search: "" });

check("默认启动仍是第一关，第三关不污染默认入口", () => {
  assertEqual(fallback.api, undefined, "无 debug 时不应暴露接口");
  assertEqual(fallback.getElement("levelBanner").hidden, true, "不显示关卡横幅");
  assertEqual(fallback.getElement("killLabel").textContent, "KILLS / 击毁", "击毁标签");
  assertEqual(fallback.getElement("bossName").textContent, "BOSS // 歼星母舰", "Boss 名称");
  assertEqual(fallback.getElement("bossWarningTitle").textContent, "大型敌机接近", "预警标题");
  assertEqual(fallback.getElement("bossHpText").textContent, "1600 / 1600", "Boss HP 文案");
  fallback.runFrames(6);
});

/* ---------- 汇总 ---------- */

console.log("");
if (failed === 0) {
  console.log(`全部通过：${passed} 项`);
  process.exit(0);
}

console.log(`通过 ${passed} 项，失败 ${failed} 项：`);
failures.forEach((failure) => console.log(`  - ${failure}`));
process.exit(1);
