# 太空射击实践 · 六轮游戏版本

按 01—06 查看迭代结果。复制整个版本目录到自己的练习文件夹，再打开 index.html。HTML、CSS、JavaScript 必须保留在同一目录。

这是阶段快照，含课堂讨论的已知限制，不代表每轮都已完成全部人工验收。

实践讲解：https://jluios.club/resources/ai-programming/chapters/07

来源：太空射击实战资料包（精简版）中的深空防线（结构化）。原版本 README 中的跨目录链接指向完整原资料包，本下载仅提供六轮游戏源码及其测试。
